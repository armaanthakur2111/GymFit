package com.gymfit.app.data.repository;

import android.os.Handler;
import android.os.Looper;

import com.gymfit.app.BuildConfig;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.model.TemplateExercise;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.model.Workout;
import com.gymfit.app.data.model.WorkoutTemplate;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * AI Coach backend access.
 *
 * SECURITY: the OpenAI key must never ship inside the APK. The app talks to a
 * backend/proxy endpoint configured at build time (GYMFIT_AI_ENDPOINT in
 * gradle.properties). If the endpoint is an OpenAI-compatible API and a key is
 * provided via GYMFIT_AI_KEY (also build config, ideally a per-user proxy
 * token), it is sent as a Bearer token. Requests use the standard chat
 * completions shape so any OpenAI-compatible gateway works.
 */
public class AiCoachRepository {

    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    public static class ChatMessage {
        public final String role;    // "user" | "assistant" | "system"
        public final String content;

        public ChatMessage(String role, String content) {
            this.role = role;
            this.content = content;
        }
    }

    public boolean isConfigured() {
        return BuildConfig.AI_ENDPOINT != null && !BuildConfig.AI_ENDPOINT.trim().isEmpty();
    }

    public void chat(User user, List<ChatMessage> history, Callback<String> callback) {
        if (!isConfigured()) {
            post(callback, null, new IllegalStateException("AI endpoint not configured"));
            return;
        }
        EXECUTOR.execute(() -> {
            try {
                String reply = requestCompletion(systemPrompt(user), history);
                post(callback, reply, null);
            } catch (Exception e) {
                post(callback, null, e);
            }
        });
    }

    private String systemPrompt(User user) {
        StringBuilder sb = new StringBuilder();
        sb.append("You are GymFit Coach, an experienced strength & conditioning coach ")
                .append("inside a gym fitness app. Be concise, motivating and practical. ")
                .append("Never give medical diagnoses; advise seeing a professional for pain or injury. ")
                .append("When proposing a weekly split, format EXACTLY like this so the app can import it:\n")
                .append("Recommended Split\n")
                .append("Monday\n<Workout Name>\n<Exercise 1> - <sets>x<reps>\n...\n")
                .append("Tuesday\nRest\n...\n")
                .append("(one line per day starting with the day name; 'Rest' means rest day).\n");
        if (user != null) {
            sb.append("\nAthlete profile: ");
            sb.append("goal=").append(orDefault(user.goal)).append("; ");
            sb.append("experience=").append(orDefault(user.experience)).append("; ");
            sb.append("days/week=").append(user.trainingDaysPerWeek).append("; ");
            sb.append("weight=").append(user.weightKg).append("kg; ");
            sb.append("height=").append(user.heightCm).append("cm; ");
            sb.append("gym=").append(orDefault(user.gymName)).append("; ");
            sb.append("streak=").append(user.currentStreak).append("d; ");
            sb.append("workouts total=").append(user.totalWorkouts).append("; ");
            sb.append("volume last 28d=").append(Math.round(user.volumeLast28Kg)).append("kg; ");
            sb.append("bench/squat/deadlift e1RM=")
                    .append(Math.round(user.bestBenchE1rm)).append('/')
                    .append(Math.round(user.bestSquatE1rm)).append('/')
                    .append(Math.round(user.bestDeadliftE1rm)).append("kg; ");
            sb.append("PRs last 30d=").append(user.prsLast30).append('.');
        }
        return sb.toString();
    }

    /** Builds the progress-analysis prompt from recent training data. */
    public String buildAnalysisPrompt(User user, List<Workout> recentWorkouts) {
        StringBuilder sb = new StringBuilder();
        sb.append("Analyze my training progress. Here is my recent data:\n");
        sb.append("- Goal: ").append(orDefault(user.goal))
                .append(", Experience: ").append(orDefault(user.experience)).append('\n');
        sb.append("- Workouts last 28 days: ").append(user.workoutsLast28)
                .append(" (planned ").append(user.trainingDaysPerWeek).append("/week)\n");
        sb.append("- Volume last 28 days: ").append(Math.round(user.volumeLast28Kg))
                .append(" kg, previous 28 days: ").append(Math.round(user.volumePrev28Kg)).append(" kg\n");
        sb.append("- PRs last 30 days: ").append(user.prsLast30).append('\n');
        sb.append("- Current streak: ").append(user.currentStreak).append(" days\n");
        sb.append("- Est. 1RMs — Bench: ").append(Math.round(user.bestBenchE1rm))
                .append(" kg, Squat: ").append(Math.round(user.bestSquatE1rm))
                .append(" kg, Deadlift: ").append(Math.round(user.bestDeadliftE1rm)).append(" kg\n");
        sb.append("- Recent workouts:\n");
        int count = 0;
        for (Workout w : recentWorkouts) {
            if (count++ >= 10) break;
            sb.append("  · ").append(w.name).append(" — ").append(w.durationMinutes)
                    .append(" min, ").append(Math.round(w.totalVolumeKg)).append(" kg, ")
                    .append(w.exerciseCount).append(" exercises, muscles: ")
                    .append(String.join(", ", w.muscleGroups)).append('\n');
        }
        sb.append("\nGive 4-6 concrete observations and 2-3 actionable recommendations. ")
                .append("Mention trends (frequency, volume, muscle-group balance, strength). ")
                .append("Do not provide medical diagnosis.");
        return sb.toString();
    }

    private String requestCompletion(String system, List<ChatMessage> history) throws Exception {
        JSONObject body = new JSONObject();
        body.put("model", BuildConfig.AI_MODEL == null || BuildConfig.AI_MODEL.isEmpty()
                ? "gpt-4o-mini" : BuildConfig.AI_MODEL);
        JSONArray messages = new JSONArray();
        messages.put(new JSONObject().put("role", "system").put("content", system));
        for (ChatMessage m : history) {
            messages.put(new JSONObject().put("role", m.role).put("content", m.content));
        }
        body.put("messages", messages);
        body.put("temperature", 0.7);
        body.put("max_tokens", 900);

        HttpURLConnection conn = (HttpURLConnection) new URL(BuildConfig.AI_ENDPOINT).openConnection();
        try {
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(20_000);
            conn.setReadTimeout(60_000);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");
            if (BuildConfig.AI_API_KEY != null && !BuildConfig.AI_API_KEY.isEmpty()) {
                conn.setRequestProperty("Authorization", "Bearer " + BuildConfig.AI_API_KEY);
            }
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code = conn.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
            String response = readAll(stream);
            if (code < 200 || code >= 300) {
                throw new IllegalStateException("AI request failed (HTTP " + code + ")");
            }
            JSONObject json = new JSONObject(response);
            return json.getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content");
        } finally {
            conn.disconnect();
        }
    }

    private String readAll(InputStream stream) throws Exception {
        StringBuilder sb = new StringBuilder();
        if (stream == null) return "";
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private void post(Callback<String> callback, String value, Exception error) {
        MAIN.post(() -> {
            if (error != null) callback.onError(error);
            else callback.onSuccess(value);
        });
    }

    private static String orDefault(String s) {
        return s == null || s.isEmpty() ? "not set" : s;
    }

    // ---- Split plan parsing ("ADD TO MY WORKOUT") ----

    private static final String[] DAYS = {
            "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"
    };

    /**
     * Parses the coach's structured split into WorkoutTemplates.
     * Returns an empty list when the reply contains no recognizable plan.
     */
    public static List<WorkoutTemplate> parseSplitPlan(String aiReply, String ownerUid) {
        List<WorkoutTemplate> plans = new ArrayList<>();
        if (aiReply == null) return plans;

        String[] lines = aiReply.split("\\r?\\n");
        WorkoutTemplate current = null;
        for (String raw : lines) {
            String line = stripMarkdown(raw).trim();
            if (line.isEmpty()) continue;
            String lower = line.toLowerCase(Locale.US);

            String day = matchDayPrefix(lower);
            if (day != null) {
                current = null;
                String rest = line.substring(day.length()).trim();
                rest = rest.replaceFirst("^[:,\\-–—]\\s*", "").trim();
                if (!rest.isEmpty() && !rest.toLowerCase(Locale.US).startsWith("rest")) {
                    current = new WorkoutTemplate(rest, "Custom", ownerUid, "ai");
                    current.orderIndex = dayIndex(day);
                    plans.add(current);
                }
                continue;
            }
            if (current == null) continue;
            if (lower.startsWith("rest")) continue;

            TemplateExercise ex = parseExerciseLine(line);
            if (ex != null) current.exercises.add(ex);
        }

        plans.removeIf(p -> p.exercises.isEmpty());
        return plans;
    }

    private static String stripMarkdown(String s) {
        return s.replaceAll("[*#`>]", "").trim();
    }

    private static String matchDayPrefix(String lowerLine) {
        for (String day : DAYS) {
            if (lowerLine.startsWith(day)) return day;
        }
        return null;
    }

    private static int dayIndex(String day) {
        for (int i = 0; i < DAYS.length; i++) {
            if (DAYS[i].equals(day)) return i;
        }
        return -1;
    }

    private static final Pattern SETS_REPS = Pattern.compile("(\\d+)\\s*[x×]\\s*(\\d+)");

    static TemplateExercise parseExerciseLine(String line) {
        String cleaned = stripMarkdown(line);
        cleaned = cleaned.replaceFirst("^\\d+[.)]\\s*", "");       // "1. Bench"
        cleaned = cleaned.replaceFirst("^[\\-–—•*]\\s*", "");        // bullet
        if (cleaned.isEmpty()) return null;

        int sets = 3;
        int reps = 10;
        Matcher m = SETS_REPS.matcher(cleaned);
        if (m.find()) {
            sets = Integer.parseInt(m.group(1));
            reps = Integer.parseInt(m.group(2));
            cleaned = cleaned.substring(0, m.start()).trim();
        }
        cleaned = cleaned.replaceAll("\\(.*?\\)", "").trim();
        cleaned = cleaned.replaceFirst("[,:\\-–—]\\s*$", "").trim();
        cleaned = cleaned.replaceAll("\\s*(to failure|AMRAP)$", "").trim();
        if (cleaned.isEmpty() || cleaned.length() > 60) return null;

        String muscle = com.gymfit.app.data.ExerciseCatalog.muscleGroupOf(cleaned);
        return new TemplateExercise(cleaned, muscle, Math.min(sets, 12), Math.min(reps, 50));
    }
}
