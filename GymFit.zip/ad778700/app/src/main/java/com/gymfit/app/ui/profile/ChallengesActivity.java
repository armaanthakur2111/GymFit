package com.gymfit.app.ui.profile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.repository.UserRepository;
import com.gymfit.app.data.service.AchievementService;
import com.gymfit.app.data.service.ChallengeService;
import com.gymfit.app.databinding.ActivityChallengesBinding;
import com.gymfit.app.databinding.ItemChallengeBinding;
import com.gymfit.app.util.DateUtils;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.UiUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Challenge catalog with join state, live progress and completion detection. */
public class ChallengesActivity extends AppCompatActivity {

    private ActivityChallengesBinding binding;
    private final ChallengeService service = new ChallengeService();
    private final AchievementService achievements = new AchievementService();
    private final UserRepository userRepo = new UserRepository();
    private final List<ChallengeService.ChallengeProgress> items = new ArrayList<>();
    private ChallengeAdapter adapter;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChallengesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.buttonBack.setOnClickListener(v -> finish());

        binding.recyclerChallenges.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ChallengeAdapter();
        binding.recyclerChallenges.setAdapter(adapter);

        if (!FirebaseState.isReady(this)) {
            binding.bannerFirebase.setVisibility(View.VISIBLE);
            binding.progressBar.setVisibility(View.GONE);
            return;
        }
        load();
    }

    private void load() {
        String uid = Session.uid();
        if (uid == null) {
            binding.progressBar.setVisibility(View.GONE);
            return;
        }
        binding.progressBar.setVisibility(View.VISIBLE);
        userRepo.getUser(uid, new Callback<User>() {
            @Override
            public void onSuccess(User result) {
                if (result == null || isFinishing()) return;
                user = result;
                Session.setProfile(result);
                loadProgress(result);
            }

            @Override
            public void onError(Exception e) {
                binding.progressBar.setVisibility(View.GONE);
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, ChallengesActivity.this));
            }
        });
    }

    private void loadProgress(User u) {
        service.getAllProgress(u, new Callback<List<ChallengeService.ChallengeProgress>>() {
            @Override
            public void onSuccess(List<ChallengeService.ChallengeProgress> result) {
                if (isFinishing()) return;
                items.clear();
                items.addAll(sort(result));
                adapter.notifyDataSetChanged();
                binding.progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onError(Exception e) {
                binding.progressBar.setVisibility(View.GONE);
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, ChallengesActivity.this));
            }
        });
    }

    private List<ChallengeService.ChallengeProgress> sort(List<ChallengeService.ChallengeProgress> in) {
        List<ChallengeService.ChallengeProgress> out = new ArrayList<>(in);
        Collections.sort(out, (a, b) -> Integer.compare(order(a), order(b)));
        return out;
    }

    private int order(ChallengeService.ChallengeProgress p) {
        if (p.completed) return 2;
        return p.joined ? 0 : 1;
    }

    private void join(ChallengeService.ChallengeProgress p) {
        if (user == null) return;
        service.join(user, p.challenge, new Callback<Void>() {
            @Override
            public void onSuccess(Void result) {
                UiUtils.snack(binding.getRoot(), getString(R.string.challenge_joined_toast));
                achievements.evaluate(user, 0, new Callback<List<String>>() {
                    @Override
                    public void onSuccess(List<String> ignored) {
                        load();
                    }

                    @Override
                    public void onError(Exception e) {
                        load();
                    }
                });
            }

            @Override
            public void onError(Exception e) {
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, ChallengesActivity.this));
            }
        });
    }

    private class ChallengeAdapter extends RecyclerView.Adapter<ChallengeHolder> {

        @NonNull
        @Override
        public ChallengeHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ItemChallengeBinding b = ItemChallengeBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false);
            return new ChallengeHolder(b);
        }

        @Override
        public void onBindViewHolder(@NonNull ChallengeHolder holder, int position) {
            ChallengeService.ChallengeProgress p = items.get(position);
            holder.binding.textTitle.setText(p.challenge.title);
            holder.binding.textDesc.setText(p.challenge.description);
            holder.binding.textMeta.setText(getString(R.string.challenge_progress, p.current, p.target)
                    + "  ·  " + getString(R.string.challenge_days, p.challenge.days));

            int progressPct = Math.round(p.fraction() * 100);
            holder.binding.progress.setProgressCompat(progressPct, false);

            if (p.completed) {
                holder.binding.textState.setText(R.string.challenge_complete);
                holder.binding.textState.setTextColor(ContextCompat.getColor(
                        ChallengesActivity.this, R.color.accent_green));
                holder.binding.buttonJoin.setVisibility(View.GONE);
            } else if (p.joined) {
                holder.binding.textState.setText(R.string.joined);
                holder.binding.textState.setTextColor(ContextCompat.getColor(
                        ChallengesActivity.this, R.color.accent));
                holder.binding.buttonJoin.setVisibility(View.GONE);
                if (p.deadline > 0) {
                    holder.binding.textMeta.setText(holder.binding.textMeta.getText()
                            + "  ·  " + getString(R.string.challenge_ends,
                            DateUtils.formatDate(p.deadline)));
                }
            } else {
                holder.binding.textState.setText("");
                holder.binding.progress.setProgressCompat(0, false);
                holder.binding.buttonJoin.setVisibility(View.VISIBLE);
                holder.binding.buttonJoin.setOnClickListener(v -> {
                    int pos = holder.getBindingAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) join(items.get(pos));
                });
            }
        }

        @Override
        public int getItemCount() {
            return items.size();
        }
    }

    private static class ChallengeHolder extends RecyclerView.ViewHolder {
        final ItemChallengeBinding binding;

        ChallengeHolder(ItemChallengeBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
