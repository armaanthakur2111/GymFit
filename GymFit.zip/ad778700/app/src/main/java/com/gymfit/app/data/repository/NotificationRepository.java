package com.gymfit.app.data.repository;

import com.google.firebase.firestore.DocumentSnapshot;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Db;
import com.gymfit.app.data.model.AppNotification;

import java.util.ArrayList;
import java.util.List;

/**
 * In-app notifications. Stored newest-first by document id (reversed timestamp
 * prefix) so "latest first" reads need no orderBy and no composite index.
 */
public class NotificationRepository {

    public static String reverseTimeId() {
        return (Long.MAX_VALUE - System.currentTimeMillis()) + "_" + System.nanoTime();
    }

    /** Fire-and-forget write used by other repositories to fan out events. */
    public static void push(String recipientUid, String type, String title, String body,
                            String actorId, String actorName, String linkId) {
        if (Db.notifications() == null || recipientUid == null) return;
        if (recipientUid.equals(actorId)) return; // no self-notifications
        AppNotification n = new AppNotification(recipientUid, type, title, body, actorId, actorName, linkId);
        Db.notifications().document(reverseTimeId()).set(n);
    }

    public void getNotifications(String uid, Callback<List<AppNotification>> callback) {
        if (Db.notifications() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.notifications().whereEqualTo("userId", uid).limit(100).get()
                .addOnSuccessListener(snapshot -> {
                    List<AppNotification> items = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot) {
                        AppNotification n = doc.toObject(AppNotification.class);
                        if (n != null) {
                            n.id = doc.getId();
                            items.add(n);
                        }
                    }
                    items.sort((a, b) -> Long.compare(b.createdAt, a.createdAt));
                    callback.onSuccess(items);
                })
                .addOnFailureListener(callback::onError);
    }

    public void markRead(String notificationId) {
        if (Db.notifications() != null) {
            Db.notifications().document(notificationId).update("read", true);
        }
    }

    public void markAllRead(String uid, List<AppNotification> items) {
        if (Db.notifications() == null) return;
        for (AppNotification n : items) {
            if (!n.read) {
                Db.notifications().document(n.id).update("read", true);
            }
        }
    }
}
