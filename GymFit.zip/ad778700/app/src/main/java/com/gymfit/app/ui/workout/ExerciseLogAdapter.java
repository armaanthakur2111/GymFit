package com.gymfit.app.ui.workout;

import android.annotation.SuppressLint;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ViewGroup;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.gymfit.app.R;
import com.gymfit.app.data.model.ExerciseEntry;
import com.gymfit.app.data.model.SetLog;
import com.gymfit.app.databinding.ItemExerciseLogBinding;
import com.gymfit.app.databinding.ItemSetRowBinding;

import java.util.List;
import java.util.Locale;

/**
 * Renders each exercise as a card whose set rows are built in place. The adapter
 * mutates the bound {@link ExerciseEntry} list directly, so the workout object
 * stays the single source of truth while the user logs.
 */
public class ExerciseLogAdapter extends RecyclerView.Adapter<ExerciseLogAdapter.ExerciseHolder> {

    public interface Listener {
        void onSetCompleted(ExerciseEntry entry, int setIndex);

        void onRemoveExercise(int position);

        void onStartDrag(ExerciseHolder holder);
    }

    private final List<ExerciseEntry> entries;
    private final Listener listener;

    public ExerciseLogAdapter(List<ExerciseEntry> entries, Listener listener) {
        this.entries = entries;
        this.listener = listener;
    }

    @Override
    public ExerciseHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        ItemExerciseLogBinding binding = ItemExerciseLogBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new ExerciseHolder(binding);
    }

    @Override
    public void onBindViewHolder(ExerciseHolder holder, int position) {
        holder.bind(entries.get(position), position);
    }

    @Override
    public int getItemCount() {
        return entries.size();
    }

    public class ExerciseHolder extends RecyclerView.ViewHolder {

        private final ItemExerciseLogBinding binding;

        ExerciseHolder(ItemExerciseLogBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressLint("ClickableViewAccessibility")
        void bind(ExerciseEntry entry, int position) {
            binding.textExerciseName.setText(entry.exerciseName);
            binding.textMuscleGroup.setText(entry.muscleGroup);

            binding.buttonDrag.setOnTouchListener((v, event) -> {
                if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    listener.onStartDrag(this);
                }
                return false;
            });

            binding.buttonRemove.setOnClickListener(v -> {
                int pos = getBindingAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) listener.onRemoveExercise(pos);
            });

            binding.buttonAddSet.setOnClickListener(v -> {
                int pos = getBindingAdapterPosition();
                if (pos == RecyclerView.NO_POSITION) return;
                ExerciseEntry e = entries.get(pos);
                int defaultReps = e.sets.isEmpty() ? 10 : e.sets.get(e.sets.size() - 1).reps;
                if (defaultReps <= 0) defaultReps = 10;
                e.sets.add(new SetLog(0, defaultReps));
                notifyItemChanged(pos);
            });

            binding.containerSets.removeAllViews();
            LayoutInflater inflater = LayoutInflater.from(binding.getRoot().getContext());
            for (int i = 0; i < entry.sets.size(); i++) {
                final int setIndex = i;
                final SetLog set = entry.sets.get(i);
                ItemSetRowBinding row = ItemSetRowBinding.inflate(inflater, binding.containerSets, false);

                row.textSetNumber.setText(String.valueOf(setIndex + 1));
                row.inputWeight.setText(set.weightKg > 0 ? trimNumber(set.weightKg) : "");
                row.inputReps.setText(set.reps > 0 ? String.valueOf(set.reps) : "");

                row.inputWeight.addTextChangedListener(new SimpleWatcher() {
                    @Override
                    public void afterTextChanged(Editable s) {
                        set.weightKg = parseDouble(s.toString());
                    }
                });
                row.inputReps.addTextChangedListener(new SimpleWatcher() {
                    @Override
                    public void afterTextChanged(Editable s) {
                        set.reps = (int) parseDouble(s.toString());
                    }
                });

                applyCompleteState(row, set.completed);
                row.buttonComplete.setOnClickListener(v -> {
                    set.completed = !set.completed;
                    applyCompleteState(row, set.completed);
                    if (set.completed) listener.onSetCompleted(entry, setIndex);
                });

                binding.containerSets.addView(row.getRoot());
            }
        }

        private void applyCompleteState(ItemSetRowBinding row, boolean completed) {
            row.buttonComplete.setActivated(completed);
            int tint = ContextCompat.getColor(row.getRoot().getContext(),
                    completed ? R.color.white : R.color.text_tertiary);
            row.buttonComplete.setColorFilter(tint);
        }
    }

    private static String trimNumber(double value) {
        if (value == Math.rint(value)) return String.format(Locale.US, "%d", (long) value);
        return String.format(Locale.US, "%.1f", value);
    }

    private static double parseDouble(String s) {
        try {
            return s == null || s.trim().isEmpty() ? 0 : Double.parseDouble(s.trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private abstract static class SimpleWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
    }
}
