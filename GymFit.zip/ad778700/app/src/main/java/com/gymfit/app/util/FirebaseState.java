package com.gymfit.app.util;

import android.content.Context;

import com.google.firebase.FirebaseApp;

/**
 * Central check for whether Firebase is usable in this build.
 * The app ships without google-services.json; every Firebase feature must
 * consult this and degrade gracefully instead of crashing.
 */
public final class FirebaseState {

    private FirebaseState() {
    }

    public static boolean isReady(Context context) {
        try {
            return !FirebaseApp.getApps(context.getApplicationContext()).isEmpty();
        } catch (Exception e) {
            return false;
        }
    }
}
