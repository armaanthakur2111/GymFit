package com.gymfit.app.ui.social;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.repository.FriendRepository;
import com.gymfit.app.data.repository.UserRepository;
import com.gymfit.app.databinding.ActivityUserSearchBinding;
import com.gymfit.app.databinding.ItemUserSearchBinding;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.UiUtils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Prefix search over public profiles with friend-request actions. */
public class UserSearchActivity extends AppCompatActivity {

    private ActivityUserSearchBinding binding;
    private final UserRepository userRepo = new UserRepository();
    private final FriendRepository friendRepo = new FriendRepository();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final List<User> results = new ArrayList<>();
    private final Set<String> friendIds = new HashSet<>();
    private final Set<String> sentIds = new HashSet<>();
    private ResultAdapter adapter;
    private Runnable pending;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUserSearchBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.buttonBack.setOnClickListener(v -> finish());

        binding.recyclerResults.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ResultAdapter();
        binding.recyclerResults.setAdapter(adapter);

        binding.inputSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
                if (pending != null) handler.removeCallbacks(pending);
                pending = () -> search(s.toString());
                handler.postDelayed(pending, 400);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        loadRelationships();
    }

    private void loadRelationships() {
        String uid = Session.uid();
        if (!FirebaseState.isReady(this) || uid == null) return;
        friendRepo.getFriendIds(uid, new Callback<List<String>>() {
            @Override
            public void onSuccess(List<String> ids) {
                friendIds.clear();
                if (ids != null) friendIds.addAll(ids);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onError(Exception e) {
            }
        });
        User me = Session.profile();
        if (me != null && me.sentRequestIds != null) sentIds.addAll(me.sentRequestIds);
    }

    private void search(String query) {
        String q = query == null ? "" : query.trim();
        if (!FirebaseState.isReady(this) || q.length() < 2) {
            results.clear();
            adapter.notifyDataSetChanged();
            binding.textEmpty.setText(R.string.search_users_hint);
            binding.textEmpty.setVisibility(View.VISIBLE);
            return;
        }
        String uid = Session.uid();
        userRepo.searchUsers(q, new Callback<List<User>>() {
            @Override
            public void onSuccess(List<User> users) {
                results.clear();
                if (users != null) {
                    for (User u : users) {
                        if (u.uid == null || u.uid.equals(uid)) continue;
                        if (!u.publicProfile) continue;
                        results.add(u);
                    }
                }
                adapter.notifyDataSetChanged();
                binding.textEmpty.setText(R.string.no_search_results);
                binding.textEmpty.setVisibility(results.isEmpty() ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onError(Exception e) {
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, UserSearchActivity.this));
            }
        });
    }

    private void sendRequest(User target) {
        User me = Session.profile();
        if (me == null) return;
        friendRepo.sendRequest(me, target.uid, new Callback<Void>() {
            @Override
            public void onSuccess(Void result) {
                sentIds.add(target.uid);
                userRepo.markRequestSent(me.uid, target.uid);
                if (me.sentRequestIds == null) me.sentRequestIds = new ArrayList<>();
                if (!me.sentRequestIds.contains(target.uid)) me.sentRequestIds.add(target.uid);
                Session.setProfile(me);
                adapter.notifyDataSetChanged();
                UiUtils.snack(binding.getRoot(), getString(R.string.requested));
            }

            @Override
            public void onError(Exception e) {
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, UserSearchActivity.this));
            }
        });
    }

    private class ResultAdapter extends RecyclerView.Adapter<ResultHolder> {
        @NonNull
        @Override
        public ResultHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ResultHolder(ItemUserSearchBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull ResultHolder holder, int position) {
            User u = results.get(position);
            holder.binding.textName.setText(u.name);
            List<String> meta = new ArrayList<>();
            if (u.goal != null && !u.goal.isEmpty()) meta.add(u.goal);
            if (u.gymName != null && !u.gymName.isEmpty()) meta.add(u.gymName);
            holder.binding.textMeta.setText(join(meta));
            UiUtils.loadAvatar(holder.binding.imageAvatar, u.photoUrl, u.name, holder.binding.textInitials);
            holder.binding.getRoot().setOnClickListener(v ->
                    startActivity(new Intent(UserSearchActivity.this, UserProfileActivity.class)
                            .putExtra(UserProfileActivity.EXTRA_UID, u.uid)));

            if (friendIds.contains(u.uid)) {
                holder.binding.buttonAction.setText(R.string.friends);
                holder.binding.buttonAction.setEnabled(false);
            } else if (sentIds.contains(u.uid)) {
                holder.binding.buttonAction.setText(R.string.requested);
                holder.binding.buttonAction.setEnabled(false);
            } else {
                holder.binding.buttonAction.setText(R.string.add_friend);
                holder.binding.buttonAction.setEnabled(true);
                holder.binding.buttonAction.setOnClickListener(v -> {
                    int pos = holder.getBindingAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) sendRequest(results.get(pos));
                });
            }
        }

        @Override
        public int getItemCount() {
            return results.size();
        }
    }

    private static class ResultHolder extends RecyclerView.ViewHolder {
        final ItemUserSearchBinding binding;

        ResultHolder(ItemUserSearchBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    private static String join(List<String> parts) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) sb.append("  ·  ");
            sb.append(parts.get(i));
        }
        return sb.toString();
    }
}
