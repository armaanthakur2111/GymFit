package com.gymfit.app.ui.progress;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.BodyWeightEntry;
import com.gymfit.app.data.model.ExerciseEntry;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.model.Workout;
import com.gymfit.app.data.repository.UserRepository;
import com.gymfit.app.data.repository.WorkoutRepository;
import com.gymfit.app.databinding.ActivityProgressBinding;
import com.gymfit.app.util.DateUtils;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.FormatUtils;
import com.gymfit.app.util.UiUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Progress analytics: body weight, weekly volume, big-three strength and muscle-group volume. */
public class ProgressActivity extends AppCompatActivity {

    private static final long DAY = 24L * 60 * 60 * 1000;
    private static final int WEEKS = 8;

    private ActivityProgressBinding binding;
    private final WorkoutRepository workoutRepo = new WorkoutRepository();
    private final UserRepository userRepo = new UserRepository();
    private List<Workout> workoutsDesc = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityProgressBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.buttonBack.setOnClickListener(v -> finish());

        bindStat(binding.statStreak.imageIcon, binding.statStreak.textValue, binding.statStreak.textLabel,
                R.drawable.ic_fire, "0", R.string.day_streak);
        bindStat(binding.statWorkouts.imageIcon, binding.statWorkouts.textValue, binding.statWorkouts.textLabel,
                R.drawable.ic_dumbbell, "0", R.string.total_workouts);
        bindStat(binding.statFrequency.imageIcon, binding.statFrequency.textValue, binding.statFrequency.textLabel,
                R.drawable.ic_clock, "0", R.string.workout_frequency);
        bindStat(binding.statVolume.imageIcon, binding.statVolume.textValue, binding.statVolume.textLabel,
                R.drawable.ic_volume, FormatUtils.compactKg(0), R.string.weekly_training_volume);

        styleLine(binding.chartWeight);
        styleLine(binding.chartStrength);
        styleBar(binding.chartVolume);
        styleBar(binding.chartMuscles);
        binding.chartStrength.getLegend().setEnabled(true);
        binding.chartStrength.getLegend().setTextColor(ContextCompat.getColor(this, R.color.text_secondary));

        loadStats();
        loadBodyWeight();
        loadWorkouts();
    }

    private void loadStats() {
        User u = Session.profile();
        if (u == null) return;
        binding.statStreak.textValue.setText(String.valueOf(u.currentStreak));
        binding.statWorkouts.textValue.setText(String.valueOf(u.totalWorkouts));
    }

    private void loadWorkouts() {
        String uid = Session.uid();
        if (!FirebaseState.isReady(this) || uid == null) return;
        workoutRepo.getUserWorkouts(uid, 200, new Callback<List<Workout>>() {
            @Override
            public void onSuccess(List<Workout> result) {
                workoutsDesc = result == null ? new ArrayList<>() : result;
                renderVolumeStats();
                renderWeeklyVolume();
                renderStrength();
                renderMuscles();
            }

            @Override
            public void onError(Exception e) {
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, ProgressActivity.this));
            }
        });
    }

    private void renderVolumeStats() {
        long now = System.currentTimeMillis();
        double weekVolume = 0;
        int workouts28 = 0;
        for (Workout w : workoutsDesc) {
            if (w.startTime >= now - 7 * DAY) weekVolume += w.totalVolumeKg;
            if (w.startTime >= now - 28 * DAY) workouts28++;
        }
        binding.statVolume.textValue.setText(FormatUtils.compactKg(weekVolume));
        binding.statFrequency.textValue.setText(
                String.format(Locale.US, "%.1f", workouts28 / 4.0));
    }

    private void renderWeeklyVolume() {
        long now = System.currentTimeMillis();
        long[] starts = new long[WEEKS];
        double[] vol = new double[WEEKS];
        for (int i = 0; i < WEEKS; i++) {
            starts[i] = DateUtils.startOfWeek(now - (long) (WEEKS - 1 - i) * 7 * DAY);
        }
        for (Workout w : workoutsDesc) {
            long ws = DateUtils.startOfWeek(w.startTime);
            for (int i = 0; i < WEEKS; i++) {
                if (ws == starts[i]) {
                    vol[i] += w.totalVolumeKg;
                    break;
                }
            }
        }
        List<BarEntry> entries = new ArrayList<>();
        for (int i = 0; i < WEEKS; i++) entries.add(new BarEntry(i, (float) vol[i]));
        BarDataSet set = new BarDataSet(entries, "");
        set.setColor(ContextCompat.getColor(this, R.color.accent));
        set.setDrawValues(false);
        BarData data = new BarData(set);
        data.setBarWidth(0.6f);
        binding.chartVolume.setData(data);
        final long[] fStarts = starts;
        binding.chartVolume.getXAxis().setValueFormatter(new ValueFormatter() {
            private final SimpleDateFormat fmt = new SimpleDateFormat("d/M", Locale.getDefault());
            @Override
            public String getFormattedValue(float value) {
                int idx = (int) value;
                if (idx < 0 || idx >= fStarts.length) return "";
                return fmt.format(new Date(fStarts[idx]));
            }
        });
        binding.chartVolume.invalidate();
    }

    private void renderStrength() {
        List<Workout> chrono = new ArrayList<>(workoutsDesc);
        Collections.reverse(chrono);

        Map<String, List<Entry>> series = new LinkedHashMap<>();
        series.put("Bench Press", new ArrayList<>());
        series.put("Squat", new ArrayList<>());
        series.put("Deadlift", new ArrayList<>());

        for (int i = 0; i < chrono.size(); i++) {
            Workout w = chrono.get(i);
            Map<String, Double> best = new HashMap<>();
            for (ExerciseEntry e : w.completedEntries()) {
                if (!series.containsKey(e.exerciseName)) continue;
                double e1rm = e.bestE1rm();
                Double cur = best.get(e.exerciseName);
                if (cur == null || e1rm > cur) best.put(e.exerciseName, e1rm);
            }
            for (Map.Entry<String, Double> en : best.entrySet()) {
                if (en.getValue() > 0) {
                    series.get(en.getKey()).add(new Entry(i, en.getValue().floatValue()));
                }
            }
        }

        LineData data = new LineData();
        addLine(data, series.get("Bench Press"), "Bench", R.color.accent);
        addLine(data, series.get("Squat"), "Squat", R.color.accent_blue);
        addLine(data, series.get("Deadlift"), "Deadlift", R.color.accent_green);
        binding.chartStrength.setData(data);
        binding.chartStrength.getXAxis().setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                int idx = (int) value;
                if (idx < 0 || idx >= chrono.size()) return "";
                return DateUtils.formatDayMonth(chrono.get(idx).startTime);
            }
        });
        binding.chartStrength.invalidate();
    }

    private void addLine(LineData data, List<Entry> points, String label, int colorRes) {
        if (points == null || points.isEmpty()) return;
        LineDataSet set = new LineDataSet(points, label);
        int color = ContextCompat.getColor(this, colorRes);
        set.setColor(color);
        set.setCircleColor(color);
        set.setLineWidth(2.5f);
        set.setCircleRadius(3f);
        set.setDrawValues(false);
        set.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        data.addDataSet(set);
    }

    private void renderMuscles() {
        long cutoff = System.currentTimeMillis() - 28 * DAY;
        Map<String, Double> totals = new HashMap<>();
        for (Workout w : workoutsDesc) {
            if (w.startTime < cutoff) continue;
            for (ExerciseEntry e : w.completedEntries()) {
                String mg = (e.muscleGroup == null || e.muscleGroup.isEmpty()) ? "Other" : e.muscleGroup;
                Double cur = totals.get(mg);
                totals.put(mg, (cur == null ? 0 : cur) + e.volume());
            }
        }
        List<Map.Entry<String, Double>> sorted = new ArrayList<>(totals.entrySet());
        sorted.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));
        if (sorted.size() > 8) sorted = sorted.subList(0, 8);

        final List<String> labels = new ArrayList<>();
        List<BarEntry> entries = new ArrayList<>();
        for (int i = 0; i < sorted.size(); i++) {
            labels.add(sorted.get(i).getKey());
            entries.add(new BarEntry(i, sorted.get(i).getValue().floatValue()));
        }
        BarDataSet set = new BarDataSet(entries, "");
        set.setColor(ContextCompat.getColor(this, R.color.accent_gold));
        set.setDrawValues(false);
        BarData data = new BarData(set);
        data.setBarWidth(0.6f);
        binding.chartMuscles.setData(data);
        binding.chartMuscles.getXAxis().setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                int idx = (int) value;
                return idx >= 0 && idx < labels.size() ? labels.get(idx) : "";
            }
        });
        binding.chartMuscles.invalidate();
    }

    private void loadBodyWeight() {
        String uid = Session.uid();
        if (!FirebaseState.isReady(this) || uid == null) return;
        userRepo.getBodyWeights(uid, new Callback<List<BodyWeightEntry>>() {
            @Override
            public void onSuccess(List<BodyWeightEntry> entries) {
                if (entries == null || entries.isEmpty()) return;
                List<Entry> points = new ArrayList<>();
                for (int i = 0; i < entries.size(); i++) {
                    points.add(new Entry(i, (float) entries.get(i).weightKg));
                }
                LineDataSet set = new LineDataSet(points, "");
                set.setColor(ContextCompat.getColor(ProgressActivity.this, R.color.accent));
                set.setCircleColor(ContextCompat.getColor(ProgressActivity.this, R.color.accent));
                set.setLineWidth(2.5f);
                set.setCircleRadius(3f);
                set.setDrawValues(false);
                set.setMode(LineDataSet.Mode.CUBIC_BEZIER);
                binding.chartWeight.setData(new LineData(set));
                binding.chartWeight.getXAxis().setValueFormatter(new ValueFormatter() {
                    @Override
                    public String getFormattedValue(float value) {
                        int idx = (int) value;
                        if (idx < 0 || idx >= entries.size()) return "";
                        return DateUtils.formatDayMonth(entries.get(idx).recordedAt);
                    }
                });
                binding.chartWeight.invalidate();
            }

            @Override
            public void onError(Exception e) {
                // Non-fatal: chart simply stays empty.
            }
        });
    }

    private void styleLine(LineChart chart) {
        int tertiary = ContextCompat.getColor(this, R.color.text_tertiary);
        int grid = ContextCompat.getColor(this, R.color.bg_card_alt);
        chart.getDescription().setEnabled(false);
        chart.getLegend().setEnabled(false);
        chart.setDrawGridBackground(false);
        chart.setScaleEnabled(false);
        chart.setPinchZoom(false);
        chart.getAxisRight().setEnabled(false);
        XAxis x = chart.getXAxis();
        x.setPosition(XAxis.XAxisPosition.BOTTOM);
        x.setDrawGridLines(false);
        x.setTextColor(tertiary);
        x.setGranularity(1f);
        chart.getAxisLeft().setTextColor(tertiary);
        chart.getAxisLeft().setGridColor(grid);
        chart.getAxisLeft().setSpaceTop(15f);
        chart.getAxisLeft().setSpaceBottom(15f);
    }

    private void styleBar(BarChart chart) {
        int tertiary = ContextCompat.getColor(this, R.color.text_tertiary);
        int grid = ContextCompat.getColor(this, R.color.bg_card_alt);
        chart.getDescription().setEnabled(false);
        chart.getLegend().setEnabled(false);
        chart.setDrawGridBackground(false);
        chart.setScaleEnabled(false);
        chart.setPinchZoom(false);
        chart.getAxisRight().setEnabled(false);
        XAxis x = chart.getXAxis();
        x.setPosition(XAxis.XAxisPosition.BOTTOM);
        x.setDrawGridLines(false);
        x.setTextColor(tertiary);
        x.setGranularity(1f);
        chart.getAxisLeft().setTextColor(tertiary);
        chart.getAxisLeft().setGridColor(grid);
        chart.getAxisLeft().setAxisMinimum(0f);
    }

    private void bindStat(ImageView icon, TextView value, TextView label,
                          int iconRes, String valueText, int labelRes) {
        icon.setImageResource(iconRes);
        value.setText(valueText);
        label.setText(labelRes);
    }
}
