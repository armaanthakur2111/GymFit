package com.gymfit.app.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.google.firebase.firestore.DocumentSnapshot;
import com.gymfit.app.R;
import com.gymfit.app.data.Db;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.ActivityPost;
import com.gymfit.app.data.model.BodyWeightEntry;
import com.gymfit.app.data.model.ExerciseEntry;
import com.gymfit.app.data.model.PersonalRecord;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.model.Workout;
import com.gymfit.app.data.model.WorkoutTemplate;
import com.gymfit.app.data.repository.FriendRepository;
import com.gymfit.app.data.repository.SocialRepository;
import com.gymfit.app.data.repository.UserRepository;
import com.gymfit.app.data.repository.WorkoutRepository;
import com.gymfit.app.databinding.FragmentHomeBinding;
import com.gymfit.app.databinding.ItemActivityFeedBinding;
import com.gymfit.app.databinding.ItemPrRowBinding;
import com.gymfit.app.databinding.ItemRecentWorkoutBinding;
import com.gymfit.app.ui.bodyweight.BodyWeightActivity;
import com.gymfit.app.ui.notifications.NotificationsActivity;
import com.gymfit.app.ui.profile.ProfileActivity;
import com.gymfit.app.ui.progress.ProgressActivity;
import com.gymfit.app.ui.workout.ActiveWorkout;
import com.gymfit.app.ui.workout.ActiveWorkoutActivity;
import com.gymfit.app.ui.workout.WorkoutDetailActivity;
import com.gymfit.app.ui.workout.WorkoutHistoryActivity;
import com.gymfit.app.util.DateUtils;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.FormatUtils;
import com.gymfit.app.util.UiUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Primary dashboard: greeting, today's workout, stats, goal, weight, weekly chart, PRs, activity. */
public class HomeFragment extends Fragment {

    private static final long DAY = 24L * 60 * 60 * 1000;

    private FragmentHomeBinding binding;
    private final UserRepository userRepo = new UserRepository();
    private final WorkoutRepository workoutRepo = new WorkoutRepository();
    private final FriendRepository friendRepo = new FriendRepository();
    private final SocialRepository socialRepo = new SocialRepository();

    private String uid;
    private WorkoutTemplate suggestedTemplate;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        uid = Session.uid();

        setupStatic();
        setupChart();
        binding.textGreeting.setText(DateUtils.greeting());

        if (uid == null) {
            return;
        }
        if (!FirebaseState.isReady(requireContext())) {
            binding.bannerFirebase.setVisibility(View.VISIBLE);
            bindOfflineDefaults();
            return;
        }
        binding.bannerFirebase.setVisibility(View.GONE);

        watchProfile();
        loadWorkouts();
        loadPrs();
        loadBodyWeight();
        loadFriendActivity();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (binding != null) {
            updateTodayWorkout();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void setupStatic() {
        binding.statStreak.imageIcon.setImageResource(R.drawable.ic_fire);
        binding.statStreak.textLabel.setText(R.string.day_streak);
        binding.statStreak.textValue.setText("0");

        binding.statVolume.imageIcon.setImageResource(R.drawable.ic_volume);
        binding.statVolume.textLabel.setText(R.string.total_volume);
        binding.statVolume.textValue.setText(FormatUtils.compactKg(0));

        binding.statTime.imageIcon.setImageResource(R.drawable.ic_clock);
        binding.statTime.textLabel.setText(R.string.active_time);
        binding.statTime.textValue.setText(FormatUtils.duration(0));

        binding.statWorkouts.imageIcon.setImageResource(R.drawable.ic_dumbbell);
        binding.statWorkouts.textLabel.setText(R.string.workouts);
        binding.statWorkouts.textValue.setText("0");

        binding.buttonNotifications.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), NotificationsActivity.class)));

        View avatarArea = binding.imageAvatar;
        avatarArea.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), ProfileActivity.class)));
        binding.textAvatarInitials.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), ProfileActivity.class)));

        binding.buttonViewProgress.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), ProgressActivity.class)));
        binding.buttonViewHistory.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), WorkoutHistoryActivity.class)));
        binding.cardBodyWeight.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), BodyWeightActivity.class)));

        binding.buttonContinue.setOnClickListener(v -> onContinueClicked());

        updateTodayWorkout();
    }

    private void onContinueClicked() {
        if (ActiveWorkout.isActive()) {
            startActivity(new Intent(requireContext(), ActiveWorkoutActivity.class));
            return;
        }
        if (suggestedTemplate != null) {
            ActiveWorkout.startFromTemplate(suggestedTemplate);
        } else {
            ActiveWorkout.startEmpty("Free Workout");
        }
        startActivity(new Intent(requireContext(), ActiveWorkoutActivity.class));
    }

    private void bindOfflineDefaults() {
        User cached = Session.profile();
        String name = cached != null ? cached.firstName() : "Athlete";
        binding.textName.setText(name);
        UiUtils.loadAvatar(binding.imageAvatar, cached == null ? null : cached.photoUrl,
                name, binding.textAvatarInitials);
        binding.textTodayWorkout.setText(R.string.start_workout);
        binding.textTodayProgress.setText(R.string.no_workouts_hint);
        binding.progressToday.setProgress(0);
        binding.buttonContinue.setText(R.string.start_workout);
        binding.textGoal.setText(R.string.goal);
        binding.textGoalProgress.setText("0%");
        binding.textWeight.setText(FormatUtils.kg(0));
        binding.textWeightTrend.setText(R.string.weight_trend);
        binding.textEmptyPrs.setVisibility(View.VISIBLE);
        binding.textEmptyRecent.setVisibility(View.VISIBLE);
        binding.textEmptyFriends.setVisibility(View.VISIBLE);
        emptyChart();
    }

    private void watchProfile() {
        userRepo.watchUser(uid, new com.gymfit.app.data.Callback<User>() {
            @Override
            public void onSuccess(User user) {
                if (user == null || binding == null || !isAdded()) return;
                Session.setProfile(user);
                bindProfile(user);
            }

            @Override
            public void onError(Exception e) {
                User cached = Session.profile();
                if (cached != null && binding != null && isAdded()) bindProfile(cached);
            }
        });
        loadTemplates();
    }

    private void loadTemplates() {
        workoutRepo.getTemplates(uid, new com.gymfit.app.data.Callback<List<WorkoutTemplate>>() {
            @Override
            public void onSuccess(List<WorkoutTemplate> result) {
                if (binding == null || !isAdded()) return;
                if (result != null && !result.isEmpty()) {
                    suggestedTemplate = result.get(0);
                }
                updateTodayWorkout();
            }

            @Override
            public void onError(Exception e) {
                updateTodayWorkout();
            }
        });
    }

    private void bindProfile(User user) {
        binding.textName.setText(user.firstName());
        UiUtils.loadAvatar(binding.imageAvatar, user.photoUrl, user.name, binding.textAvatarInitials);

        binding.statStreak.textValue.setText(String.valueOf(user.currentStreak));
        binding.statVolume.textValue.setText(FormatUtils.compactKg(user.totalVolumeKg));

        String goal = (user.goal == null || user.goal.trim().isEmpty())
                ? getString(R.string.goal) : user.goal;
        binding.textGoal.setText(goal);
        int goalPct = goalProgress(user);
        binding.textGoalProgress.setText(goalPct + "%");
        binding.progressGoal.setProgress(goalPct);

        if (user.weightKg > 0) {
            binding.textWeight.setText(FormatUtils.kg(user.weightKg));
        }
    }

    /** Transparent "on track" measure: recent sessions vs. the planned weekly frequency. */
    private int goalProgress(User user) {
        double planned = user.trainingDaysPerWeek > 0 ? user.trainingDaysPerWeek * 4.0 : 16.0;
        double fraction = Math.max(0, Math.min(1, user.workoutsLast28 / planned));
        return (int) Math.round(fraction * 100);
    }

    private void updateTodayWorkout() {
        if (binding == null) return;
        if (ActiveWorkout.isActive()) {
            Workout w = ActiveWorkout.get();
            int total = w.entries.size();
            int done = 0;
            for (ExerciseEntry e : w.entries) {
                if (e.hasCompletedSets()) done++;
            }
            binding.textTodayWorkout.setText(w.name);
            binding.textTodayProgress.setText(getString(R.string.exercises_completed, done, total));
            binding.progressToday.setProgress(total > 0 ? done * 100 / total : 0);
            binding.buttonContinue.setText(R.string.continue_workout);
        } else {
            if (suggestedTemplate != null) {
                binding.textTodayWorkout.setText(suggestedTemplate.name);
                int count = suggestedTemplate.exercises.size();
                binding.textTodayProgress.setText(count + " " + getString(R.string.exercises));
            } else {
                binding.textTodayWorkout.setText(R.string.start_workout);
                binding.textTodayProgress.setText(R.string.no_workouts_hint);
            }
            binding.progressToday.setProgress(0);
            binding.buttonContinue.setText(R.string.start_workout);
        }
    }

    private void loadWorkouts() {
        workoutRepo.getUserWorkouts(uid, 60, new com.gymfit.app.data.Callback<List<Workout>>() {
            @Override
            public void onSuccess(List<Workout> history) {
                if (binding == null || !isAdded()) return;
                applyWorkoutStats(history == null ? new ArrayList<>() : history);
            }

            @Override
            public void onError(Exception e) {
                if (binding == null || !isAdded()) return;
                applyWorkoutStats(new ArrayList<>());
                binding.textEmptyRecent.setVisibility(View.VISIBLE);
            }
        });
    }

    private void applyWorkoutStats(List<Workout> history) {
        long now = System.currentTimeMillis();
        long weekAgo = now - 7 * DAY;
        long monthAgo = now - 30 * DAY;

        double[] daily = new double[7];
        long activeMinutesWeek = 0;
        int workoutsMonth = 0;

        for (Workout w : history) {
            if (w.startTime >= weekAgo) {
                activeMinutesWeek += w.durationMinutes;
                int idx = DateUtils.daysBetween(DateUtils.startOfDay(w.startTime), DateUtils.startOfDay(now));
                if (idx >= 0 && idx < 7) {
                    daily[6 - idx] += w.totalVolumeKg;
                }
            }
            if (w.startTime >= monthAgo) {
                workoutsMonth++;
            }
        }

        binding.statTime.textValue.setText(FormatUtils.duration(activeMinutesWeek));
        binding.statWorkouts.textValue.setText(String.valueOf(workoutsMonth));

        populateChart(daily);

        binding.containerRecent.removeAllViews();
        int shown = 0;
        for (Workout w : history) {
            if (shown >= 3) break;
            ItemRecentWorkoutBinding rb = ItemRecentWorkoutBinding.inflate(
                    getLayoutInflater(), binding.containerRecent, false);
            rb.textName.setText(w.name);
            String meta = DateUtils.formatDayMonth(w.startTime) + " · "
                    + FormatUtils.duration(w.durationMinutes) + " · "
                    + w.exerciseCount + " " + getString(R.string.exercises);
            rb.textMeta.setText(meta);
            rb.textVolume.setText(FormatUtils.compactKg(w.totalVolumeKg));
            final String workoutId = w.id;
            rb.getRoot().setOnClickListener(v -> {
                Intent i = new Intent(requireContext(), WorkoutDetailActivity.class);
                i.putExtra("workoutId", workoutId);
                startActivity(i);
            });
            binding.containerRecent.addView(rb.getRoot());
            shown++;
        }
        binding.textEmptyRecent.setVisibility(history.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void loadPrs() {
        if (Db.personalRecords() == null) {
            binding.textEmptyPrs.setVisibility(View.VISIBLE);
            return;
        }
        Db.personalRecords().whereEqualTo("userId", uid).limit(60).get()
                .addOnSuccessListener(snapshot -> {
                    if (binding == null || !isAdded()) return;
                    List<PersonalRecord> prs = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot) {
                        PersonalRecord pr = doc.toObject(PersonalRecord.class);
                        if (pr != null) prs.add(pr);
                    }
                    prs.sort((a, b) -> Long.compare(b.achievedAt, a.achievedAt));

                    binding.containerPrs.removeAllViews();
                    int shown = 0;
                    for (PersonalRecord pr : prs) {
                        if (shown >= 3) break;
                        ItemPrRowBinding pb = ItemPrRowBinding.inflate(
                                getLayoutInflater(), binding.containerPrs, false);
                        pb.textExercise.setText(pr.exerciseName);
                        pb.textType.setText(pr.typeLabel());
                        pb.textValue.setText(PersonalRecord.TYPE_REPS.equals(pr.type)
                                ? ((int) pr.value + " reps") : FormatUtils.kg(pr.value));
                        binding.containerPrs.addView(pb.getRoot());
                        shown++;
                    }
                    binding.textEmptyPrs.setVisibility(prs.isEmpty() ? View.VISIBLE : View.GONE);
                })
                .addOnFailureListener(e -> {
                    if (binding != null && isAdded()) binding.textEmptyPrs.setVisibility(View.VISIBLE);
                });
    }

    private void loadBodyWeight() {
        userRepo.getBodyWeights(uid, new com.gymfit.app.data.Callback<List<BodyWeightEntry>>() {
            @Override
            public void onSuccess(List<BodyWeightEntry> entries) {
                if (binding == null || !isAdded()) return;
                if (entries == null || entries.isEmpty()) {
                    User u = Session.profile();
                    binding.textWeight.setText(u != null && u.weightKg > 0
                            ? FormatUtils.kg(u.weightKg) : FormatUtils.kg(0));
                    binding.textWeightTrend.setText(R.string.log_weight);
                    return;
                }
                BodyWeightEntry latest = entries.get(entries.size() - 1);
                binding.textWeight.setText(FormatUtils.kg(latest.weightKg));
                if (entries.size() >= 2) {
                    BodyWeightEntry prev = entries.get(entries.size() - 2);
                    double delta = latest.weightKg - prev.weightKg;
                    String sign = delta >= 0 ? "+" : "";
                    binding.textWeightTrend.setText(String.format(Locale.US, "%s%.1f kg", sign, delta));
                } else {
                    binding.textWeightTrend.setText(R.string.weight_trend);
                }
            }

            @Override
            public void onError(Exception e) {
                if (binding != null && isAdded()) binding.textWeightTrend.setText(R.string.weight_trend);
            }
        });
    }

    private void loadFriendActivity() {
        friendRepo.getFriendIds(uid, new com.gymfit.app.data.Callback<List<String>>() {
            @Override
            public void onSuccess(List<String> friendIds) {
                if (binding == null || !isAdded()) return;
                if (friendIds == null || friendIds.isEmpty()) {
                    binding.containerFriends.removeAllViews();
                    binding.textEmptyFriends.setVisibility(View.VISIBLE);
                    return;
                }
                socialRepo.getFeed(uid, friendIds, new com.gymfit.app.data.Callback<List<ActivityPost>>() {
                    @Override
                    public void onSuccess(List<ActivityPost> feed) {
                        if (binding == null || !isAdded()) return;
                        bindFriendActivity(feed, friendIds);
                    }

                    @Override
                    public void onError(Exception e) {
                        if (binding != null && isAdded()) binding.textEmptyFriends.setVisibility(View.VISIBLE);
                    }
                });
            }

            @Override
            public void onError(Exception e) {
                if (binding != null && isAdded()) binding.textEmptyFriends.setVisibility(View.VISIBLE);
            }
        });
    }

    private void bindFriendActivity(List<ActivityPost> feed, List<String> friendIds) {
        binding.containerFriends.removeAllViews();
        int shown = 0;
        for (ActivityPost post : feed) {
            if (shown >= 3) break;
            if (!friendIds.contains(post.userId)) continue;
            ItemActivityFeedBinding ab = ItemActivityFeedBinding.inflate(
                    getLayoutInflater(), binding.containerFriends, false);
            bindActivityCard(ab, post);
            binding.containerFriends.addView(ab.getRoot());
            shown++;
        }
        binding.textEmptyFriends.setVisibility(shown == 0 ? View.VISIBLE : View.GONE);
    }

    private void bindActivityCard(ItemActivityFeedBinding ab, ActivityPost post) {
        ab.textName.setText(post.userName);
        ab.textTime.setText(DateUtils.relativeTime(post.createdAt));
        ab.textActivity.setText(post.text);
        UiUtils.loadAvatar(ab.imageAvatar, post.userPhoto, post.userName, ab.textAvatarInitials);
        ab.imageTypeIcon.setImageResource(iconForActivity(post.type));

        if (post.workoutId != null && !post.workoutId.isEmpty()) {
            ab.layoutWorkoutInfo.setVisibility(View.VISIBLE);
            ab.textWorkoutName.setText(post.workoutName);
            ab.textWorkoutStats.setText(FormatUtils.compactKg(post.volumeKg) + " · "
                    + FormatUtils.duration(post.durationMinutes));
        } else {
            ab.layoutWorkoutInfo.setVisibility(View.GONE);
        }

        ab.textKudosCount.setText(String.valueOf(post.kudosCount));
        ab.textCommentCount.setText(String.valueOf(post.commentCount));
        applyKudosTint(ab, post.kudosByMe);

        ab.buttonKudos.setOnClickListener(v -> {
            User me = Session.profile();
            if (me == null) return;
            socialRepo.toggleKudos(me, post, new com.gymfit.app.data.Callback<Boolean>() {
                @Override
                public void onSuccess(Boolean liked) {
                    ab.textKudosCount.setText(String.valueOf(post.kudosCount));
                    applyKudosTint(ab, liked);
                }

                @Override
                public void onError(Exception e) {
                    UiUtils.snack(ab.getRoot(), UiUtils.friendlyError(e, requireContext()));
                }
            });
        });

        final String activityId = post.id;
        ab.buttonComments.setOnClickListener(v -> {
            Intent i = new Intent(requireContext(), com.gymfit.app.ui.social.CommentsActivity.class);
            i.putExtra("activityId", activityId);
            startActivity(i);
        });
    }

    private void applyKudosTint(ItemActivityFeedBinding ab, boolean liked) {
        int color = ContextCompat.getColor(requireContext(),
                liked ? R.color.accent : R.color.text_secondary);
        ab.imageKudos.setColorFilter(color);
        ab.textKudosCount.setTextColor(color);
    }

    private int iconForActivity(String type) {
        if (type == null) return R.drawable.ic_dumbbell;
        switch (type) {
            case ActivityPost.TYPE_PR: return R.drawable.ic_medal;
            case ActivityPost.TYPE_STREAK: return R.drawable.ic_fire;
            case ActivityPost.TYPE_JOINED: return R.drawable.ic_person;
            default: return R.drawable.ic_dumbbell;
        }
    }

    // ---- Weekly volume chart ----

    private void setupChart() {
        BarChart chart = binding.chartWeekly;
        chart.getDescription().setEnabled(false);
        chart.getLegend().setEnabled(false);
        chart.setDrawGridBackground(false);
        chart.setDrawBorders(false);
        chart.setScaleEnabled(false);
        chart.setDoubleTapToZoomEnabled(false);
        chart.setPinchZoom(false);
        chart.getAxisRight().setEnabled(false);

        int tertiary = ContextCompat.getColor(requireContext(), R.color.text_tertiary);
        XAxis xAxis = chart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setTextColor(tertiary);
        xAxis.setGranularity(1f);
        xAxis.setLabelCount(7);
        xAxis.setValueFormatter(new ValueFormatter() {
            private final SimpleDateFormat fmt = new SimpleDateFormat("EEE", Locale.getDefault());
            @Override
            public String getFormattedValue(float value) {
                long millis = System.currentTimeMillis() - (long) (6 - value) * DAY;
                return fmt.format(new Date(millis));
            }
        });

        com.github.mikephil.charting.components.YAxis left = chart.getAxisLeft();
        left.setTextColor(tertiary);
        left.setAxisMinimum(0f);
        left.setDrawGridLines(true);
        left.setGridColor(ContextCompat.getColor(requireContext(), R.color.bg_card_alt));
        emptyChart();
    }

    private void populateChart(double[] daily) {
        if (binding == null) return;
        List<BarEntry> entries = new ArrayList<>();
        for (int i = 0; i < daily.length; i++) {
            entries.add(new BarEntry(i, (float) daily[i]));
        }
        BarDataSet set = new BarDataSet(entries, "");
        set.setColor(ContextCompat.getColor(requireContext(), R.color.accent));
        set.setDrawValues(false);
        set.setHighlightEnabled(false);

        BarData data = new BarData(set);
        data.setBarWidth(0.6f);
        binding.chartWeekly.setData(data);
        binding.chartWeekly.invalidate();
    }

    private void emptyChart() {
        populateChart(new double[7]);
    }
}
