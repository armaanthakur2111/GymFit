package com.gymfit.app.data.model;

import java.util.ArrayList;
import java.util.List;

/** A workout split / plan. Stored in `workoutTemplates/{id}`. */
public class WorkoutTemplate {

    public String id;
    public String ownerId;        // uid, or "system" for built-in splits
    public String name;           // e.g. "Push Day"
    public String type;           // Push / Pull / Legs / Upper / Lower / Full Body / Bro Split / Custom
    public List<TemplateExercise> exercises = new ArrayList<>();
    public long createdAt;
    public String source;         // "builtin" | "user" | "ai"
    public int orderIndex;        // day-of-week hint for weekly plans (0 = none)

    public WorkoutTemplate() {
    }

    public WorkoutTemplate(String name, String type, String ownerId, String source) {
        this.name = name;
        this.type = type;
        this.ownerId = ownerId;
        this.source = source;
        this.createdAt = System.currentTimeMillis();
    }
}
