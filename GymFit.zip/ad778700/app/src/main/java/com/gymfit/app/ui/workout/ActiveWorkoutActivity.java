package com.gymfit.app.ui.workout;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.gymfit.app.R;
import com.gymfit.app.data.ExerciseCatalog;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.ExerciseEntry;
import com.gymfit.app.data.model.SetLog;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.model.Workout;
import com.gymfit.app.data.service.WorkoutCompletionService;
import com.gymfit.app.databinding.ActivityActiveWorkoutBinding;
import com.gymfit.app.util.DateUtils;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.UiUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Live workout logger: exercises, sets, weight/reps, rest timer, reorder, finish/cancel. */
public class ActiveWorkoutActivity extends AppCompatActivity implements ExerciseLogAdapter.Listener {

    private ActivityActiveWorkoutBinding binding;
    private Workout workout;
    private ExerciseLogAdapter adapter;
    private ItemTouchHelper touchHelper;

    private final Handler clock = new Handler(Looper.getMainLooper());
    private CountDownTimer restTimer;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateElapsed();
            clock.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityActiveWorkoutBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if (!ActiveWorkout.isActive()) {
            finish();
            return;
        }
        workout = ActiveWorkout.get();

        binding.textWorkoutName.setText(workout.name);
        setupRecycler();
        updateElapsed();
        updateEmptyState();

        binding.buttonCancel.setOnClickListener(v -> confirmDiscard());
        binding.buttonFinish.setOnClickListener(v -> confirmFinish());
        binding.buttonAddExercise.setOnClickListener(v -> openExercisePicker());
        binding.buttonSkipRest.setOnClickListener(v -> stopRest());
    }

    private void setupRecycler() {
        adapter = new ExerciseLogAdapter(workout.entries, this);
        binding.recyclerExercises.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerExercises.setAdapter(adapter);

        ItemTouchHelper.Callback callback = new ItemTouchHelper.SimpleCallback(
                ItemTouchHelper.UP | ItemTouchHelper.DOWN, 0) {
            @Override
            public boolean onMove(@NonNull RecyclerView rv, @NonNull RecyclerView.ViewHolder vh,
                                  @NonNull RecyclerView.ViewHolder target) {
                int from = vh.getBindingAdapterPosition();
                int to = target.getBindingAdapterPosition();
                if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) return false;
                Collections.swap(workout.entries, from, to);
                adapter.notifyItemMoved(from, to);
                return true;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder vh, int direction) {
            }
        };
        touchHelper = new ItemTouchHelper(callback);
        touchHelper.attachToRecyclerView(binding.recyclerExercises);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!ActiveWorkout.isActive()) {
            finish();
            return;
        }
        clock.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        clock.removeCallbacks(tick);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (restTimer != null) restTimer.cancel();
        clock.removeCallbacks(tick);
    }

    private void updateElapsed() {
        long elapsed = System.currentTimeMillis() - workout.startTime;
        binding.textElapsed.setText(formatElapsed(elapsed));
    }

    private String formatElapsed(long millis) {
        long totalSeconds = Math.max(0, millis / 1000);
        long h = totalSeconds / 3600;
        long m = (totalSeconds % 3600) / 60;
        long s = totalSeconds % 60;
        if (h > 0) return String.format(Locale.US, "%d:%02d:%02d", h, m, s);
        return String.format(Locale.US, "%02d:%02d", m, s);
    }

    private void updateEmptyState() {
        boolean empty = workout.entries.isEmpty();
        binding.textEmptyExercises.setVisibility(empty ? android.view.View.VISIBLE : android.view.View.GONE);
        binding.recyclerExercises.setVisibility(empty ? android.view.View.GONE : android.view.View.VISIBLE);
    }

    // ---- Exercise log callbacks ----

    @Override
    public void onSetCompleted(ExerciseEntry entry, int setIndex) {
        int seconds = setIndex < entry.sets.size() ? entry.sets.get(setIndex).restSeconds : 90;
        startRest(seconds > 0 ? seconds : 90);
    }

    @Override
    public void onRemoveExercise(int position) {
        if (position < 0 || position >= workout.entries.size()) return;
        workout.entries.remove(position);
        adapter.notifyItemRemoved(position);
        updateEmptyState();
    }

    @Override
    public void onStartDrag(ExerciseLogAdapter.ExerciseHolder holder) {
        if (touchHelper != null) touchHelper.startDrag(holder);
    }

    private void openExercisePicker() {
        ExercisePickerDialog.show(this, exercise -> {
            ExerciseEntry entry = new ExerciseEntry(exercise.name, exercise.muscleGroup);
            for (int i = 0; i < 3; i++) {
                entry.sets.add(new SetLog(0, 10));
            }
            workout.entries.add(entry);
            adapter.notifyItemInserted(workout.entries.size() - 1);
            updateEmptyState();
            binding.recyclerExercises.scrollToPosition(workout.entries.size() - 1);
        });
    }

    // ---- Rest timer ----

    private void startRest(int seconds) {
        if (restTimer != null) restTimer.cancel();
        binding.barRest.setVisibility(android.view.View.VISIBLE);
        restTimer = new CountDownTimer(seconds * 1000L, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                binding.textRest.setText(getString(R.string.rest_timer) + " · "
                        + DateUtils.formatCountdown(millisUntilFinished));
            }

            @Override
            public void onFinish() {
                binding.textRest.setText(R.string.content_desc_rest_done);
                stopRest();
            }
        }.start();
    }

    private void stopRest() {
        if (restTimer != null) {
            restTimer.cancel();
            restTimer = null;
        }
        binding.barRest.setVisibility(android.view.View.GONE);
    }

    // ---- Finish / cancel ----

    private void confirmDiscard() {
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.cancel_workout)
                .setMessage(R.string.discard_confirm_message)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.discard_workout, (d, w) -> {
                    ActiveWorkout.clear();
                    finish();
                })
                .show();
    }

    private void confirmFinish() {
        workout.recalculate();
        if (workout.totalSets == 0) {
            UiUtils.snack(binding.getRoot(), getString(R.string.no_workouts_hint));
            return;
        }
        User user = Session.profile();
        MaterialCheckBox share = (MaterialCheckBox) LayoutInflater.from(this)
                .inflate(R.layout.dialog_finish_workout, null);
        share.setChecked(user == null || user.showActivities);

        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.finish_workout)
                .setView(share)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.save_workout, (d, w) -> finishWorkout(share.isChecked()))
                .show();
    }

    private void finishWorkout(boolean share) {
        User user = Session.profile();
        workout.recalculate();

        if (!FirebaseState.isReady(this) || user == null) {
            ActiveWorkout.clear();
            WorkoutResult.last = WorkoutResult.of(workout, new ArrayList<>(), new ArrayList<>(), null);
            navigateAfterSave(false);
            return;
        }

        binding.buttonFinish.setEnabled(false);
        new WorkoutCompletionService().complete(this, user, workout, share,
                new com.gymfit.app.data.Callback<WorkoutCompletionService.Result>() {
                    @Override
                    public void onSuccess(WorkoutCompletionService.Result result) {
                        ActiveWorkout.clear();
                        WorkoutResult.last = WorkoutResult.of(result.workout, result.newPrs,
                                result.newBadges, result.updatedUser);
                        navigateAfterSave(result.newPrs != null && !result.newPrs.isEmpty());
                    }

                    @Override
                    public void onError(Exception e) {
                        binding.buttonFinish.setEnabled(true);
                        UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, ActiveWorkoutActivity.this));
                    }
                });
    }

    private void navigateAfterSave(boolean hasPrs) {
        Intent next = new Intent(this, hasPrs ? PrCelebrationActivity.class : WorkoutSummaryActivity.class);
        startActivity(next);
        finish();
    }
}
