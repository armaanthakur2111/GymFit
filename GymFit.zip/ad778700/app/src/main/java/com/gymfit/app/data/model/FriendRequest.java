package com.gymfit.app.data.model;

/** Friend request. Stored in `friendRequests/{id}`. */
public class FriendRequest {

    public static final String STATUS_PENDING = "pending";
    public static final String STATUS_ACCEPTED = "accepted";
    public static final String STATUS_REJECTED = "rejected";

    public String id;
    public String fromId;
    public String fromName;
    public String fromPhoto;
    public String toId;
    public String status = STATUS_PENDING;
    public long createdAt;

    public FriendRequest() {
    }
}
