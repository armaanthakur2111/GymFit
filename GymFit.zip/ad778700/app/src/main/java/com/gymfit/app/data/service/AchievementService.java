package com.gymfit.app.data.service;

import com.gymfit.app.data.Callback;
import com.gymfit.app.data.model.AppNotification;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.repository.NotificationRepository;
import com.gymfit.app.data.repository.UserRepository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Evaluates badge conditions against the refreshed user stats and persists newly earned badges. */
public class AchievementService {

    public void evaluate(User user, int newPrCount, Callback<List<String>> callback) {
        List<String> newlyEarned = new ArrayList<>();
        List<String> badges = user.earnedBadges == null ? new ArrayList<>() : new ArrayList<>(user.earnedBadges);

        check(badges, newlyEarned, AchievementDefs.FIRST_WORKOUT, user.totalWorkouts >= 1);
        check(badges, newlyEarned, AchievementDefs.FIRST_PR, user.totalPrs > 0 || newPrCount > 0);
        check(badges, newlyEarned, AchievementDefs.STREAK_7, user.currentStreak >= 7 || user.longestStreak >= 7);
        check(badges, newlyEarned, AchievementDefs.STREAK_30, user.currentStreak >= 30 || user.longestStreak >= 30);
        check(badges, newlyEarned, AchievementDefs.WORKOUTS_25, user.totalWorkouts >= 25);
        check(badges, newlyEarned, AchievementDefs.WORKOUTS_100, user.totalWorkouts >= 100);
        check(badges, newlyEarned, AchievementDefs.VOLUME_10K, user.totalVolumeKg >= 10_000);
        check(badges, newlyEarned, AchievementDefs.VOLUME_100K, user.totalVolumeKg >= 100_000);
        check(badges, newlyEarned, AchievementDefs.FIRST_CHALLENGE,
                user.joinedChallengesAt != null && !user.joinedChallengesAt.isEmpty());
        check(badges, newlyEarned, AchievementDefs.CHALLENGE_DONE,
                user.completedChallenges != null && !user.completedChallenges.isEmpty());

        if (newlyEarned.isEmpty()) {
            callback.onSuccess(Collections.emptyList());
            return;
        }

        user.earnedBadges = badges;
        Map<String, Object> fields = new HashMap<>();
        fields.put("earnedBadges", badges);
        new UserRepository().updateFields(user.uid, fields, new Callback<Void>() {
            @Override
            public void onSuccess(Void result) {
                for (String badgeId : newlyEarned) {
                    AchievementDefs.Badge badge = AchievementDefs.byId(badgeId);
                    if (badge != null) {
                        NotificationRepository.push(user.uid, AppNotification.TYPE_CHALLENGE,
                                "Achievement unlocked!", badge.title + " — " + badge.description,
                                null, null, badgeId);
                    }
                }
                callback.onSuccess(newlyEarned);
            }

            @Override
            public void onError(Exception e) {
                callback.onError(e);
            }
        });
    }

    private void check(List<String> badges, List<String> newlyEarned, String id, boolean condition) {
        if (condition && !badges.contains(id)) {
            badges.add(id);
            newlyEarned.add(id);
        }
    }
}
