package com.gymfit.app.ui.profile;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.repository.AuthRepository;
import com.gymfit.app.data.repository.UserRepository;
import com.gymfit.app.databinding.ActivitySettingsBinding;
import com.gymfit.app.databinding.ItemSwitchRowBinding;
import com.gymfit.app.ui.auth.LoginActivity;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.SessionManager;
import com.gymfit.app.util.UiUtils;

import java.util.HashMap;
import java.util.Map;

/** Notification preferences (local) and privacy switches (persisted on the user document). */
public class SettingsActivity extends AppCompatActivity {

    public static final String EXTRA_SECTION = "section";
    public static final String SECTION_PRIVACY = "privacy";
    public static final String SECTION_NOTIFICATIONS = "notifications";

    private ActivitySettingsBinding binding;
    private SessionManager session;
    private final UserRepository userRepo = new UserRepository();
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        session = new SessionManager(this);

        binding.buttonBack.setOnClickListener(v -> finish());
        buildNotificationRows();
        buildPrivacyRows();
        binding.buttonDelete.setOnClickListener(v -> confirmDelete());

        user = Session.profile();
        if (user == null) loadUser();
        else applyPrivacyState(user);

        String section = getIntent().getStringExtra(EXTRA_SECTION);
        if (SECTION_PRIVACY.equals(section)) {
            binding.scroll.post(() -> binding.scroll.smoothScrollTo(0, binding.labelPrivacy.getTop()));
        } else if (SECTION_NOTIFICATIONS.equals(section)) {
            binding.scroll.post(() -> binding.scroll.smoothScrollTo(0, binding.labelNotifications.getTop()));
        }
    }

    private void loadUser() {
        String uid = Session.uid();
        if (!FirebaseState.isReady(this) || uid == null) return;
        userRepo.getUser(uid, new Callback<User>() {
            @Override
            public void onSuccess(User result) {
                if (result == null || isFinishing()) return;
                user = result;
                Session.setProfile(result);
                applyPrivacyState(result);
            }

            @Override
            public void onError(Exception e) {
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, SettingsActivity.this));
            }
        });
    }

    private void buildNotificationRows() {
        LayoutInflater inflater = LayoutInflater.from(this);
        addSwitch(binding.containerNotifications, inflater, R.string.notify_social, R.string.notify_social_desc,
                session.notifySocial(), v -> session.setNotifySocial(v));
        addSwitch(binding.containerNotifications, inflater, R.string.notify_progress, R.string.notify_progress_desc,
                session.notifyProgress(), v -> session.setNotifyProgress(v));
        addSwitch(binding.containerNotifications, inflater, R.string.notify_workout, R.string.notify_workout_desc,
                session.notifyWorkout(), v -> session.setNotifyWorkout(v));
    }

    private void buildPrivacyRows() {
        LayoutInflater inflater = LayoutInflater.from(this);
        addPrivacySwitch(inflater, R.string.privacy_public, R.string.privacy_public_desc, "publicProfile");
        addPrivacySwitch(inflater, R.string.privacy_activity, R.string.privacy_activity_desc, "showActivities");
        addPrivacySwitch(inflater, R.string.privacy_leaderboard, R.string.privacy_leaderboard_desc, "showOnLeaderboard");
        addPrivacySwitch(inflater, R.string.privacy_gym, R.string.privacy_gym_desc, "showGymOnMap");
    }

    private void addPrivacySwitch(LayoutInflater inflater, int titleRes, int descRes, String field) {
        ItemSwitchRowBinding row = addSwitch(binding.containerPrivacy, inflater, titleRes, descRes,
                false, null);
        row.switchToggle.setTag(field);
        row.switchToggle.setOnCheckedChangeListener((b, checked) -> onPrivacyToggled(field, checked));
    }

    private void onPrivacyToggled(String field, boolean checked) {
        if (user == null) return;
        applyLocal(field, checked);
        if (!FirebaseState.isReady(this)) return;
        Map<String, Object> fields = new HashMap<>();
        fields.put(field, checked);
        userRepo.updateFields(user.uid, fields, new Callback<Void>() {
            @Override
            public void onSuccess(Void result) {
            }

            @Override
            public void onError(Exception e) {
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, SettingsActivity.this));
            }
        });
    }

    private void applyLocal(String field, boolean checked) {
        switch (field) {
            case "publicProfile": user.publicProfile = checked; break;
            case "showActivities": user.showActivities = checked; break;
            case "showOnLeaderboard": user.showOnLeaderboard = checked; break;
            case "showGymOnMap": user.showGymOnMap = checked; break;
            default: break;
        }
        Session.setProfile(user);
    }

    private void applyPrivacyState(User u) {
        setSwitch(binding.containerPrivacy, 0, u.publicProfile);
        setSwitch(binding.containerPrivacy, 1, u.showActivities);
        setSwitch(binding.containerPrivacy, 2, u.showOnLeaderboard);
        setSwitch(binding.containerPrivacy, 3, u.showGymOnMap);
    }

    private void setSwitch(LinearLayout container, int index, boolean checked) {
        View child = container.getChildAt(index);
        if (child == null) return;
        MaterialSwitch sw = child.findViewById(R.id.switchToggle);
        if (sw != null) sw.setChecked(checked);
    }

    private ItemSwitchRowBinding addSwitch(LinearLayout container, LayoutInflater inflater,
                                           int titleRes, int descRes, boolean checked,
                                           OnToggle listener) {
        ItemSwitchRowBinding row = ItemSwitchRowBinding.inflate(inflater, container, false);
        row.textTitle.setText(titleRes);
        row.textDesc.setVisibility(descRes == 0 ? View.GONE : View.VISIBLE);
        if (descRes != 0) row.textDesc.setText(descRes);
        row.switchToggle.setChecked(checked);
        if (listener != null) {
            row.switchToggle.setOnCheckedChangeListener((b, v) -> listener.onToggle(v));
        }
        container.addView(row.getRoot());
        return row;
    }

    private void confirmDelete() {
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.delete_account)
                .setMessage(R.string.delete_account_confirm)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.delete, (d, w) -> {
                    new AuthRepository().deleteAccount(new Callback<Void>() {
                        @Override
                        public void onSuccess(Void result) {
                            Session.clear();
                            Intent intent = new Intent(SettingsActivity.this, LoginActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                            finish();
                        }

                        @Override
                        public void onError(Exception e) {
                            UiUtils.snack(binding.getRoot(),
                                    UiUtils.friendlyError(e, SettingsActivity.this));
                        }
                    });
                })
                .show();
    }

    private interface OnToggle {
        void onToggle(boolean checked);
    }
}
