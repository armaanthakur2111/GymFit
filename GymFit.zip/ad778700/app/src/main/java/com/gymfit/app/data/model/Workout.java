package com.gymfit.app.data.model;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** A finished (or in-progress) workout. Stored in `workouts/{id}`. */
public class Workout {

    public String id;
    public String userId;
    public String name;              // e.g. "Push Day"
    public String type;              // Push / Pull / Legs / ... / Custom
    public String templateId;
    public long startTime;
    public long endTime;
    public int durationMinutes;
    public int exerciseCount;
    public int totalSets;
    public int totalReps;
    public double totalVolumeKg;
    public int prCount;
    public List<String> muscleGroups = new ArrayList<>();
    public List<ExerciseEntry> entries = new ArrayList<>();
    public boolean sharedToFeed;

    public Workout() {
    }

    /** Recompute aggregate fields from entries; call before saving. */
    public void recalculate() {
        exerciseCount = 0;
        totalSets = 0;
        totalReps = 0;
        totalVolumeKg = 0;
        Set<String> muscles = new LinkedHashSet<>();
        for (ExerciseEntry e : entries) {
            if (!e.hasCompletedSets()) continue;
            exerciseCount++;
            totalSets += e.completedSets();
            totalReps += e.totalReps();
            totalVolumeKg += e.volume();
            if (e.muscleGroup != null && !e.muscleGroup.isEmpty()) {
                muscles.add(e.muscleGroup);
            }
        }
        muscleGroups = new ArrayList<>(muscles);
        durationMinutes = (int) Math.max(1, (endTime - startTime) / 60000);
    }

    public List<ExerciseEntry> completedEntries() {
        List<ExerciseEntry> result = new ArrayList<>();
        for (ExerciseEntry e : entries) {
            if (e.hasCompletedSets()) result.add(e);
        }
        return result;
    }
}
