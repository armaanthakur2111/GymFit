package com.gymfit.app.data.model;

/** One logged set inside an exercise entry. */
public class SetLog {

    public double weightKg;
    public int reps;
    public boolean completed;
    public int restSeconds = 90;

    public SetLog() {
    }

    public SetLog(double weightKg, int reps) {
        this.weightKg = weightKg;
        this.reps = reps;
    }

    public double volume() {
        return weightKg * reps;
    }

    /** Epley estimated one-rep max. */
    public double estimated1Rm() {
        if (reps <= 0 || weightKg <= 0) return 0;
        if (reps == 1) return weightKg;
        return weightKg * (1 + reps / 30.0);
    }
}
