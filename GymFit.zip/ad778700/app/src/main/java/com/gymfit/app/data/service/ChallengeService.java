package com.gymfit.app.data.service;

import com.google.firebase.firestore.DocumentSnapshot;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Db;
import com.gymfit.app.data.model.AppNotification;
import com.gymfit.app.data.model.Challenge;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.model.Workout;
import com.gymfit.app.data.repository.NotificationRepository;
import com.gymfit.app.data.repository.UserRepository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Join state, progress computation and completion detection for challenges. */
public class ChallengeService {

    public static class ChallengeProgress {
        public final Challenge challenge;
        public final boolean joined;
        public final boolean completed;
        public final int current;
        public final int target;
        public final long deadline;

        ChallengeProgress(Challenge c, boolean joined, boolean completed,
                          int current, int target, long deadline) {
            this.challenge = c;
            this.joined = joined;
            this.completed = completed;
            this.current = Math.min(current, target);
            this.target = target;
            this.deadline = deadline;
        }

        public float fraction() {
            return target == 0 ? 0 : Math.min(1f, current / (float) target);
        }
    }

    private static final long DAY = 24L * 60 * 60 * 1000;

    public void join(User user, Challenge challenge, Callback<Void> callback) {
        Map<String, Long> joined = user.joinedChallengesAt == null
                ? new HashMap<>() : new HashMap<>(user.joinedChallengesAt);
        joined.put(challenge.id, System.currentTimeMillis());
        user.joinedChallengesAt = joined;

        Map<String, Object> fields = new HashMap<>();
        fields.put("joinedChallengesAt", joined);
        new UserRepository().updateFields(user.uid, fields, callback);
    }

    /** Computes progress for every challenge in the catalog. */
    public void getAllProgress(User user, Callback<List<ChallengeProgress>> callback) {
        List<Challenge> catalog = new ArrayList<>();
        java.util.Collections.addAll(catalog, Challenge.catalog());

        long earliestJoin = Long.MAX_VALUE;
        if (user.joinedChallengesAt != null) {
            for (Long t : user.joinedChallengesAt.values()) {
                earliestJoin = Math.min(earliestJoin, t);
            }
        }
        if (earliestJoin == Long.MAX_VALUE || Db.workouts() == null) {
            callback.onSuccess(staticProgress(user, catalog));
            return;
        }

        // Single-field query; date window filtered client-side.
        Db.workouts().whereEqualTo("userId", user.uid).limit(300).get()
                .addOnSuccessListener(snapshot -> {
                    List<Workout> workouts = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot) {
                        Workout w = doc.toObject(Workout.class);
                        if (w != null) workouts.add(w);
                    }
                    countPrs(user, catalog, workouts, callback);
                })
                .addOnFailureListener(e -> callback.onSuccess(staticProgress(user, catalog)));
    }

    private void countPrs(User user, List<Challenge> catalog, List<Workout> workouts,
                          Callback<List<ChallengeProgress>> callback) {
        if (Db.personalRecords() == null) {
            callback.onSuccess(compute(user, catalog, workouts, 0));
            return;
        }
        Db.personalRecords().whereEqualTo("userId", user.uid).limit(500).get()
                .addOnSuccessListener(snapshot -> {
                    int prsLast30 = 0;
                    long cutoff = System.currentTimeMillis() - 30 * DAY;
                    int prsSinceJoin = 0;
                    long join = earliestJoin(user);
                    for (DocumentSnapshot doc : snapshot) {
                        Long achieved = doc.getLong("achievedAt");
                        long t = achieved == null ? 0 : achieved;
                        Double prev = doc.getDouble("previousValue");
                        boolean isBaseline = prev != null && prev <= 0;
                        if (isBaseline) continue;
                        if (t >= cutoff) prsLast30++;
                        if (t >= join) prsSinceJoin++;
                    }
                    callback.onSuccess(compute(user, catalog, workouts, prsSinceJoin));
                })
                .addOnFailureListener(e -> callback.onSuccess(compute(user, catalog, workouts, 0)));
    }

    private long earliestJoin(User user) {
        long earliest = Long.MAX_VALUE;
        if (user.joinedChallengesAt != null) {
            for (Long t : user.joinedChallengesAt.values()) earliest = Math.min(earliest, t);
        }
        return earliest == Long.MAX_VALUE ? System.currentTimeMillis() : earliest;
    }

    private List<ChallengeProgress> staticProgress(User user, List<Challenge> catalog) {
        return compute(user, catalog, new ArrayList<>(), 0);
    }

    private List<ChallengeProgress> compute(User user, List<Challenge> catalog,
                                            List<Workout> workouts, int prsSinceJoin) {
        List<ChallengeProgress> result = new ArrayList<>();
        for (Challenge c : catalog) {
            Long joinedAt = user.joinedChallengesAt == null ? null : user.joinedChallengesAt.get(c.id);
            boolean joined = joinedAt != null;
            boolean completed = user.completedChallenges != null && user.completedChallenges.contains(c.id);
            int current = 0;
            if (joined) {
                long deadline = joinedAt + c.days * DAY;
                switch (c.metric) {
                    case Challenge.METRIC_WORKOUTS:
                        for (Workout w : workouts) {
                            if (w.startTime >= joinedAt && w.startTime <= deadline) current++;
                        }
                        break;
                    case Challenge.METRIC_VOLUME:
                        double vol = 0;
                        for (Workout w : workouts) {
                            if (w.startTime >= joinedAt && w.startTime <= deadline) vol += w.totalVolumeKg;
                        }
                        current = (int) vol;
                        break;
                    case Challenge.METRIC_PRS:
                        current = prsSinceJoin;
                        break;
                    case Challenge.METRIC_STREAK:
                        current = user.currentStreak;
                        break;
                    default:
                        break;
                }
            }
            result.add(new ChallengeProgress(c, joined, completed, current, c.target,
                    joined ? joinedAt + c.days * DAY : 0));
        }
        return result;
    }

    /** Marks completed challenges, notifies, and returns newly completed ids. */
    public void checkCompletions(User user, Callback<List<String>> callback) {
        getAllProgress(user, new Callback<List<ChallengeProgress>>() {
            @Override
            public void onSuccess(List<ChallengeProgress> progressList) {
                List<String> newlyCompleted = new ArrayList<>();
                List<String> completed = user.completedChallenges == null
                        ? new ArrayList<>() : new ArrayList<>(user.completedChallenges);
                for (ChallengeProgress p : progressList) {
                    if (p.joined && !p.completed && p.current >= p.target) {
                        completed.add(p.challenge.id);
                        newlyCompleted.add(p.challenge.id);
                        NotificationRepository.push(user.uid, AppNotification.TYPE_CHALLENGE,
                                "Challenge complete!",
                                "You finished \"" + p.challenge.title + "\". Respect earned.",
                                null, null, p.challenge.id);
                    }
                }
                if (newlyCompleted.isEmpty()) {
                    callback.onSuccess(newlyCompleted);
                    return;
                }
                user.completedChallenges = completed;
                Map<String, Object> fields = new HashMap<>();
                fields.put("completedChallenges", completed);
                new UserRepository().updateFields(user.uid, fields, new Callback<Void>() {
                    @Override
                    public void onSuccess(Void result) {
                        callback.onSuccess(newlyCompleted);
                    }

                    @Override
                    public void onError(Exception e) {
                        callback.onError(e);
                    }
                });
            }

            @Override
            public void onError(Exception e) {
                callback.onError(e);
            }
        });
    }
}
