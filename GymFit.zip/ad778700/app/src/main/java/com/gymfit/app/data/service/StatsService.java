package com.gymfit.app.data.service;

import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Db;
import com.gymfit.app.data.model.ExerciseEntry;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.model.Workout;
import com.gymfit.app.data.repository.UserRepository;
import com.gymfit.app.data.repository.WorkoutRepository;
import com.gymfit.app.util.DateUtils;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Recomputes the rolling stats on the user document after each workout:
 * streaks, 28-day volume windows (for progress scoring), recent workout counts
 * and big-three estimated 1RMs (for strength scoring).
 */
public class StatsService {

    private static final long DAY = 24L * 60 * 60 * 1000;

    public void recomputeAfterWorkout(String uid, Callback<User> callback) {
        WorkoutRepository workouts = new WorkoutRepository();
        UserRepository users = new UserRepository();

        workouts.getUserWorkouts(uid, 300, new Callback<java.util.List<Workout>>() {
            @Override
            public void onSuccess(java.util.List<Workout> history) {
                countRecentPrs(uid, history, users, callback);
            }

            @Override
            public void onError(Exception e) {
                callback.onError(e);
            }
        });
    }

    private void countRecentPrs(String uid, java.util.List<Workout> history,
                                UserRepository users, Callback<User> callback) {
        long cutoff = System.currentTimeMillis() - 30 * DAY;
        if (Db.personalRecords() == null) {
            applyStats(uid, history, 0, users, callback);
            return;
        }
        Db.personalRecords().whereEqualTo("userId", uid).limit(500).get()
                .addOnSuccessListener(snapshot -> {
                    int prsLast30 = 0;
                    for (com.google.firebase.firestore.DocumentSnapshot doc : snapshot) {
                        Long achieved = doc.getLong("achievedAt");
                        Double prev = doc.getDouble("previousValue");
                        boolean baseline = prev != null && prev <= 0;
                        if (!baseline && achieved != null && achieved >= cutoff) prsLast30++;
                    }
                    applyStats(uid, history, prsLast30, users, callback);
                })
                .addOnFailureListener(e -> applyStats(uid, history, 0, users, callback));
    }

    private void applyStats(String uid, java.util.List<Workout> history, int prsLast30,
                            UserRepository users, Callback<User> callback) {
        users.getUser(uid, new Callback<User>() {
            @Override
            public void onSuccess(User user) {
                if (user == null) {
                    callback.onError(new IllegalStateException("Profile missing"));
                    return;
                }
                Map<String, Object> stats = compute(user, history);
                stats.put("prsLast30", prsLast30);
                users.updateFields(uid, stats, new Callback<Void>() {
                    @Override
                    public void onSuccess(Void result) {
                        for (Map.Entry<String, Object> e : stats.entrySet()) {
                            applyLocal(user, e.getKey(), e.getValue());
                        }
                        callback.onSuccess(user);
                    }

                    @Override
                    public void onError(Exception e) {
                        callback.onError(e);
                    }
                });
            }

            @Override
            public void onError(Exception e) {
                callback.onError(e);
            }
        });
    }

    public static Map<String, Object> compute(User user, java.util.List<Workout> historyDescending) {
        long now = System.currentTimeMillis();
        Map<String, Object> stats = new HashMap<>();

        int totalWorkouts = historyDescending.size();
        double totalVolume = 0;
        int workouts28 = 0;
        double volume28 = 0;
        double volumePrev28 = 0;
        Set<Long> trainedDays = new HashSet<>();
        double bestBench = 0, bestSquat = 0, bestDeadlift = 0;

        for (Workout w : historyDescending) {
            totalVolume += w.totalVolumeKg;
            long age = now - w.startTime;
            if (age <= 28 * DAY) {
                workouts28++;
                volume28 += w.totalVolumeKg;
            } else if (age <= 56 * DAY) {
                volumePrev28 += w.totalVolumeKg;
            }
            trainedDays.add(DateUtils.startOfDay(w.startTime));

            for (ExerciseEntry e : w.entries) {
                if (!e.hasCompletedSets()) continue;
                double e1rm = e.bestE1rm();
                switch (e.exerciseName) {
                    case "Bench Press":
                        bestBench = Math.max(bestBench, e1rm);
                        break;
                    case "Squat":
                        bestSquat = Math.max(bestSquat, e1rm);
                        break;
                    case "Deadlift":
                        bestDeadlift = Math.max(bestDeadlift, e1rm);
                        break;
                    default:
                        break;
                }
            }
        }

        int streak = currentStreak(trainedDays, now);
        int longest = Math.max(user.longestStreak, streak);

        stats.put("totalWorkouts", totalWorkouts);
        stats.put("totalVolumeKg", totalVolume);
        stats.put("workoutsLast28", workouts28);
        stats.put("volumeLast28Kg", volume28);
        stats.put("volumePrev28Kg", volumePrev28);
        stats.put("currentStreak", streak);
        stats.put("longestStreak", longest);
        stats.put("bestBenchE1rm", bestBench);
        stats.put("bestSquatE1rm", bestSquat);
        stats.put("bestDeadliftE1rm", bestDeadlift);
        if (!historyDescending.isEmpty()) {
            stats.put("lastWorkoutAt", historyDescending.get(0).startTime);
        }
        return stats;
    }

    /** Consecutive calendar days with a workout, counting today or yesterday as the tail. */
    public static int currentStreak(Set<Long> trainedDays, long now) {
        long today = DateUtils.startOfDay(now);
        long cursor;
        if (trainedDays.contains(today)) {
            cursor = today;
        } else if (trainedDays.contains(today - DAY)) {
            cursor = today - DAY;
        } else {
            return 0;
        }
        int streak = 0;
        while (trainedDays.contains(cursor)) {
            streak++;
            cursor -= DAY;
        }
        return streak;
    }

    private static void applyLocal(User user, String key, Object value) {
        switch (key) {
            case "totalWorkouts": user.totalWorkouts = (int) value; break;
            case "totalVolumeKg": user.totalVolumeKg = toDouble(value); break;
            case "workoutsLast28": user.workoutsLast28 = (int) value; break;
            case "volumeLast28Kg": user.volumeLast28Kg = toDouble(value); break;
            case "volumePrev28Kg": user.volumePrev28Kg = toDouble(value); break;
            case "currentStreak": user.currentStreak = (int) value; break;
            case "longestStreak": user.longestStreak = (int) value; break;
            case "prsLast30": user.prsLast30 = (int) value; break;
            case "bestBenchE1rm": user.bestBenchE1rm = toDouble(value); break;
            case "bestSquatE1rm": user.bestSquatE1rm = toDouble(value); break;
            case "bestDeadliftE1rm": user.bestDeadliftE1rm = toDouble(value); break;
            case "lastWorkoutAt": user.lastWorkoutAt = (long) value; break;
            default: break;
        }
    }

    private static double toDouble(Object v) {
        return v instanceof Number ? ((Number) v).doubleValue() : 0;
    }
}
