package com.gymfit.app.ui.workout;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.Workout;
import com.gymfit.app.data.repository.WorkoutRepository;
import com.gymfit.app.databinding.ActivityWorkoutHistoryBinding;
import com.gymfit.app.databinding.ItemRecentWorkoutBinding;
import com.gymfit.app.util.DateUtils;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.FormatUtils;
import com.gymfit.app.util.UiUtils;

import java.util.ArrayList;
import java.util.List;

/** Chronological list of finished workouts; tap to open full details. */
public class WorkoutHistoryActivity extends AppCompatActivity {

    private ActivityWorkoutHistoryBinding binding;
    private final WorkoutRepository repo = new WorkoutRepository();
    private final List<Workout> items = new ArrayList<>();
    private HistoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityWorkoutHistoryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.buttonBack.setOnClickListener(v -> finish());
        adapter = new HistoryAdapter();
        binding.recyclerHistory.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerHistory.setAdapter(adapter);

        load();
    }

    private void load() {
        String uid = Session.uid();
        if (!FirebaseState.isReady(this) || uid == null) {
            binding.progress.setVisibility(View.GONE);
            binding.emptyState.setVisibility(View.VISIBLE);
            return;
        }
        binding.progress.setVisibility(View.VISIBLE);
        repo.getUserWorkouts(uid, 200, new Callback<List<Workout>>() {
            @Override
            public void onSuccess(List<Workout> result) {
                binding.progress.setVisibility(View.GONE);
                items.clear();
                if (result != null) items.addAll(result);
                adapter.notifyDataSetChanged();
                binding.emptyState.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onError(Exception e) {
                binding.progress.setVisibility(View.GONE);
                binding.emptyState.setVisibility(View.VISIBLE);
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, WorkoutHistoryActivity.this));
            }
        });
    }

    private class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.Holder> {

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new Holder(ItemRecentWorkoutBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Holder holder, int position) {
            holder.bind(items.get(position));
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        class Holder extends RecyclerView.ViewHolder {
            private final ItemRecentWorkoutBinding b;

            Holder(ItemRecentWorkoutBinding b) {
                super(b.getRoot());
                this.b = b;
            }

            void bind(Workout w) {
                b.textName.setText(w.name);
                String pr = w.prCount > 0 ? " · " + w.prCount + " PR" + (w.prCount > 1 ? "s" : "") : "";
                b.textMeta.setText(DateUtils.formatDate(w.startTime) + " · "
                        + FormatUtils.duration(w.durationMinutes) + " · "
                        + w.exerciseCount + " " + getString(R.string.exercises) + pr);
                b.textVolume.setText(FormatUtils.compactKg(w.totalVolumeKg));
                b.getRoot().setOnClickListener(v -> {
                    Intent i = new Intent(WorkoutHistoryActivity.this, WorkoutDetailActivity.class);
                    i.putExtra("workoutId", w.id);
                    startActivity(i);
                });
            }
        }
    }
}
