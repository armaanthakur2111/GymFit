package com.gymfit.app.ui.workout;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.TemplateExercise;
import com.gymfit.app.data.model.WorkoutTemplate;
import com.gymfit.app.data.repository.WorkoutRepository;
import com.gymfit.app.databinding.ActivityTemplateEditorBinding;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.UiUtils;

import java.util.Collections;
import java.util.List;

/** Create or edit a custom split (also used to fork AI-generated and system plans). */
public class TemplateEditorActivity extends AppCompatActivity implements TemplateExerciseAdapter.Listener {

    private ActivityTemplateEditorBinding binding;
    private final WorkoutRepository repo = new WorkoutRepository();
    private WorkoutTemplate draft;
    private List<TemplateExercise> exerciseList;
    private TemplateExerciseAdapter adapter;
    private ItemTouchHelper touchHelper;
    private String selectedType;
    private boolean editingExistingUserTemplate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTemplateEditorBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        String uid = Session.uid();
        String[] types = getResources().getStringArray(R.array.workout_split_types);
        selectedType = types.length > 0 ? types[0] : "Custom";
        draft = new WorkoutTemplate("", selectedType, uid == null ? "" : uid, "user");
        exerciseList = draft.exercises;

        binding.buttonBack.setOnClickListener(v -> finish());
        setupTypeDropdown(types);
        setupRecycler();

        binding.buttonAddExercise.setOnClickListener(v -> ExercisePickerDialog.show(this, exercise -> {
            exerciseList.add(new TemplateExercise(exercise.name, exercise.muscleGroup, 3, 10));
            adapter.notifyItemInserted(exerciseList.size() - 1);
            updateEmptyState();
        }));

        binding.buttonSave.setOnClickListener(v -> save());

        String templateId = getIntent().getStringExtra("templateId");
        if (templateId != null && !templateId.isEmpty()) {
            load(templateId);
        } else {
            binding.textTitle.setText(R.string.create_split);
        }
    }

    private void setupTypeDropdown(String[] types) {
        ArrayAdapter<String> typeAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, types);
        binding.inputType.setAdapter(typeAdapter);
        binding.inputType.setText(selectedType, false);
        binding.inputType.setOnItemClickListener((parent, view, position, id) -> {
            selectedType = types[position];
            draft.type = selectedType;
        });
    }

    private void setupRecycler() {
        adapter = new TemplateExerciseAdapter(exerciseList, this);
        binding.recyclerExercises.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerExercises.setAdapter(adapter);

        ItemTouchHelper.Callback callback = new ItemTouchHelper.SimpleCallback(
                ItemTouchHelper.UP | ItemTouchHelper.DOWN, 0) {
            @Override
            public boolean onMove(@NonNull RecyclerView rv, @NonNull RecyclerView.ViewHolder vh,
                                  @NonNull RecyclerView.ViewHolder target) {
                int from = vh.getBindingAdapterPosition();
                int to = target.getBindingAdapterPosition();
                if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) return false;
                Collections.swap(exerciseList, from, to);
                adapter.notifyItemMoved(from, to);
                return true;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder vh, int direction) {
            }
        };
        touchHelper = new ItemTouchHelper(callback);
        touchHelper.attachToRecyclerView(binding.recyclerExercises);
        updateEmptyState();
    }

    private void load(String templateId) {
        repo.getTemplate(templateId, new Callback<WorkoutTemplate>() {
            @Override
            public void onSuccess(WorkoutTemplate t) {
                if (t == null) {
                    binding.textTitle.setText(R.string.create_split);
                    return;
                }
                draft.name = t.name;
                draft.type = t.type == null ? selectedType : t.type;
                draft.source = t.source;
                draft.orderIndex = t.orderIndex;
                binding.inputName.setText(t.name);
                binding.inputType.setText(draft.type, false);
                selectedType = draft.type;

                boolean system = "system".equals(t.ownerId);
                if (system) {
                    draft.id = null; // fork a system split into the user's own library
                    draft.ownerId = Session.uid();
                    draft.source = "user";
                    editingExistingUserTemplate = false;
                } else {
                    draft.id = t.id;
                    draft.ownerId = t.ownerId;
                    editingExistingUserTemplate = true;
                    binding.buttonDelete.setVisibility(View.VISIBLE);
                    binding.buttonDelete.setOnClickListener(v -> confirmDelete());
                }
                binding.textTitle.setText(R.string.edit_profile);

                exerciseList.clear();
                if (t.exercises != null) exerciseList.addAll(t.exercises);
                adapter.notifyDataSetChanged();
                updateEmptyState();
            }

            @Override
            public void onError(Exception e) {
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, TemplateEditorActivity.this));
            }
        });
    }

    @Override
    public void onRemove(int position) {
        if (position < 0 || position >= exerciseList.size()) return;
        exerciseList.remove(position);
        adapter.notifyItemRemoved(position);
        updateEmptyState();
    }

    @Override
    public void onStartDrag(TemplateExerciseAdapter.Holder holder) {
        if (touchHelper != null) touchHelper.startDrag(holder);
    }

    private void updateEmptyState() {
        boolean empty = exerciseList.isEmpty();
        binding.textEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
        binding.recyclerExercises.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    private void save() {
        String name = binding.inputName.getText() == null ? "" : binding.inputName.getText().toString().trim();
        if (name.isEmpty()) {
            binding.layoutName.setError(getString(R.string.error_required_field));
            return;
        }
        binding.layoutName.setError(null);

        String uid = Session.uid();
        if (!FirebaseState.isReady(this) || uid == null) {
            UiUtils.snack(binding.getRoot(), getString(R.string.firebase_not_configured));
            return;
        }
        if (exerciseList.isEmpty()) {
            UiUtils.snack(binding.getRoot(), getString(R.string.add_exercise));
            return;
        }

        draft.name = name;
        draft.type = selectedType;
        draft.ownerId = uid;
        if (draft.source == null) draft.source = "user";

        binding.buttonSave.setEnabled(false);
        repo.saveTemplate(draft, new Callback<String>() {
            @Override
            public void onSuccess(String id) {
                UiUtils.snack(binding.getRoot(), getString(R.string.template_saved));
                finish();
            }

            @Override
            public void onError(Exception e) {
                binding.buttonSave.setEnabled(true);
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, TemplateEditorActivity.this));
            }
        });
    }

    private void confirmDelete() {
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.delete_template)
                .setMessage(R.string.discard_confirm_message)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.delete, (d, w) -> repo.deleteTemplate(draft.id, new Callback<Void>() {
                    @Override
                    public void onSuccess(Void result) {
                        finish();
                    }

                    @Override
                    public void onError(Exception e) {
                        UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, TemplateEditorActivity.this));
                    }
                }))
                .show();
    }
}
