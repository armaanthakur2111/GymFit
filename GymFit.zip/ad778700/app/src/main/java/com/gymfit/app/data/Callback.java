package com.gymfit.app.data;

/** Generic async result callback used by all repositories. */
public interface Callback<T> {
    void onSuccess(T result);

    void onError(Exception e);
}
