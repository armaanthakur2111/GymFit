package com.gymfit.app.ui.auth;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.gymfit.app.R;
import com.gymfit.app.databinding.ActivityOnboardingBinding;
import com.gymfit.app.util.SessionManager;

public class OnboardingActivity extends AppCompatActivity {

    private ActivityOnboardingBinding binding;
    private int page = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityOnboardingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.buttonSkip.setOnClickListener(v -> finishOnboarding());
        binding.buttonNext.setOnClickListener(v -> {
            if (page < 3) {
                page++;
                render();
            } else {
                finishOnboarding();
            }
        });
        render();
    }

    private void render() {
        binding.page1.setVisibility(page == 1 ? View.VISIBLE : View.GONE);
        binding.page2.setVisibility(page == 2 ? View.VISIBLE : View.GONE);
        binding.page3.setVisibility(page == 3 ? View.VISIBLE : View.GONE);
        setDot(binding.dot1, page == 1);
        setDot(binding.dot2, page == 2);
        setDot(binding.dot3, page == 3);
        binding.buttonNext.setText(page == 3 ? R.string.get_started : R.string.continue_label);
    }

    private void setDot(View dot, boolean active) {
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) dot.getLayoutParams();
        params.width = getResources().getDimensionPixelSize(active ? R.dimen.space_lg : R.dimen.space_sm);
        dot.setLayoutParams(params);
        dot.setBackgroundResource(active ? R.drawable.bg_pill_accent : R.drawable.bg_pill_dark);
    }

    private void finishOnboarding() {
        new SessionManager(this).setOnboarded();
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }
}
