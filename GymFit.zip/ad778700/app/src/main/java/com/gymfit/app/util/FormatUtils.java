package com.gymfit.app.util;

import java.util.Locale;

public final class FormatUtils {

    private FormatUtils() {
    }

    public static String kg(double value) {
        if (value == Math.rint(value)) {
            return String.format(Locale.US, "%d kg", (long) value);
        }
        return String.format(Locale.US, "%.1f kg", value);
    }

    public static String compactKg(double value) {
        if (value >= 1_000_000) return String.format(Locale.US, "%.1fM kg", value / 1_000_000);
        if (value >= 10_000) return String.format(Locale.US, "%.1fK kg", value / 1000);
        if (value == Math.rint(value)) return String.format(Locale.US, "%d kg", (long) value);
        return String.format(Locale.US, "%.1f kg", value);
    }

    public static String duration(long minutes) {
        if (minutes < 60) return minutes + "m";
        long h = minutes / 60;
        long m = minutes % 60;
        return m == 0 ? h + "h" : h + "h " + m + "m";
    }

    public static String percent(double fraction) {
        return Math.round(fraction * 100) + "%";
    }

    public static String signedPercent(double previous, double current) {
        if (previous <= 0) return "+100%";
        double delta = (current - previous) / previous * 100;
        return String.format(Locale.US, "%s%.1f%%", delta >= 0 ? "+" : "", delta);
    }

    public static String initials(String name) {
        if (name == null || name.trim().isEmpty()) return "?";
        String[] parts = name.trim().split("\\s+");
        if (parts.length == 1) {
            return parts[0].substring(0, Math.min(2, parts[0].length())).toUpperCase(Locale.US);
        }
        return (parts[0].charAt(0) + "" + parts[parts.length - 1].charAt(0)).toUpperCase(Locale.US);
    }
}
