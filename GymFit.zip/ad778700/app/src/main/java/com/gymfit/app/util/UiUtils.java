package com.gymfit.app.util;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;
import com.gymfit.app.R;

public final class UiUtils {

    private UiUtils() {
    }

    public static void snack(View anchor, String message) {
        if (anchor == null) return;
        Snackbar.make(anchor, message, Snackbar.LENGTH_SHORT).show();
    }

    public static void snackLong(View anchor, String message) {
        if (anchor == null) return;
        Snackbar.make(anchor, message, Snackbar.LENGTH_LONG).show();
    }

    public static void errorDialog(Context context, String message) {
        if (context == null || !(context instanceof Activity) || ((Activity) context).isFinishing()) return;
        new MaterialAlertDialogBuilder(context)
                .setTitle(R.string.app_name)
                .setMessage(message)
                .setPositiveButton(R.string.ok, null)
                .show();
    }

    public static String friendlyError(Exception e, Context context) {
        if (!NetworkUtils.isOnline(context)) {
            return context.getString(R.string.error_network);
        }
        String msg = e != null ? e.getLocalizedMessage() : null;
        if (msg == null || msg.isEmpty()) {
            return context.getString(R.string.error_generic);
        }
        return msg;
    }

    /** Loads a user avatar with an initials fallback badge. */
    public static void loadAvatar(ImageView view, String photoUrl, String name, TextView initialsView) {
        if (initialsView != null) {
            initialsView.setText(FormatUtils.initials(name));
        }
        if (photoUrl == null || photoUrl.isEmpty()) {
            if (view != null) view.setVisibility(View.GONE);
            if (initialsView != null) initialsView.setVisibility(View.VISIBLE);
            return;
        }
        if (view == null) return;
        view.setVisibility(View.VISIBLE);
        if (initialsView != null) initialsView.setVisibility(View.GONE);
        Glide.with(view.getContext())
                .load(photoUrl)
                .circleCrop()
                .placeholder(R.drawable.bg_avatar_placeholder)
                .error(R.drawable.bg_avatar_placeholder)
                .into(view);
    }
}
