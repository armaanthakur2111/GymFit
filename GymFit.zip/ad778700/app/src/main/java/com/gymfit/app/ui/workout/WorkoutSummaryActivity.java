package com.gymfit.app.ui.workout;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.chip.Chip;
import com.gymfit.app.R;
import com.gymfit.app.data.model.PersonalRecord;
import com.gymfit.app.data.model.Workout;
import com.gymfit.app.data.service.AchievementDefs;
import com.gymfit.app.databinding.ActivityWorkoutSummaryBinding;
import com.gymfit.app.databinding.ItemPrRowBinding;
import com.gymfit.app.ui.MainActivity;
import com.gymfit.app.util.FormatUtils;

/** Post-save breakdown: duration, volume, sets, reps, muscle groups, new PRs and badges. */
public class WorkoutSummaryActivity extends AppCompatActivity {

    private ActivityWorkoutSummaryBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityWorkoutSummaryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        WorkoutResult result = WorkoutResult.last;
        if (result == null || result.workout == null) {
            finish();
            return;
        }
        Workout w = result.workout;

        binding.textWorkoutName.setText(w.name);

        bindStat(binding.statDuration.imageIcon, binding.statDuration.textValue,
                binding.statDuration.textLabel, R.drawable.ic_clock,
                FormatUtils.duration(w.durationMinutes), R.string.workout_duration);
        bindStat(binding.statVolume.imageIcon, binding.statVolume.textValue,
                binding.statVolume.textLabel, R.drawable.ic_volume,
                FormatUtils.compactKg(w.totalVolumeKg), R.string.total_volume);
        bindStat(binding.statSets.imageIcon, binding.statSets.textValue,
                binding.statSets.textLabel, R.drawable.ic_dumbbell,
                String.valueOf(w.totalSets), R.string.total_sets);
        bindStat(binding.statReps.imageIcon, binding.statReps.textValue,
                binding.statReps.textLabel, R.drawable.ic_check,
                String.valueOf(w.totalReps), R.string.total_reps);

        for (String muscle : w.muscleGroups) {
            Chip chip = new Chip(this);
            chip.setText(muscle);
            chip.setCheckable(false);
            chip.setClickable(false);
            chip.setEnsureMinTouchTargetSize(false);
            chip.setChipBackgroundColorResource(R.color.bg_card_alt);
            chip.setTextColor(ContextCompat.getColor(this, R.color.text_primary));
            binding.chipMuscles.addView(chip);
        }

        if (result.hasPrs()) {
            binding.containerPrs.setVisibility(View.VISIBLE);
            for (PersonalRecord pr : result.newPrs) {
                ItemPrRowBinding row = ItemPrRowBinding.inflate(
                        LayoutInflater.from(this), binding.containerPrs, false);
                row.textExercise.setText(pr.exerciseName);
                row.textType.setText(pr.typeLabel());
                row.textValue.setText(PersonalRecord.TYPE_REPS.equals(pr.type)
                        ? ((int) pr.value + " reps") : FormatUtils.kg(pr.value));
                binding.containerPrs.addView(row.getRoot());
            }
        }

        if (result.newBadges != null && !result.newBadges.isEmpty()) {
            binding.containerBadges.setVisibility(View.VISIBLE);
            for (String id : result.newBadges) {
                AchievementDefs.Badge badge = AchievementDefs.byId(id);
                if (badge == null) continue;
                ItemPrRowBinding row = ItemPrRowBinding.inflate(
                        LayoutInflater.from(this), binding.containerBadges, false);
                row.textExercise.setText(badge.title);
                row.textType.setText(badge.description);
                row.textValue.setVisibility(View.GONE);
                binding.containerBadges.addView(row.getRoot());
            }
        }

        binding.switchShare.setChecked(w.sharedToFeed);
        binding.switchShare.setEnabled(false);

        binding.buttonDone.setOnClickListener(v -> {
            WorkoutResult.clear();
            Intent home = new Intent(this, MainActivity.class);
            home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(home);
            finish();
        });
    }

    private void bindStat(android.widget.ImageView icon, android.widget.TextView value,
                          android.widget.TextView label, int iconRes, String valueText, int labelRes) {
        icon.setImageResource(iconRes);
        value.setText(valueText);
        label.setText(labelRes);
    }
}
