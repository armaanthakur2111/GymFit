package com.gymfit.app.ui.workout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.gymfit.app.R;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.PersonalRecord;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.repository.SocialRepository;
import com.gymfit.app.databinding.ActivityPrCelebrationBinding;
import com.gymfit.app.util.FormatUtils;
import com.gymfit.app.util.UiUtils;

/** Full-screen celebration for the biggest new PR from the finished workout. */
public class PrCelebrationActivity extends AppCompatActivity {

    private ActivityPrCelebrationBinding binding;
    private WorkoutResult result;
    private PersonalRecord top;
    private boolean shared;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPrCelebrationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        result = WorkoutResult.last;
        if (result == null || !result.hasPrs()) {
            goSummary();
            return;
        }
        top = result.newPrs.get(0);
        shared = result.workout != null && result.workout.sharedToFeed;

        binding.textExercise.setText(top.exerciseName);
        binding.textType.setText(top.typeLabel());
        binding.textPrevious.setText(formatValue(top.previousValue, top.type));
        binding.textNew.setText(formatValue(top.value, top.type));
        binding.textImprovement.setText(FormatUtils.signedPercent(top.previousValue, top.value));

        if (shared) {
            binding.buttonShare.setText(R.string.share_to_feed);
            binding.buttonShare.setEnabled(false);
        } else {
            binding.buttonShare.setOnClickListener(v -> sharePr());
        }

        binding.buttonContinue.setOnClickListener(v -> goSummary());
    }

    private void sharePr() {
        User user = result.updatedUser != null ? result.updatedUser : Session.profile();
        if (user == null) {
            UiUtils.snack(binding.getRoot(), getString(R.string.error_generic));
            return;
        }
        binding.buttonShare.setEnabled(false);
        new SocialRepository().postPrActivity(user, top, new com.gymfit.app.data.Callback<Void>() {
            @Override
            public void onSuccess(Void v) {
                shared = true;
                if (result.workout != null) result.workout.sharedToFeed = true;
                UiUtils.snack(binding.getRoot(), getString(R.string.saved));
            }

            @Override
            public void onError(Exception e) {
                binding.buttonShare.setEnabled(true);
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, PrCelebrationActivity.this));
            }
        });
    }

    private String formatValue(double value, String type) {
        if (PersonalRecord.TYPE_REPS.equals(type)) return ((int) value) + " reps";
        return FormatUtils.kg(value);
    }

    private void goSummary() {
        startActivity(new Intent(this, WorkoutSummaryActivity.class));
        finish();
    }
}
