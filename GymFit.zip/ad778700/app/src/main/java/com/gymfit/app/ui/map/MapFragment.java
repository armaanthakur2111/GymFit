
package com.gymfit.app.ui.map;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

import com.gymfit.app.databinding.FragmentMapBinding;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MapFragment extends Fragment {

    private FragmentMapBinding binding;
    private MapView mapView;
    private MyLocationNewOverlay locationOverlay;
    private LocationManager locationManager;
    private LocationListener locationListener;
    private ExecutorService executor;

    private boolean centeredOnLocation = false;

    private final ActivityResultLauncher<String[]> locationPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestMultiplePermissions(),
                    result -> {
                        if (hasLocationPermission()) {
                            enableMyLocation();
                            requestCurrentLocation();
                        } else if (binding != null) {
                            binding.textCityLocation.setText(
                                    "Location permission denied"
                            );
                            binding.textMapHelp.setText(
                                    "Allow location access in Settings to show your position."
                            );
                        }
                    }
            );

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        Context context = requireContext().getApplicationContext();

        Configuration.getInstance().setUserAgentValue(
                context.getPackageName()
        );

        binding = FragmentMapBinding.inflate(
                inflater, container, false
        );

        return binding.getRoot();
    }

    @Override
    public void onViewCreated(
            @NonNull View view,
            @Nullable Bundle savedInstanceState) {

        super.onViewCreated(view, savedInstanceState);

        mapView = binding.mapView;
        mapView.setTileSource(TileSourceFactory.MAPNIK);
        mapView.setMultiTouchControls(true);
        mapView.getController().setZoom(15.0);

        locationManager = (LocationManager)
                requireContext().getSystemService(Context.LOCATION_SERVICE);

        executor = Executors.newSingleThreadExecutor();

        if (hasLocationPermission()) {
            enableMyLocation();
            requestCurrentLocation();
        } else {
            binding.textCityLocation.setText(
                    "Location permission required"
            );
            locationPermissionLauncher.launch(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            });
        }
    }

    private boolean hasLocationPermission() {
        if (getContext() == null) {
            return false;
        }

        return ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED;
    }

    private void enableMyLocation() {
        if (mapView == null || !hasLocationPermission()) {
            return;
        }

        if (locationOverlay != null) {
            mapView.getOverlays().remove(locationOverlay);
        }

        locationOverlay = new MyLocationNewOverlay(
                new GpsMyLocationProvider(requireContext()),
                mapView
        );

        locationOverlay.enableMyLocation();
        mapView.getOverlays().add(locationOverlay);
        mapView.invalidate();

        binding.textMapHelp.setText(
                "Blue marker shows your device location. Map data provided by OpenStreetMap."
        );
    }

    private void requestCurrentLocation() {
        if (locationManager == null || !hasLocationPermission()) {
            return;
        }

        try {
            Location bestLocation = null;

            String[] providers = {
                    LocationManager.GPS_PROVIDER,
                    LocationManager.NETWORK_PROVIDER
            };

            for (String provider : providers) {
                try {
                    Location candidate =
                            locationManager.getLastKnownLocation(provider);

                    if (candidate != null &&
                            (bestLocation == null ||
                                    candidate.getTime() > bestLocation.getTime())) {
                        bestLocation = candidate;
                    }
                } catch (SecurityException ignored) {
                    // Permission may have changed.
                } catch (IllegalArgumentException ignored) {
                    // Provider may not exist on this device.
                }
            }

            if (bestLocation != null) {
                showLocation(bestLocation);
            } else if (binding != null) {
                binding.textCityLocation.setText(
                        "Finding GPS location..."
                );
            }

            locationListener = location -> {
                if (!isAdded() || binding == null) {
                    return;
                }
                showLocation(location);
            };

            for (String provider : providers) {
                try {
                    if (locationManager.isProviderEnabled(provider)) {
                        locationManager.requestLocationUpdates(
                                provider,
                                5000L,
                                10f,
                                locationListener
                        );
                    }
                } catch (SecurityException ignored) {
                    // Permission may have changed.
                } catch (IllegalArgumentException ignored) {
                    // Provider may not exist.
                }
            }

        } catch (SecurityException e) {
            if (binding != null) {
                binding.textCityLocation.setText(
                        "Location permission is required"
                );
            }
        }
    }

    private void showLocation(Location location) {
        if (!isAdded() || binding == null || mapView == null) {
            return;
        }

        GeoPoint point = new GeoPoint(
                location.getLatitude(),
                location.getLongitude()
        );

        if (!centeredOnLocation) {
            mapView.getController().animateTo(point);
            centeredOnLocation = true;
        }

        if (executor != null && !executor.isShutdown()) {
            executor.execute(() -> {
                String place = getCityName(location);

                if (!isAdded()) {
                    return;
                }

                requireActivity().runOnUiThread(() -> {
                    if (binding != null) {
                        binding.textCityLocation.setText(
                                place != null
                                        ? place
                                        : "Current location detected"
                        );
                    }
                });
            });
        }
    }

    private String getCityName(Location location) {
        if (!Geocoder.isPresent()) {
            return null;
        }

        Geocoder geocoder = new Geocoder(
                requireContext(),
                Locale.getDefault()
        );

        try {
            List<Address> addresses = geocoder.getFromLocation(
                    location.getLatitude(),
                    location.getLongitude(),
                    1
            );

            if (addresses != null && !addresses.isEmpty()) {
                Address address = addresses.get(0);

                String city = address.getLocality();

                if (city == null || city.trim().isEmpty()) {
                    city = address.getSubAdminArea();
                }

                String state = address.getAdminArea();

                if (city != null && state != null) {
                    return city + ", " + state;
                }

                if (city != null) {
                    return city;
                }

                if (state != null) {
                    return state;
                }
            }
        } catch (IOException | IllegalArgumentException e) {
            return null;
        }

        return null;
    }

    @Override
    public void onResume() {
        super.onResume();

        if (mapView != null) {
            mapView.onResume();
        }

        if (hasLocationPermission() && locationManager != null) {
            requestCurrentLocation();
        }
    }

    @Override
    public void onPause() {
        if (locationManager != null && locationListener != null) {
            try {
                locationManager.removeUpdates(locationListener);
            } catch (SecurityException ignored) {
                // Permission may have changed.
            }
            locationListener = null;
        }

        if (mapView != null) {
            mapView.onPause();
        }

        super.onPause();
    }

    @Override
    public void onDestroyView() {
        if (locationOverlay != null) {
            locationOverlay.disableMyLocation();
            locationOverlay = null;
        }

        if (executor != null) {
            executor.shutdownNow();
            executor = null;
        }

        if (mapView != null) {
            mapView.onDetach();
            mapView = null;
        }

        binding = null;
        super.onDestroyView();
    }
}
