package com.gymfit.app.ui.workout;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.gymfit.app.data.model.TemplateExercise;
import com.gymfit.app.databinding.ItemTemplateExerciseBinding;

import java.util.List;

/** Editable list of planned exercises within a split, with sets/reps steppers and drag reorder. */
public class TemplateExerciseAdapter extends RecyclerView.Adapter<TemplateExerciseAdapter.Holder> {

    public interface Listener {
        void onRemove(int position);

        void onStartDrag(Holder holder);
    }

    private static final int MIN_SETS = 1;
    private static final int MAX_SETS = 12;
    private static final int MIN_REPS = 1;
    private static final int MAX_REPS = 30;

    private final List<TemplateExercise> items;
    private final Listener listener;

    public TemplateExerciseAdapter(List<TemplateExercise> items, Listener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(ItemTemplateExerciseBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        holder.bind(items.get(position));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    class Holder extends RecyclerView.ViewHolder {
        private final ItemTemplateExerciseBinding b;

        Holder(ItemTemplateExerciseBinding b) {
            super(b.getRoot());
            this.b = b;
        }

        @SuppressLint("ClickableViewAccessibility")
        void bind(TemplateExercise ex) {
            b.textName.setText(ex.exerciseName);
            b.textMuscle.setText(ex.muscleGroup);
            b.textSets.setText(String.valueOf(ex.targetSets));
            b.textReps.setText(String.valueOf(ex.targetReps));

            b.buttonDrag.setOnTouchListener((v, event) -> {
                if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    listener.onStartDrag(this);
                }
                return false;
            });

            b.buttonRemove.setOnClickListener(v -> {
                int pos = getBindingAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) listener.onRemove(pos);
            });

            b.buttonSetsPlus.setOnClickListener(v -> {
                ex.targetSets = Math.min(MAX_SETS, ex.targetSets + 1);
                b.textSets.setText(String.valueOf(ex.targetSets));
            });
            b.buttonSetsMinus.setOnClickListener(v -> {
                ex.targetSets = Math.max(MIN_SETS, ex.targetSets - 1);
                b.textSets.setText(String.valueOf(ex.targetSets));
            });
            b.buttonRepsPlus.setOnClickListener(v -> {
                ex.targetReps = Math.min(MAX_REPS, ex.targetReps + 1);
                b.textReps.setText(String.valueOf(ex.targetReps));
            });
            b.buttonRepsMinus.setOnClickListener(v -> {
                ex.targetReps = Math.max(MIN_REPS, ex.targetReps - 1);
                b.textReps.setText(String.valueOf(ex.targetReps));
            });
        }
    }
}
