package com.gymfit.app.data.model;

/** A social feed post. Stored in `activities/{id}`. */
public class ActivityPost {

    public static final String TYPE_WORKOUT = "WORKOUT";
    public static final String TYPE_PR = "PR";
    public static final String TYPE_STREAK = "STREAK";
    public static final String TYPE_JOINED = "JOINED";

    public String id;
    public String userId;
    public String userName;
    public String userPhoto;
    public String type;
    public String text;
    public String workoutId;
    public String workoutName;
    public String workoutType;
    public double volumeKg;
    public int durationMinutes;
    public int kudosCount;
    public int commentCount;
    public boolean publicPost = true;
    public long createdAt;

    // Client-side only (not persisted): whether current user gave kudos.
    public transient boolean kudosByMe;

    public ActivityPost() {
    }
}
