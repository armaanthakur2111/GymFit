package com.gymfit.app.data.service;

import com.gymfit.app.R;

/** Badge catalog. Earned ids are stored on User.earnedBadges. */
public final class AchievementDefs {

    public static final String FIRST_WORKOUT = "first_workout";
    public static final String FIRST_PR = "first_pr";
    public static final String STREAK_7 = "streak_7";
    public static final String STREAK_30 = "streak_30";
    public static final String WORKOUTS_25 = "workouts_25";
    public static final String WORKOUTS_100 = "workouts_100";
    public static final String VOLUME_10K = "volume_10k";
    public static final String VOLUME_100K = "volume_100k";
    public static final String FIRST_CHALLENGE = "first_challenge";
    public static final String CHALLENGE_DONE = "challenge_done";
    public static final String FIRST_FRIEND = "first_friend";
    public static final String KUDOS_10 = "kudos_10";

    public static class Badge {
        public final String id;
        public final String title;
        public final String description;
        public final int iconRes;

        Badge(String id, String title, String description, int iconRes) {
            this.id = id;
            this.title = title;
            this.description = description;
            this.iconRes = iconRes;
        }
    }

    private static final Badge[] ALL = {
            new Badge(FIRST_WORKOUT, "First Rep", "Complete your first workout", R.drawable.ic_trophy),
            new Badge(FIRST_PR, "Record Breaker", "Hit your first personal record", R.drawable.ic_medal),
            new Badge(STREAK_7, "Week Warrior", "Train 7 days in a row", R.drawable.ic_fire),
            new Badge(STREAK_30, "Unstoppable", "Train 30 days in a row", R.drawable.ic_fire),
            new Badge(WORKOUTS_25, "Quarter Century", "Complete 25 workouts", R.drawable.ic_dumbbell),
            new Badge(WORKOUTS_100, "Centurion", "Complete 100 workouts", R.drawable.ic_trophy),
            new Badge(VOLUME_10K, "10K Club", "Lift 10,000 kg total volume", R.drawable.ic_volume),
            new Badge(VOLUME_100K, "100K Club", "Lift 100,000 kg total volume", R.drawable.ic_volume),
            new Badge(FIRST_CHALLENGE, "Challenger", "Join your first challenge", R.drawable.ic_target),
            new Badge(CHALLENGE_DONE, "Challenge Complete", "Finish a challenge", R.drawable.ic_medal),
            new Badge(FIRST_FRIEND, "Training Partner", "Add your first friend", R.drawable.ic_friends),
            new Badge(KUDOS_10, "Respected", "Receive 10 kudos", R.drawable.ic_kudos),
    };

    private AchievementDefs() {
    }

    public static Badge[] all() {
        return ALL;
    }

    public static Badge byId(String id) {
        for (Badge b : ALL) {
            if (b.id.equals(id)) return b;
        }
        return null;
    }
}
