package com.gymfit.app.data.repository;

import com.google.firebase.firestore.DocumentSnapshot;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Db;
import com.gymfit.app.data.model.TemplateExercise;
import com.gymfit.app.data.model.Workout;
import com.gymfit.app.data.model.WorkoutTemplate;

import java.util.ArrayList;
import java.util.List;

/** Workout history persistence and split/template management. */
public class WorkoutRepository {

    /** Saves a finished workout; id is generated with a reversed-time prefix for cheap "latest" reads. */
    public void saveWorkout(Workout workout, Callback<String> callback) {
        if (Db.workouts() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        String id = NotificationRepository.reverseTimeId();
        workout.id = id;
        Db.workouts().document(id).set(workout)
                .addOnSuccessListener(v -> callback.onSuccess(id))
                .addOnFailureListener(callback::onError);
    }

    public void getUserWorkouts(String uid, int limit, Callback<List<Workout>> callback) {
        if (Db.workouts() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.workouts().whereEqualTo("userId", uid).limit(limit).get()
                .addOnSuccessListener(snapshot -> callback.onSuccess(parseAll(snapshot.getDocuments())))
                .addOnFailureListener(callback::onError);
    }

    public void getWorkout(String id, Callback<Workout> callback) {
        if (Db.workouts() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.workouts().document(id).get()
                .addOnSuccessListener(doc -> callback.onSuccess(doc.toObject(Workout.class)))
                .addOnFailureListener(callback::onError);
    }

    /** Public recent workouts by a set of users, for profile screens and feeds. */
    public void getRecentWorkoutsSince(String uid, long sinceMillis, Callback<List<Workout>> callback) {
        getUserWorkouts(uid, 200, new Callback<List<Workout>>() {
            @Override
            public void onSuccess(List<Workout> result) {
                List<Workout> filtered = new ArrayList<>();
                for (Workout w : result) {
                    if (w.startTime >= sinceMillis) filtered.add(w);
                }
                callback.onSuccess(filtered);
            }

            @Override
            public void onError(Exception e) {
                callback.onError(e);
            }
        });
    }

    private List<Workout> parseAll(List<DocumentSnapshot> docs) {
        List<Workout> workouts = new ArrayList<>();
        for (DocumentSnapshot doc : docs) {
            Workout w = doc.toObject(Workout.class);
            if (w != null) {
                w.id = doc.getId();
                workouts.add(w);
            }
        }
        workouts.sort((a, b) -> Long.compare(b.startTime, a.startTime));
        return workouts;
    }

    // ---- Templates ----

    /** System splits plus the user's own (including AI-generated) plans. */
    public void getTemplates(String uid, Callback<List<WorkoutTemplate>> callback) {
        if (Db.templates() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        List<String> owners = new ArrayList<>();
        owners.add(uid);
        owners.add("system");
        Db.templates().whereIn("ownerId", owners).get()
                .addOnSuccessListener(snapshot -> {
                    List<WorkoutTemplate> templates = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot) {
                        WorkoutTemplate t = doc.toObject(WorkoutTemplate.class);
                        if (t != null) {
                            t.id = doc.getId();
                            templates.add(t);
                        }
                    }
                    templates.sort((a, b) -> {
                        boolean sa = "system".equals(a.ownerId);
                        boolean sb = "system".equals(b.ownerId);
                        if (sa != sb) return sa ? -1 : 1;
                        return a.name == null ? 1 : b.name == null ? -1 : a.name.compareToIgnoreCase(b.name);
                    });
                    callback.onSuccess(templates);
                })
                .addOnFailureListener(callback::onError);
    }

    public void getTemplate(String id, Callback<WorkoutTemplate> callback) {
        if (Db.templates() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.templates().document(id).get()
                .addOnSuccessListener(doc -> {
                    WorkoutTemplate t = doc.toObject(WorkoutTemplate.class);
                    if (t != null) t.id = doc.getId();
                    callback.onSuccess(t);
                })
                .addOnFailureListener(callback::onError);
    }

    public void saveTemplate(WorkoutTemplate template, Callback<String> callback) {
        if (Db.templates() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        if (template.id != null && !template.id.isEmpty()) {
            Db.templates().document(template.id).set(template)
                    .addOnSuccessListener(v -> callback.onSuccess(template.id))
                    .addOnFailureListener(callback::onError);
        } else {
            Db.templates().add(template)
                    .addOnSuccessListener(ref -> callback.onSuccess(ref.getId()))
                    .addOnFailureListener(callback::onError);
        }
    }

    public void deleteTemplate(String templateId, Callback<Void> callback) {
        if (Db.templates() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.templates().document(templateId).delete()
                .addOnSuccessListener(v -> callback.onSuccess(null))
                .addOnFailureListener(callback::onError);
    }

    /**
     * Writes the built-in split library once per install so a fresh Firestore has
     * usable content. Idempotent: guarded by a local flag in SessionManager.
     */
    public void seedSystemTemplates(Callback<Void> callback) {
        if (Db.templates() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        List<WorkoutTemplate> seeds = builtinTemplates();
        final int[] remaining = {seeds.size()};
        for (WorkoutTemplate t : seeds) {
            Db.templates().document("sys_" + t.name.toLowerCase().replace(" ", "_").replace("+", "plus"))
                    .set(t)
                    .addOnCompleteListener(task -> {
                        if (--remaining[0] == 0) callback.onSuccess(null);
                    });
        }
    }

    public static List<WorkoutTemplate> builtinTemplates() {
        List<WorkoutTemplate> list = new ArrayList<>();
        list.add(template("Push Day", "Push",
                ex("Bench Press", "Chest", 4, 8),
                ex("Overhead Press", "Shoulders", 3, 8),
                ex("Incline Dumbbell Press", "Chest", 3, 10),
                ex("Lateral Raise", "Shoulders", 3, 12),
                ex("Tricep Pushdown", "Triceps", 3, 12),
                ex("Overhead Tricep Extension", "Triceps", 3, 12)));
        list.add(template("Pull Day", "Pull",
                ex("Deadlift", "Back", 3, 5),
                ex("Pull-Up", "Back", 4, 8),
                ex("Seated Cable Row", "Back", 3, 10),
                ex("Lat Pulldown", "Back", 3, 12),
                ex("Face Pull", "Back", 3, 15),
                ex("Barbell Curl", "Biceps", 3, 10),
                ex("Hammer Curl", "Biceps", 3, 12)));
        list.add(template("Leg Day", "Legs",
                ex("Squat", "Quads", 4, 6),
                ex("Romanian Deadlift", "Hamstrings", 3, 8),
                ex("Leg Press", "Quads", 3, 10),
                ex("Leg Curl", "Hamstrings", 3, 12),
                ex("Hip Thrust", "Glutes", 3, 10),
                ex("Standing Calf Raise", "Calves", 4, 15)));
        list.add(template("Upper Body", "Upper",
                ex("Bench Press", "Chest", 4, 8),
                ex("Barbell Row", "Back", 4, 8),
                ex("Dumbbell Shoulder Press", "Shoulders", 3, 10),
                ex("Lat Pulldown", "Back", 3, 12),
                ex("Dumbbell Curl", "Biceps", 3, 12),
                ex("Skull Crusher", "Triceps", 3, 12)));
        list.add(template("Lower Body", "Lower",
                ex("Front Squat", "Quads", 4, 6),
                ex("Bulgarian Split Squat", "Quads", 3, 10),
                ex("Leg Curl", "Hamstrings", 3, 12),
                ex("Glute Bridge", "Glutes", 3, 12),
                ex("Seated Calf Raise", "Calves", 4, 15)));
        list.add(template("Full Body Blast", "Full Body",
                ex("Squat", "Quads", 3, 8),
                ex("Bench Press", "Chest", 3, 8),
                ex("Barbell Row", "Back", 3, 8),
                ex("Lunge", "Quads", 3, 10),
                ex("Plank", "Core", 3, 1)));
        list.add(template("Chest Day", "Bro Split",
                ex("Bench Press", "Chest", 4, 8),
                ex("Incline Bench Press", "Chest", 4, 8),
                ex("Cable Fly", "Chest", 3, 12),
                ex("Pec Deck", "Chest", 3, 12),
                ex("Dip (Chest)", "Chest", 3, 10)));
        return list;
    }

    private static WorkoutTemplate template(String name, String type, TemplateExercise... exercises) {
        WorkoutTemplate t = new WorkoutTemplate(name, type, "system", "builtin");
        for (TemplateExercise e : exercises) t.exercises.add(e);
        return t;
    }

    private static TemplateExercise ex(String name, String muscleGroup, int sets, int reps) {
        return new TemplateExercise(name, muscleGroup, sets, reps);
    }
}
