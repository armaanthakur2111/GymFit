
package com.gymfit.app.data.repository;

import android.content.Context;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.FirebaseFirestore;

import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Db;
import com.gymfit.app.data.model.ActivityPost;
import com.gymfit.app.data.model.User;
import com.gymfit.app.util.FirebaseState;

import java.util.HashMap;
import java.util.Map;

public class AuthRepository {

    private final FirebaseAuth auth;

    public AuthRepository() {
        FirebaseAuth instance;
        try {
            instance = FirebaseAuth.getInstance();
        } catch (Exception e) {
            instance = null;
        }
        auth = instance;
    }

    public static boolean isConfigured(Context context) {
        return FirebaseState.isReady(context);
    }

    private static IllegalStateException notConfigured() {
        return new IllegalStateException(
                "Firebase is not configured on this build");
    }

    public FirebaseUser currentUser() {
        return auth == null ? null : auth.getCurrentUser();
    }

    public String currentUid() {
        FirebaseUser user = currentUser();
        return user == null ? null : user.getUid();
    }

    public void login(
            String email,
            String password,
            Callback<FirebaseUser> callback) {

        if (auth == null) {
            callback.onError(notConfigured());
            return;
        }

        auth.signInWithEmailAndPassword(email.trim(), password)
                .addOnSuccessListener(result -> {
                    if (result.getUser() == null) {
                        callback.onError(
                                new IllegalStateException(
                                        "Login produced no user"));
                    } else {
                        callback.onSuccess(result.getUser());
                    }
                })
                .addOnFailureListener(callback::onError);
    }

    public void signUp(
            User profile,
            String password,
            Callback<FirebaseUser> callback) {

        if (auth == null) {
            callback.onError(notConfigured());
            return;
        }

        auth.createUserWithEmailAndPassword(
                        profile.email.trim(), password)
                .addOnSuccessListener(result -> {
                    FirebaseUser fbUser = result.getUser();

                    if (fbUser == null) {
                        callback.onError(
                                new IllegalStateException(
                                        "Sign up produced no user"));
                        return;
                    }

                    profile.uid = fbUser.getUid();
                    profile.createdAt = System.currentTimeMillis();

                    fbUser.updateProfile(
                            new UserProfileChangeRequest.Builder()
                                    .setDisplayName(profile.name)
                                    .build());

                    FirebaseFirestore db = Db.get();

                    if (db == null) {
                        callback.onError(
                                new IllegalStateException(
                                        "Firestore unavailable"));
                        return;
                    }

                    Map<String, Object> publicProfile =
                            createPublicProfile(profile);

                    db.collection(Db.USERS)
                            .document(profile.uid)
                            .set(profile)
                            .addOnSuccessListener(v ->
                                    db.collection(Db.PUBLIC_PROFILES)
                                            .document(profile.uid)
                                            .set(publicProfile)
                                            .addOnSuccessListener(publicResult -> {
                                                postJoinedActivity(profile);
                                                callback.onSuccess(fbUser);
                                            })
                                            .addOnFailureListener(callback::onError))
                            .addOnFailureListener(callback::onError);
                })
                .addOnFailureListener(callback::onError);
    }

    private Map<String, Object> createPublicProfile(User user) {
        Map<String, Object> data = new HashMap<>();

        data.put("uid", user.uid);
        data.put("name", user.name);
        data.put("photoUrl", user.photoUrl);
        data.put("searchKey",
                user.searchKey == null
                        ? (user.name == null ? "" : user.name.toLowerCase())
                        : user.searchKey);

        data.put("showOnLeaderboard", user.showOnLeaderboard);
        data.put("gymId", user.gymId);
        data.put("gymName", user.gymName);
        data.put("goal", user.goal);
        data.put("experience", user.experience);
        data.put("trainingDaysPerWeek", user.trainingDaysPerWeek);

        // Leaderboard statistics
        data.put("weightKg", user.weightKg);
        data.put("workoutsLast28", user.workoutsLast28);
        data.put("currentStreak", user.currentStreak);
        data.put("longestStreak", user.longestStreak);
        data.put("bestBenchE1rm", user.bestBenchE1rm);
        data.put("bestSquatE1rm", user.bestSquatE1rm);
        data.put("bestDeadliftE1rm", user.bestDeadliftE1rm);
        data.put("prsLast30", user.prsLast30);
        data.put("volumeLast28Kg", user.volumeLast28Kg);
        data.put("volumePrev28Kg", user.volumePrev28Kg);

        return data;
    }

    private void postJoinedActivity(User profile) {
        ActivityPost post = new ActivityPost();
        post.userId = profile.uid;
        post.userName = profile.name;
        post.userPhoto = profile.photoUrl;
        post.type = ActivityPost.TYPE_JOINED;
        post.text = "joined GymFit";
        post.publicPost = profile.showActivities;
        post.createdAt = System.currentTimeMillis();

        if (Db.activities() != null) {
            Db.activities().add(post);
        }
    }

    public void sendPasswordReset(
            String email,
            Callback<Void> callback) {

        if (auth == null) {
            callback.onError(notConfigured());
            return;
        }

        auth.sendPasswordResetEmail(email.trim())
                .addOnSuccessListener(v -> callback.onSuccess(null))
                .addOnFailureListener(callback::onError);
    }

    public void logout() {
        if (auth != null) {
            auth.signOut();
        }
    }

    public void deleteAccount(Callback<Void> callback) {
        if (auth == null) {
            callback.onError(notConfigured());
            return;
        }

        FirebaseUser user = auth.getCurrentUser();

        if (user == null) {
            callback.onError(
                    new IllegalStateException("Not signed in"));
            return;
        }

        String uid = user.getUid();

        user.delete()
                .addOnSuccessListener(v -> {
                    FirebaseFirestore db = Db.get();

                    if (db == null) {
                        callback.onError(
                                new IllegalStateException(
                                        "Firestore unavailable"));
                        return;
                    }

                    db.collection(Db.USERS).document(uid).delete()
                            .addOnSuccessListener(a ->
                                    db.collection(Db.PUBLIC_PROFILES)
                                            .document(uid).delete()
                                            .addOnSuccessListener(b ->
                                                    callback.onSuccess(null))
                                            .addOnFailureListener(callback::onError))
                            .addOnFailureListener(callback::onError);
                })
                .addOnFailureListener(callback::onError);
    }
}
