package com.gymfit.app.util;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Local device preferences: onboarding flags, notification toggles, cached identity.
 * NOT a substitute for Firestore — only cheap local state lives here.
 */
public class SessionManager {

    private static final String PREFS = "gymfit_session";
    private static final String KEY_ONBOARDED = "onboarded";
    private static final String KEY_NOTIFY_SOCIAL = "notify_social";
    private static final String KEY_NOTIFY_PROGRESS = "notify_progress";
    private static final String KEY_NOTIFY_WORKOUT = "notify_workout";
    private static final String KEY_SEEDED_TEMPLATES = "seeded_templates";

    private final SharedPreferences prefs;

    public SessionManager(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public boolean isOnboarded() {
        return prefs.getBoolean(KEY_ONBOARDED, false);
    }

    public void setOnboarded() {
        prefs.edit().putBoolean(KEY_ONBOARDED, true).apply();
    }

    public boolean notifySocial() {
        return prefs.getBoolean(KEY_NOTIFY_SOCIAL, true);
    }

    public boolean notifyProgress() {
        return prefs.getBoolean(KEY_NOTIFY_PROGRESS, true);
    }

    public boolean notifyWorkout() {
        return prefs.getBoolean(KEY_NOTIFY_WORKOUT, true);
    }

    public void setNotifySocial(boolean v) {
        prefs.edit().putBoolean(KEY_NOTIFY_SOCIAL, v).apply();
    }

    public void setNotifyProgress(boolean v) {
        prefs.edit().putBoolean(KEY_NOTIFY_PROGRESS, v).apply();
    }

    public void setNotifyWorkout(boolean v) {
        prefs.edit().putBoolean(KEY_NOTIFY_WORKOUT, v).apply();
    }

    public boolean templatesSeeded() {
        return prefs.getBoolean(KEY_SEEDED_TEMPLATES, false);
    }

    public void setTemplatesSeeded() {
        prefs.edit().putBoolean(KEY_SEEDED_TEMPLATES, true).apply();
    }
}
