package com.gymfit.app.data.model;

/** Body weight log entry. Stored in `bodyWeights/{id}`. */
public class BodyWeightEntry {

    public String id;
    public String userId;
    public double weightKg;
    public long recordedAt;

    public BodyWeightEntry() {
    }

    public BodyWeightEntry(String userId, double weightKg) {
        this.userId = userId;
        this.weightKg = weightKg;
        this.recordedAt = System.currentTimeMillis();
    }
}
