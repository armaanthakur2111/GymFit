package com.gymfit.app.ui.workout;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.chip.Chip;
import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.model.ExerciseEntry;
import com.gymfit.app.data.model.SetLog;
import com.gymfit.app.data.model.Workout;
import com.gymfit.app.data.repository.WorkoutRepository;
import com.gymfit.app.databinding.ActivityWorkoutDetailBinding;
import com.gymfit.app.databinding.ItemExerciseDetailBinding;
import com.gymfit.app.util.DateUtils;
import com.gymfit.app.util.FormatUtils;
import com.gymfit.app.util.UiUtils;

import java.util.Locale;

/** Read-only breakdown of a single finished workout. */
public class WorkoutDetailActivity extends AppCompatActivity {

    private ActivityWorkoutDetailBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityWorkoutDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.buttonBack.setOnClickListener(v -> finish());

        String workoutId = getIntent().getStringExtra("workoutId");
        if (workoutId == null || workoutId.isEmpty()) {
            finish();
            return;
        }
        binding.progress.setVisibility(View.VISIBLE);
        new WorkoutRepository().getWorkout(workoutId, new Callback<Workout>() {
            @Override
            public void onSuccess(Workout workout) {
                binding.progress.setVisibility(View.GONE);
                if (workout == null) {
                    finish();
                    return;
                }
                bind(workout);
            }

            @Override
            public void onError(Exception e) {
                binding.progress.setVisibility(View.GONE);
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, WorkoutDetailActivity.this));
                finish();
            }
        });
    }

    private void bind(Workout w) {
        binding.textName.setText(w.name);
        String pr = w.prCount > 0 ? "  ·  " + w.prCount + " PR" + (w.prCount > 1 ? "s" : "") : "";
        binding.textMeta.setText(DateUtils.formatDate(w.startTime) + "  ·  " + (w.type == null ? "" : w.type) + pr);

        bindStat(binding.statDuration.imageIcon, binding.statDuration.textValue,
                binding.statDuration.textLabel, R.drawable.ic_clock,
                FormatUtils.duration(w.durationMinutes), R.string.workout_duration);
        bindStat(binding.statVolume.imageIcon, binding.statVolume.textValue,
                binding.statVolume.textLabel, R.drawable.ic_volume,
                FormatUtils.compactKg(w.totalVolumeKg), R.string.total_volume);
        bindStat(binding.statSets.imageIcon, binding.statSets.textValue,
                binding.statSets.textLabel, R.drawable.ic_dumbbell,
                String.valueOf(w.totalSets), R.string.total_sets);
        bindStat(binding.statReps.imageIcon, binding.statReps.textValue,
                binding.statReps.textLabel, R.drawable.ic_check,
                String.valueOf(w.totalReps), R.string.total_reps);

        if (w.muscleGroups != null) {
            for (String muscle : w.muscleGroups) {
                Chip chip = new Chip(this);
                chip.setText(muscle);
                chip.setCheckable(false);
                chip.setClickable(false);
                chip.setEnsureMinTouchTargetSize(false);
                chip.setChipBackgroundColorResource(R.color.bg_card_alt);
                chip.setTextColor(ContextCompat.getColor(this, R.color.text_primary));
                binding.chipMuscles.addView(chip);
            }
        }

        binding.containerExercises.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(this);
        for (ExerciseEntry entry : w.entries) {
            if (!entry.hasCompletedSets()) continue;
            ItemExerciseDetailBinding card = ItemExerciseDetailBinding.inflate(
                    inflater, binding.containerExercises, false);
            card.textName.setText(entry.exerciseName);
            card.textMuscle.setText(entry.muscleGroup);
            card.textVolume.setText(FormatUtils.compactKg(entry.volume()));

            int setNumber = 0;
            for (SetLog set : entry.sets) {
                if (!set.completed) continue;
                setNumber++;
                TextView line = new TextView(this);
                double e1rm = set.estimated1Rm();
                String text = String.format(Locale.US, "%s %d:  %s × %d",
                        getString(R.string.set_label), setNumber,
                        FormatUtils.kg(set.weightKg), set.reps);
                if (e1rm > 0 && set.reps > 1) {
                    text += "   (" + getString(R.string.estimated_1rm) + " "
                            + FormatUtils.kg(e1rm) + ")";
                }
                line.setText(text);
                line.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
                line.setTextSize(14);
                line.setPadding(0, 4, 0, 4);
                card.containerSets.addView(line);
            }
            binding.containerExercises.addView(card.getRoot());
        }
    }

    private void bindStat(android.widget.ImageView icon, TextView value, TextView label,
                          int iconRes, String valueText, int labelRes) {
        icon.setImageResource(iconRes);
        value.setText(valueText);
        label.setText(labelRes);
    }
}
