package com.gymfit.app.data.repository;

import com.google.firebase.firestore.DocumentSnapshot;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Db;
import com.gymfit.app.data.model.AppNotification;
import com.gymfit.app.data.model.FriendRequest;
import com.gymfit.app.data.model.User;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Friends and friend requests, using per-user subcollections so that every
 * query stays single-field (no composite indexes required) and security rules
 * stay simple:
 *
 *   users/{uid}/friends/{friendUid}       — accepted friendships (mirror docs)
 *   users/{uid}/friendRequests/{fromUid}  — received requests
 *
 * The "sent" side is tracked on the sender's own user doc (sentRequestIds).
 */
public class FriendRepository {

    /** A friend row with the other user's live profile resolved. */
    public static class Friend {
        public String uid;
        public String name;
        public String photoUrl;
        public String goal;
        public String gymName;
        public long since;
    }

    public void getFriends(String uid, Callback<List<Friend>> callback) {
        if (Db.users() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.users().document(uid).collection("friends").get()
                .addOnSuccessListener(snapshot -> {
                    List<Friend> friends = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot) {
                        Friend f = doc.toObject(Friend.class);
                        if (f != null && f.uid != null) friends.add(f);
                    }
                    friends.sort((a, b) -> a.name == null ? 1 : b.name == null ? -1
                            : a.name.compareToIgnoreCase(b.name));
                    callback.onSuccess(friends);
                })
                .addOnFailureListener(callback::onError);
    }

    public void getFriendIds(String uid, Callback<List<String>> callback) {
        getFriends(uid, new Callback<List<Friend>>() {
            @Override
            public void onSuccess(List<Friend> result) {
                List<String> ids = new ArrayList<>();
                for (Friend f : result) ids.add(f.uid);
                callback.onSuccess(ids);
            }

            @Override
            public void onError(Exception e) {
                callback.onError(e);
            }
        });
    }

    public void getIncomingRequests(String uid, Callback<List<FriendRequest>> callback) {
        if (Db.users() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.users().document(uid).collection("friendRequests")
                .whereEqualTo("status", FriendRequest.STATUS_PENDING)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<FriendRequest> requests = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot) {
                        FriendRequest r = doc.toObject(FriendRequest.class);
                        if (r != null) {
                            r.id = doc.getId();
                            requests.add(r);
                        }
                    }
                    requests.sort((a, b) -> Long.compare(b.createdAt, a.createdAt));
                    callback.onSuccess(requests);
                })
                .addOnFailureListener(callback::onError);
    }

    /** Writes the request into the recipient's inbox and notifies them. */
    public void sendRequest(User from, String toUid, Callback<Void> callback) {
        if (Db.users() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        FriendRequest request = new FriendRequest();
        request.id = from.uid;
        request.fromId = from.uid;
        request.fromName = from.name;
        request.fromPhoto = from.photoUrl;
        request.toId = toUid;
        request.status = FriendRequest.STATUS_PENDING;
        request.createdAt = System.currentTimeMillis();

        Db.users().document(toUid).collection("friendRequests").document(from.uid)
                .set(request)
                .addOnSuccessListener(v -> {
                    NotificationRepository.push(toUid, AppNotification.TYPE_FRIEND_REQUEST,
                            "New friend request", from.name + " wants to train with you.",
                            from.uid, from.name, from.uid);
                    callback.onSuccess(null);
                })
                .addOnFailureListener(callback::onError);
    }

    public void cancelRequest(String fromUid, String toUid, Callback<Void> callback) {
        if (Db.users() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.users().document(toUid).collection("friendRequests").document(fromUid).delete()
                .addOnSuccessListener(v -> callback.onSuccess(null))
                .addOnFailureListener(callback::onError);
    }

    /**
     * Accepts a request: deletes the inbox doc and creates mirror friend docs.
     * Security rules allow writing a friend doc into the other participant's list.
     */
    public void acceptRequest(User me, FriendRequest request, Callback<Void> callback) {
        if (Db.users() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Friend myCopy = new Friend();
        myCopy.uid = request.fromId;
        myCopy.name = request.fromName;
        myCopy.photoUrl = request.fromPhoto;
        myCopy.since = System.currentTimeMillis();

        Map<String, Object> theirCopy = new HashMap<>();
        theirCopy.put("uid", me.uid);
        theirCopy.put("name", me.name);
        theirCopy.put("photoUrl", me.photoUrl == null ? "" : me.photoUrl);
        theirCopy.put("goal", me.goal == null ? "" : me.goal);
        theirCopy.put("gymName", me.gymName == null ? "" : me.gymName);
        theirCopy.put("since", System.currentTimeMillis());

        Db.users().document(me.uid).collection("friendRequests").document(request.fromId).delete()
                .addOnSuccessListener(v -> Db.users().document(me.uid).collection("friends")
                        .document(request.fromId).set(myCopy))
                .addOnSuccessListener(v -> Db.users().document(request.fromId).collection("friends")
                        .document(me.uid).set(theirCopy))
                .addOnSuccessListener(v -> {
                    NotificationRepository.push(request.fromId, AppNotification.TYPE_FRIEND_ACCEPTED,
                            "Friend request accepted", me.name + " accepted your request.",
                            me.uid, me.name, me.uid);
                    callback.onSuccess(null);
                })
                .addOnFailureListener(callback::onError);
    }

    public void rejectRequest(String uid, FriendRequest request, Callback<Void> callback) {
        if (Db.users() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.users().document(uid).collection("friendRequests").document(request.fromId).delete()
                .addOnSuccessListener(v -> callback.onSuccess(null))
                .addOnFailureListener(callback::onError);
    }

    /** Removes the friendship from both sides (either participant may delete). */
    public void removeFriend(String uid, String friendUid, Callback<Void> callback) {
        if (Db.users() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.users().document(uid).collection("friends").document(friendUid).delete()
                .addOnSuccessListener(v -> Db.users().document(friendUid).collection("friends")
                        .document(uid).delete())
                .addOnSuccessListener(v -> callback.onSuccess(null))
                .addOnFailureListener(callback::onError);
    }

    public void areFriends(String uid, String otherUid, Callback<Boolean> callback) {
        if (Db.users() == null) {
            callback.onSuccess(false);
            return;
        }
        Db.users().document(uid).collection("friends").document(otherUid).get()
                .addOnSuccessListener(doc -> callback.onSuccess(doc.exists()))
                .addOnFailureListener(e -> callback.onSuccess(false));
    }

    /** Refreshes the cached friend rows on both sides after a profile edit. */
    public void syncFriendRow(User updated) {
        if (Db.users() == null) return;
        Map<String, Object> row = new HashMap<>();
        row.put("name", updated.name);
        row.put("photoUrl", updated.photoUrl == null ? "" : updated.photoUrl);
        row.put("goal", updated.goal == null ? "" : updated.goal);
        row.put("gymName", updated.gymName == null ? "" : updated.gymName);
        Db.users().document(updated.uid).collection("friends").get()
                .addOnSuccessListener(snapshot -> {
                    List<String> friendIds = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot) friendIds.add(doc.getId());
                    for (String fid : friendIds) {
                        Db.users().document(fid).collection("friends")
                                .document(updated.uid).update(row);
                    }
                });
    }

    public static List<Friend> emptyIfNull(List<Friend> list) {
        return list == null ? Collections.emptyList() : list;
    }
}
