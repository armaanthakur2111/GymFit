package com.gymfit.app.ui.auth;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseUser;
import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.model.Gym;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.repository.AuthRepository;
import com.gymfit.app.data.repository.GymRepository;
import com.gymfit.app.databinding.ActivitySignUpBinding;
import com.gymfit.app.ui.MainActivity;
import com.gymfit.app.util.UiUtils;
import com.gymfit.app.util.ValidationUtils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class SignUpActivity extends AppCompatActivity {

    private ActivitySignUpBinding binding;
    private final AuthRepository auth = new AuthRepository();
    private int step = 1;
    private String dobIso = "";
    private String selectedGymId = "";
    private String selectedGymName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySignUpBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.buttonBack.setOnClickListener(v -> finish());
        binding.buttonLogin.setOnClickListener(v -> finish());
        binding.buttonContinue.setOnClickListener(v -> onNext());

        binding.inputDob.setOnClickListener(v -> pickDob());
        binding.layoutDob.setEndIconOnClickListener(v -> pickDob());

        setupDropdowns();
        loadGymSuggestions();
        renderStep();
    }

    private void setupDropdowns() {
        setItems(binding.inputGender, R.array.genders);
        setItems(binding.inputExperience, R.array.experience_levels);
        setItems(binding.inputGoal, R.array.fitness_goals);
        setItems(binding.inputFrequency, R.array.training_frequencies);
    }

    private void setItems(AutoCompleteTextView view, int arrayRes) {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, arrayRes, android.R.layout.simple_list_item_1);
        view.setAdapter(adapter);
    }

    private void loadGymSuggestions() {
        new GymRepository().getGyms(new Callback<List<Gym>>() {
            @Override
            public void onSuccess(List<Gym> gyms) {
                List<String> names = new ArrayList<>();
                for (Gym g : gyms) names.add(g.name);
                ArrayAdapter<String> adapter = new ArrayAdapter<>(
                        SignUpActivity.this, android.R.layout.simple_list_item_1, names);
                binding.inputGym.setAdapter(adapter);
                binding.inputGym.setOnItemClickListener((parent, view, position, id) -> {
                    Gym g = gyms.get(position);
                    selectedGymId = g.id;
                    selectedGymName = g.name;
                });
            }

            @Override
            public void onError(Exception e) {
                // Gym suggestions are optional; free text still works.
            }
        });
    }

    private void pickDob() {
        Calendar now = Calendar.getInstance();
        new DatePickerDialog(this, (view, year, month, day) -> {
            dobIso = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day);
            binding.inputDob.setText(String.format(Locale.US, "%02d/%02d/%04d", day, month + 1, year));
        }, now.get(Calendar.YEAR) - 20, now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void renderStep() {
        binding.step1.setVisibility(step == 1 ? View.VISIBLE : View.GONE);
        binding.step2.setVisibility(step == 2 ? View.VISIBLE : View.GONE);
        binding.step3.setVisibility(step == 3 ? View.VISIBLE : View.GONE);
        binding.stepProgress.setProgress(step);
        binding.textStep.setText(getString(R.string.step_of, step, 3));
        binding.buttonContinue.setText(step == 3 ? R.string.sign_up : R.string.continue_label);
    }

    private void onNext() {
        if (step == 1 && !validateStep1()) return;
        if (step == 2 && !validateStep2()) return;
        if (step < 3) {
            step++;
            renderStep();
        } else {
            submit();
        }
    }

    private boolean validateStep1() {
        boolean ok = true;
        String name = text(binding.inputName.getText());
        String email = text(binding.inputEmail.getText());
        String password = text(binding.inputPassword.getText());
        if (!ValidationUtils.isNonEmpty(name)) {
            binding.layoutName.setError(getString(R.string.error_required_field));
            ok = false;
        } else {
            binding.layoutName.setError(null);
        }
        if (!ValidationUtils.isValidEmail(email)) {
            binding.layoutEmail.setError(getString(R.string.error_invalid_email));
            ok = false;
        } else {
            binding.layoutEmail.setError(null);
        }
        if (!ValidationUtils.isValidPassword(password)) {
            binding.layoutPassword.setError(getString(R.string.error_short_password));
            ok = false;
        } else {
            binding.layoutPassword.setError(null);
        }
        return ok;
    }

    private boolean validateStep2() {
        boolean ok = true;
        if (dobIso.isEmpty()) {
            binding.layoutDob.setError(getString(R.string.error_required_field));
            ok = false;
        } else {
            binding.layoutDob.setError(null);
        }
        if (!ValidationUtils.isPositiveNumber(text(binding.inputHeight.getText()))) {
            binding.layoutHeight.setError(getString(R.string.error_required_field));
            ok = false;
        } else {
            binding.layoutHeight.setError(null);
        }
        if (!ValidationUtils.isPositiveNumber(text(binding.inputWeight.getText()))) {
            binding.layoutWeight.setError(getString(R.string.error_required_field));
            ok = false;
        } else {
            binding.layoutWeight.setError(null);
        }
        return ok;
    }

    private void submit() {
        User profile = new User();
        profile.name = text(binding.inputName.getText());
        profile.email = text(binding.inputEmail.getText());
        profile.dob = dobIso;
        profile.gender = text(binding.inputGender.getText());
        profile.heightCm = ValidationUtils.parseDouble(text(binding.inputHeight.getText()), 0);
        profile.weightKg = ValidationUtils.parseDouble(text(binding.inputWeight.getText()), 0);
        profile.experience = firstWordOrFull(text(binding.inputExperience.getText()));
        profile.goal = text(binding.inputGoal.getText());
        String freq = text(binding.inputFrequency.getText());
        profile.trainingDaysPerWeek = ValidationUtils.parseInt(freq.replaceAll("\\D+", ""), 3);

        String gymText = text(binding.inputGym.getText());
        if (!gymText.isEmpty()) {
            if (selectedGymName.equalsIgnoreCase(gymText)) {
                profile.gymId = selectedGymId;
                profile.gymName = selectedGymName;
            } else {
                profile.gymId = "";
                profile.gymName = gymText;
            }
        }

        setLoading(true);
        auth.signUp(profile, text(binding.inputPassword.getText()), new Callback<FirebaseUser>() {
            @Override
            public void onSuccess(FirebaseUser result) {
                setLoading(false);
                startActivity(new Intent(SignUpActivity.this, MainActivity.class));
                finish();
            }

            @Override
            public void onError(Exception e) {
                setLoading(false);
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, SignUpActivity.this));
            }
        });
    }

    private void setLoading(boolean loading) {
        binding.progress.setVisibility(loading ? View.VISIBLE : View.GONE);
        binding.buttonContinue.setEnabled(!loading);
    }

    private static String text(CharSequence cs) {
        return cs == null ? "" : cs.toString().trim();
    }

    private static String firstWordOrFull(String s) {
        if (s == null || s.isEmpty()) return "";
        return s;
    }
}
