package com.gymfit.app.ui.notifications;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.AppNotification;
import com.gymfit.app.data.repository.NotificationRepository;
import com.gymfit.app.databinding.ActivityNotificationsBinding;
import com.gymfit.app.databinding.ItemNotificationBinding;
import com.gymfit.app.ui.messages.ChatActivity;
import com.gymfit.app.ui.profile.ChallengesActivity;
import com.gymfit.app.ui.social.CommentsActivity;
import com.gymfit.app.ui.social.UserProfileActivity;
import com.gymfit.app.util.DateUtils;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.UiUtils;

import java.util.ArrayList;
import java.util.List;

/** In-app notification inbox, newest first. Tapping marks read and deep-links. */
public class NotificationsActivity extends AppCompatActivity {

    private ActivityNotificationsBinding binding;
    private final NotificationRepository repo = new NotificationRepository();
    private final List<AppNotification> items = new ArrayList<>();
    private NotificationAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityNotificationsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.buttonBack.setOnClickListener(v -> finish());
        binding.buttonMarkAll.setOnClickListener(v -> markAllRead());

        binding.recyclerNotifications.setLayoutManager(new LinearLayoutManager(this));
        adapter = new NotificationAdapter();
        binding.recyclerNotifications.setAdapter(adapter);

        if (!FirebaseState.isReady(this)) {
            binding.bannerFirebase.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }

    private void load() {
        String uid = Session.uid();
        if (!FirebaseState.isReady(this) || uid == null) {
            binding.progressBar.setVisibility(View.GONE);
            binding.emptyState.setVisibility(View.VISIBLE);
            binding.buttonMarkAll.setVisibility(View.GONE);
            return;
        }
        binding.progressBar.setVisibility(View.VISIBLE);
        repo.getNotifications(uid, new Callback<List<AppNotification>>() {
            @Override
            public void onSuccess(List<AppNotification> result) {
                if (isFinishing()) return;
                items.clear();
                if (result != null) items.addAll(result);
                binding.progressBar.setVisibility(View.GONE);
                adapter.notifyDataSetChanged();
                binding.emptyState.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
                binding.buttonMarkAll.setVisibility(hasUnread() ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onError(Exception e) {
                binding.progressBar.setVisibility(View.GONE);
                binding.emptyState.setVisibility(View.VISIBLE);
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, NotificationsActivity.this));
            }
        });
    }

    private boolean hasUnread() {
        for (AppNotification n : items) {
            if (!n.read) return true;
        }
        return false;
    }

    private void markAllRead() {
        String uid = Session.uid();
        if (uid == null) return;
        repo.markAllRead(uid, items);
        for (AppNotification n : items) n.read = true;
        adapter.notifyDataSetChanged();
        binding.buttonMarkAll.setVisibility(View.GONE);
        UiUtils.snack(binding.getRoot(), getString(R.string.notifications_cleared));
    }

    private void open(AppNotification n) {
        if (!n.read) {
            n.read = true;
            repo.markRead(n.id);
        }
        if (n.linkId == null || n.linkId.isEmpty()) {
            if (AppNotification.TYPE_CHALLENGE.equals(n.type)) {
                startActivity(new Intent(this, ChallengesActivity.class));
            }
            return;
        }
        Intent i;
        switch (n.type == null ? "" : n.type) {
            case AppNotification.TYPE_KUDOS:
            case AppNotification.TYPE_COMMENT:
                i = new Intent(this, CommentsActivity.class);
                i.putExtra(CommentsActivity.EXTRA_ACTIVITY_ID, n.linkId);
                break;
            case AppNotification.TYPE_FRIEND_REQUEST:
            case AppNotification.TYPE_FRIEND_ACCEPTED:
                i = new Intent(this, UserProfileActivity.class);
                i.putExtra(UserProfileActivity.EXTRA_UID, n.actorId);
                break;
            case AppNotification.TYPE_MESSAGE:
                i = new Intent(this, ChatActivity.class);
                i.putExtra(ChatActivity.EXTRA_OTHER_UID, n.actorId);
                i.putExtra(ChatActivity.EXTRA_OTHER_NAME, n.actorName);
                i.putExtra(ChatActivity.EXTRA_CHAT_ID, n.linkId);
                break;
            case AppNotification.TYPE_CHALLENGE:
                i = new Intent(this, ChallengesActivity.class);
                break;
            default:
                return;
        }
        startActivity(i);
    }

    private class NotificationAdapter extends RecyclerView.Adapter<NotificationHolder> {
        @NonNull
        @Override
        public NotificationHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new NotificationHolder(ItemNotificationBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull NotificationHolder holder, int position) {
            AppNotification n = items.get(position);
            ItemNotificationBinding b = holder.binding;
            b.textTitle.setText(n.title == null ? "" : n.title);
            b.textBody.setText(n.body == null ? "" : n.body);
            b.textTime.setText(DateUtils.relativeTime(n.createdAt));
            UiUtils.loadAvatar(b.imageAvatar, null, n.actorName, b.textInitials);
            b.dotUnread.setVisibility(n.read ? View.GONE : View.VISIBLE);
            b.textTitle.setTextColor(ContextCompat.getColor(NotificationsActivity.this,
                    n.read ? R.color.text_secondary : R.color.text_primary));
            b.rowRoot.setBackgroundColor(ContextCompat.getColor(NotificationsActivity.this,
                    n.read ? R.color.bg_primary : R.color.bg_surface));
            b.getRoot().setOnClickListener(v -> open(n));
        }

        @Override
        public int getItemCount() {
            return items.size();
        }
    }

    private static class NotificationHolder extends RecyclerView.ViewHolder {
        final ItemNotificationBinding binding;

        NotificationHolder(ItemNotificationBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
