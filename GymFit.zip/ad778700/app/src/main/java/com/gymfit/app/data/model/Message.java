package com.gymfit.app.data.model;

/** A chat message. Stored in `chats/{chatId}/messages/{id}`. */
public class Message {

    public String id;
    public String senderId;
    public String text;
    public long createdAt;

    public Message() {
    }

    public Message(String senderId, String text) {
        this.senderId = senderId;
        this.text = text;
        this.createdAt = System.currentTimeMillis();
    }
}
