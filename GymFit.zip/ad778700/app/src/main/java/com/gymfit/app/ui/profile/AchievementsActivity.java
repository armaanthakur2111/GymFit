package com.gymfit.app.ui.profile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.repository.UserRepository;
import com.gymfit.app.data.service.AchievementDefs;
import com.gymfit.app.databinding.ActivityAchievementsBinding;
import com.gymfit.app.databinding.ItemAchievementBinding;
import com.gymfit.app.util.FirebaseState;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Badge gallery: earned badges highlighted, locked badges dimmed. */
public class AchievementsActivity extends AppCompatActivity {

    private ActivityAchievementsBinding binding;
    private final UserRepository userRepo = new UserRepository();
    private final List<AchievementDefs.Badge> badges = new ArrayList<>();
    private Set<String> earned = new HashSet<>();
    private BadgeAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAchievementsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.buttonBack.setOnClickListener(v -> finish());

        for (AchievementDefs.Badge b : AchievementDefs.all()) badges.add(b);

        binding.recyclerBadges.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new BadgeAdapter();
        binding.recyclerBadges.setAdapter(adapter);

        User u = Session.profile();
        if (u != null) {
            earned = toSet(u.earnedBadges);
            updateSummary();
        }
        refresh();
    }

    private void refresh() {
        String uid = Session.uid();
        if (!FirebaseState.isReady(this) || uid == null) {
            adapter.notifyDataSetChanged();
            return;
        }
        userRepo.getUser(uid, new Callback<User>() {
            @Override
            public void onSuccess(User result) {
                if (result == null || isFinishing()) return;
                Session.setProfile(result);
                earned = toSet(result.earnedBadges);
                updateSummary();
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onError(Exception e) {
                adapter.notifyDataSetChanged();
            }
        });
    }

    private void updateSummary() {
        binding.textSummary.setText(getString(R.string.achievements_progress, earned.size(), badges.size()));
    }

    private static Set<String> toSet(List<String> list) {
        Set<String> set = new HashSet<>();
        if (list != null) set.addAll(list);
        return set;
    }

    private class BadgeAdapter extends RecyclerView.Adapter<BadgeHolder> {

        @NonNull
        @Override
        public BadgeHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ItemAchievementBinding b = ItemAchievementBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false);
            return new BadgeHolder(b);
        }

        @Override
        public void onBindViewHolder(@NonNull BadgeHolder holder, int position) {
            AchievementDefs.Badge badge = badges.get(position);
            boolean isEarned = earned.contains(badge.id);
            holder.binding.imageIcon.setImageResource(badge.iconRes);
            holder.binding.imageIcon.setColorFilter(ContextCompat.getColor(
                    AchievementsActivity.this, isEarned ? R.color.accent_gold : R.color.text_tertiary));
            holder.binding.textTitle.setText(badge.title);
            holder.binding.textDesc.setText(badge.description);
            holder.binding.textState.setText(isEarned ? R.string.achievement_earned : R.string.achievement_locked);
            holder.binding.textState.setTextColor(ContextCompat.getColor(
                    AchievementsActivity.this, isEarned ? R.color.accent_green : R.color.text_tertiary));
            holder.binding.getRoot().setAlpha(isEarned ? 1f : 0.6f);
        }

        @Override
        public int getItemCount() {
            return badges.size();
        }
    }

    private static class BadgeHolder extends RecyclerView.ViewHolder {
        final ItemAchievementBinding binding;

        BadgeHolder(ItemAchievementBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
