package com.gymfit.app.ui.auth;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.repository.AuthRepository;
import com.gymfit.app.databinding.ActivityForgotPasswordBinding;
import com.gymfit.app.util.UiUtils;
import com.gymfit.app.util.ValidationUtils;

public class ForgotPasswordActivity extends AppCompatActivity {

    private ActivityForgotPasswordBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityForgotPasswordBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.buttonBack.setOnClickListener(v -> finish());
        binding.buttonReset.setOnClickListener(v -> {
            String email = binding.inputEmail.getText() == null ? "" : binding.inputEmail.getText().toString();
            if (!ValidationUtils.isValidEmail(email)) {
                binding.layoutEmail.setError(getString(R.string.error_invalid_email));
                return;
            }
            binding.layoutEmail.setError(null);
            binding.progress.setVisibility(View.VISIBLE);
            binding.buttonReset.setEnabled(false);
            new AuthRepository().sendPasswordReset(email, new Callback<Void>() {
                @Override
                public void onSuccess(Void result) {
                    binding.progress.setVisibility(View.GONE);
                    UiUtils.snack(binding.getRoot(), getString(R.string.auth_reset_sent));
                    finish();
                }

                @Override
                public void onError(Exception e) {
                    binding.progress.setVisibility(View.GONE);
                    binding.buttonReset.setEnabled(true);
                    UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, ForgotPasswordActivity.this));
                }
            });
        });
    }
}
