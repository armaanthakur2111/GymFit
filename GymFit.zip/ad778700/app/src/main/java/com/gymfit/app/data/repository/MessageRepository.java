package com.gymfit.app.data.repository;

import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.ListenerRegistration;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Db;
import com.gymfit.app.data.model.AppNotification;
import com.gymfit.app.data.model.ChatRoom;
import com.gymfit.app.data.model.Message;
import com.gymfit.app.data.model.User;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** One-to-one messaging on Firestore: chats/{pairId} + chats/{pairId}/messages. */
public class MessageRepository {

    public void getChats(String uid, Callback<List<ChatRoom>> callback) {
        if (Db.chats() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.chats().whereArrayContains("participantIds", uid).get()
                .addOnSuccessListener(snapshot -> {
                    List<ChatRoom> rooms = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot) {
                        ChatRoom room = doc.toObject(ChatRoom.class);
                        if (room != null) {
                            room.id = doc.getId();
                            rooms.add(room);
                        }
                    }
                    rooms.sort((a, b) -> Long.compare(b.lastMessageAt, a.lastMessageAt));
                    callback.onSuccess(rooms);
                })
                .addOnFailureListener(callback::onError);
    }

    public void sendMessage(User me, User other, String text, Callback<Void> callback) {
        if (Db.chats() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        String chatId = ChatRoom.chatIdFor(me.uid, other.uid);
        Message message = new Message(me.uid, text.trim());

        Map<String, Object> room = new HashMap<>();
        room.put("id", chatId);
        room.put("participantIds", Arrays.asList(me.uid, other.uid));
        room.put("lastMessageText", message.text);
        room.put("lastSenderId", me.uid);
        room.put("lastMessageAt", message.createdAt);
        room.put("lastReadAt." + me.uid, message.createdAt);

        Db.chats().document(chatId).set(room, com.google.firebase.firestore.SetOptions.merge())
                .addOnSuccessListener(v -> Db.chats().document(chatId)
                        .collection(Db.MESSAGES).add(message))
                .addOnSuccessListener(ref -> {
                    NotificationRepository.push(other.uid, AppNotification.TYPE_MESSAGE,
                            "New message from " + me.firstName(), message.text,
                            me.uid, me.name, chatId);
                    callback.onSuccess(null);
                })
                .addOnFailureListener(callback::onError);
    }

    public ListenerRegistration listenMessages(String chatId, Callback<List<Message>> callback) {
        if (Db.chats() == null) return null;
        return Db.chats().document(chatId).collection(Db.MESSAGES)
                .limit(500)
                .addSnapshotListener((snapshot, error) -> {
                    if (error != null || snapshot == null) {
                        callback.onError(error != null ? error : new IllegalStateException("No snapshot"));
                        return;
                    }
                    List<Message> messages = new ArrayList<>();
                    for (DocumentChange change : snapshot.getDocumentChanges()) {
                        Message m = change.getDocument().toObject(Message.class);
                        m.id = change.getDocument().getId();
                        messages.add(m);
                    }
                    // Keep the full sorted list from the snapshot, not just changes.
                    List<Message> all = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        Message m = doc.toObject(Message.class);
                        if (m != null) {
                            m.id = doc.getId();
                            all.add(m);
                        }
                    }
                    all.sort((a, b) -> Long.compare(a.createdAt, b.createdAt));
                    callback.onSuccess(all);
                });
    }

    public void markRead(String uid, String chatId) {
        if (Db.chats() == null) return;
        Db.chats().document(chatId).update("lastReadAt." + uid, System.currentTimeMillis());
    }

    public ListenerRegistration listenRoom(String chatId, Callback<ChatRoom> callback) {
        if (Db.chats() == null) return null;
        return Db.chats().document(chatId).addSnapshotListener((doc, error) -> {
            if (error != null) {
                callback.onError(error);
                return;
            }
            if (doc != null && doc.exists()) {
                ChatRoom room = doc.toObject(ChatRoom.class);
                if (room != null) {
                    room.id = doc.getId();
                    callback.onSuccess(room);
                }
            }
        });
    }
}
