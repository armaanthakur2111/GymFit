package com.gymfit.app.data.model;

/** In-app notification. Stored in `notifications/{id}`. */
public class AppNotification {

    public static final String TYPE_KUDOS = "KUDOS";
    public static final String TYPE_COMMENT = "COMMENT";
    public static final String TYPE_FRIEND_REQUEST = "FRIEND_REQUEST";
    public static final String TYPE_FRIEND_ACCEPTED = "FRIEND_ACCEPTED";
    public static final String TYPE_PR = "PR";
    public static final String TYPE_STREAK = "STREAK";
    public static final String TYPE_CHALLENGE = "CHALLENGE";
    public static final String TYPE_MESSAGE = "MESSAGE";
    public static final String TYPE_AI = "AI";

    public String id;
    public String userId;       // recipient
    public String type;
    public String title;
    public String body;
    public String actorId;
    public String actorName;
    public String linkId;       // activityId / chatId / requestId depending on type
    public boolean read;
    public long createdAt;

    public AppNotification() {
    }

    public AppNotification(String userId, String type, String title, String body,
                           String actorId, String actorName, String linkId) {
        this.userId = userId;
        this.type = type;
        this.title = title;
        this.body = body;
        this.actorId = actorId;
        this.actorName = actorName;
        this.linkId = linkId;
        this.createdAt = System.currentTimeMillis();
    }
}
