
package com.gymfit.app.data.service;

import com.google.firebase.firestore.DocumentSnapshot;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Db;
import com.gymfit.app.data.model.LeaderboardEntry;
import com.gymfit.app.data.model.User;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Transparent leaderboard scoring. All components are 0–100:
 *
 * Consistency = 40 * min(1, workoutsLast28 / (plannedDays * 4))
 *             + 40 * min(1, currentStreak / 14)
 *             + 20 * min(1, longestStreak / 30)
 *
 * Strength = min(100, relativeBigThree / 4.0 * 100)
 *
 * Progress = min(60, prsLast30 * 12)
 *            + 40 * clamp(volumeGrowth28d, 0..1)
 *
 * Volume = min(100, volumeLast28Kg / 60000 * 100)
 *
 * Overall = 0.30 * Consistency + 0.25 * Strength
 *           + 0.25 * Progress + 0.20 * Volume
 */
public class LeaderboardService {

    public static final String CAT_OVERALL = "overall";
    public static final String CAT_STRENGTH = "strength";
    public static final String CAT_CONSISTENCY = "consistency";
    public static final String CAT_PROGRESS = "progress";
    public static final String CAT_VOLUME = "volume";

    public void getLeaderboard(
            String category,
            String gymIdFilter,
            String goalFilter,
            String weightClassFilter,
            String experienceFilter,
            Callback<List<LeaderboardEntry>> callback) {

        if (Db.publicProfiles() == null) {
            callback.onError(
                    new IllegalStateException("Firestore unavailable"));
            return;
        }

        Db.publicProfiles()
                .whereEqualTo("showOnLeaderboard", true)
                .limit(200)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<LeaderboardEntry> entries = new ArrayList<>();

                    for (DocumentSnapshot doc : snapshot) {
                        User u = doc.toObject(User.class);

                        if (u == null || !u.showOnLeaderboard) {
                            continue;
                        }

                        if (gymIdFilter != null
                                && !gymIdFilter.equals(u.gymId)) {
                            continue;
                        }

                        if (goalFilter != null
                                && !goalFilter.equals(u.goal)) {
                            continue;
                        }

                        if (weightClassFilter != null
                                && !weightClassFilter.equals(u.weightClass())) {
                            continue;
                        }

                        if (experienceFilter != null
                                && !experienceFilter.equals(u.experience)) {
                            continue;
                        }

                        entries.add(score(u));
                    }

                    sort(entries, category);

                    for (int i = 0; i < entries.size(); i++) {
                        entries.get(i).rank = i + 1;
                    }

                    callback.onSuccess(entries);
                })
                .addOnFailureListener(callback::onError);
    }

    public static LeaderboardEntry score(User u) {
        LeaderboardEntry e = new LeaderboardEntry(u);

        double planned = Math.max(1, u.trainingDaysPerWeek) * 4.0;

        double freqPart = Math.min(1, u.workoutsLast28 / planned);
        double streakPart = Math.min(1, u.currentStreak / 14.0);
        double longestPart = Math.min(1, u.longestStreak / 30.0);

        e.consistencyScore =
                40 * freqPart
                        + 40 * streakPart
                        + 20 * longestPart;

        double bw = u.weightKg > 0 ? u.weightKg : 75;

        double relative =
                (u.bestBenchE1rm
                        + u.bestSquatE1rm
                        + u.bestDeadliftE1rm) / bw;

        e.strengthScore = Math.min(100, relative / 4.0 * 100);

        double growth =
                (u.volumeLast28Kg - u.volumePrev28Kg)
                        / Math.max(u.volumePrev28Kg, 1);

        growth = Math.max(0, Math.min(1, growth));

        e.progressScore =
                Math.min(60, u.prsLast30 * 12.0)
                        + 40 * growth;

        e.volumeScore =
                Math.min(100, u.volumeLast28Kg / 60000.0 * 100);

        e.overallScore =
                0.30 * e.consistencyScore
                        + 0.25 * e.strengthScore
                        + 0.25 * e.progressScore
                        + 0.20 * e.volumeScore;

        return e;
    }

    public static void sort(
            List<LeaderboardEntry> entries,
            String category) {

        Comparator<LeaderboardEntry> by = comparatorFor(category);

        Collections.sort(entries, (a, b) ->
                by.compare(b, a));
    }

    private static Comparator<LeaderboardEntry> comparatorFor(
            String category) {

        switch (category == null ? CAT_OVERALL : category) {
            case CAT_STRENGTH:
                return (a, b) ->
                        Double.compare(a.strengthScore, b.strengthScore);

            case CAT_CONSISTENCY:
                return (a, b) ->
                        Double.compare(a.consistencyScore, b.consistencyScore);

            case CAT_PROGRESS:
                return (a, b) ->
                        Double.compare(a.progressScore, b.progressScore);

            case CAT_VOLUME:
                return (a, b) ->
                        Double.compare(a.volumeScore, b.volumeScore);

            default:
                return (a, b) ->
                        Double.compare(a.overallScore, b.overallScore);
        }
    }

    public static double scoreFor(
            LeaderboardEntry e,
            String category) {

        switch (category == null ? CAT_OVERALL : category) {
            case CAT_STRENGTH:
                return e.strengthScore;

            case CAT_CONSISTENCY:
                return e.consistencyScore;

            case CAT_PROGRESS:
                return e.progressScore;

            case CAT_VOLUME:
                return e.volumeScore;

            default:
                return e.overallScore;
        }
    }
}
