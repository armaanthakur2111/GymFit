
package com.gymfit.app.data;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

/** Single entry point for Firestore collections so names never drift apart. */
public final class Db {

    public static final String USERS = "users";
    public static final String PUBLIC_PROFILES = "publicProfiles";
    public static final String WORKOUTS = "workouts";
    public static final String TEMPLATES = "workoutTemplates";
    public static final String FRIENDSHIPS = "friendships";
    public static final String ACTIVITIES = "activities";
    public static final String KUDOS = "kudos";
    public static final String COMMENTS = "comments";
    public static final String CHATS = "chats";
    public static final String MESSAGES = "messages";
    public static final String PRS = "personalRecords";
    public static final String NOTIFICATIONS = "notifications";
    public static final String GYMS = "gyms";
    public static final String BODY_WEIGHTS = "bodyWeights";

    private Db() {
    }

    /** Returns null if Firestore cannot be initialized. */
    public static FirebaseFirestore get() {
        try {
            return FirebaseFirestore.getInstance();
        } catch (Exception e) {
            return null;
        }
    }

    public static CollectionReference users() {
        FirebaseFirestore db = get();
        return db == null ? null : db.collection(USERS);
    }

    public static CollectionReference publicProfiles() {
        FirebaseFirestore db = get();
        return db == null ? null : db.collection(PUBLIC_PROFILES);
    }

    public static CollectionReference workouts() {
        FirebaseFirestore db = get();
        return db == null ? null : db.collection(WORKOUTS);
    }

    public static CollectionReference templates() {
        FirebaseFirestore db = get();
        return db == null ? null : db.collection(TEMPLATES);
    }

    public static CollectionReference friendships() {
        FirebaseFirestore db = get();
        return db == null ? null : db.collection(FRIENDSHIPS);
    }

    public static CollectionReference activities() {
        FirebaseFirestore db = get();
        return db == null ? null : db.collection(ACTIVITIES);
    }

    public static CollectionReference kudos() {
        FirebaseFirestore db = get();
        return db == null ? null : db.collection(KUDOS);
    }

    public static CollectionReference comments() {
        FirebaseFirestore db = get();
        return db == null ? null : db.collection(COMMENTS);
    }

    public static CollectionReference chats() {
        FirebaseFirestore db = get();
        return db == null ? null : db.collection(CHATS);
    }

    public static CollectionReference personalRecords() {
        FirebaseFirestore db = get();
        return db == null ? null : db.collection(PRS);
    }

    public static CollectionReference notifications() {
        FirebaseFirestore db = get();
        return db == null ? null : db.collection(NOTIFICATIONS);
    }

    public static CollectionReference gyms() {
        FirebaseFirestore db = get();
        return db == null ? null : db.collection(GYMS);
    }
}
