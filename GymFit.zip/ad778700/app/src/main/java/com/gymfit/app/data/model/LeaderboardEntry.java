package com.gymfit.app.data.model;

/** Computed leaderboard row (view model, never persisted). */
public class LeaderboardEntry {

    public User user;
    public int rank;
    public double overallScore;
    public double consistencyScore;
    public double strengthScore;
    public double progressScore;
    public double volumeScore;

    public LeaderboardEntry(User user) {
        this.user = user;
    }
}
