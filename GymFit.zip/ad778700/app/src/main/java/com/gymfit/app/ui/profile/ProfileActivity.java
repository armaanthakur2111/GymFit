package com.gymfit.app.ui.profile;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.LeaderboardEntry;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.repository.AuthRepository;
import com.gymfit.app.data.repository.UserRepository;
import com.gymfit.app.data.service.LeaderboardService;
import com.gymfit.app.databinding.ActivityProfileBinding;
import com.gymfit.app.databinding.ItemDetailRowBinding;
import com.gymfit.app.ui.auth.LoginActivity;
import com.gymfit.app.util.DateUtils;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.FormatUtils;
import com.gymfit.app.util.UiUtils;

import java.util.List;
import java.util.Locale;

/** Current-user profile: identity, rank, aggregate stats, details and navigation to sub-screens. */
public class ProfileActivity extends AppCompatActivity {

    private ActivityProfileBinding binding;
    private final UserRepository userRepo = new UserRepository();
    private final LeaderboardService leaderboardService = new LeaderboardService();
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.buttonBack.setOnClickListener(v -> finish());
        binding.buttonEdit.setOnClickListener(v ->
                startActivity(new Intent(this, EditProfileActivity.class)));

        setupStatDefaults();
        setupMenu();
        binding.buttonLogout.setOnClickListener(v -> confirmLogout());

        user = Session.profile();
        if (user != null) bind(user);
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        String uid = Session.uid();
        if (!FirebaseState.isReady(this) || uid == null) return;
        userRepo.getUser(uid, new Callback<User>() {
            @Override
            public void onSuccess(User result) {
                if (result == null || isFinishing()) return;
                user = result;
                Session.setProfile(result);
                bind(result);
                loadRank(result.uid);
            }

            @Override
            public void onError(Exception e) {
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, ProfileActivity.this));
            }
        });
    }

    private void setupStatDefaults() {
        bindStat(binding.statStreak.imageIcon, binding.statStreak.textValue, binding.statStreak.textLabel,
                R.drawable.ic_fire, "0", R.string.day_streak);
        bindStat(binding.statWorkouts.imageIcon, binding.statWorkouts.textValue, binding.statWorkouts.textLabel,
                R.drawable.ic_dumbbell, "0", R.string.total_workouts);
        bindStat(binding.statVolume.imageIcon, binding.statVolume.textValue, binding.statVolume.textLabel,
                R.drawable.ic_volume, FormatUtils.compactKg(0), R.string.total_volume);
        bindStat(binding.statPrs.imageIcon, binding.statPrs.textValue, binding.statPrs.textLabel,
                R.drawable.ic_medal, "0", R.string.pr_count);
    }

    private void setupMenu() {
        bindRow(binding.rowAchievements.imageIcon, binding.rowAchievements.textLabel,
                binding.rowAchievements.getRoot(), R.drawable.ic_trophy, R.string.achievements,
                () -> startActivity(new Intent(this, AchievementsActivity.class)));
        bindRow(binding.rowChallenges.imageIcon, binding.rowChallenges.textLabel,
                binding.rowChallenges.getRoot(), R.drawable.ic_target, R.string.challenges,
                () -> startActivity(new Intent(this, ChallengesActivity.class)));
        bindRow(binding.rowSettings.imageIcon, binding.rowSettings.textLabel,
                binding.rowSettings.getRoot(), R.drawable.ic_settings, R.string.settings,
                () -> startActivity(new Intent(this, SettingsActivity.class)));
        bindRow(binding.rowPrivacy.imageIcon, binding.rowPrivacy.textLabel,
                binding.rowPrivacy.getRoot(), R.drawable.ic_lock, R.string.privacy,
                () -> startActivity(new Intent(this, SettingsActivity.class)
                        .putExtra(SettingsActivity.EXTRA_SECTION, SettingsActivity.SECTION_PRIVACY)));
        bindRow(binding.rowNotifications.imageIcon, binding.rowNotifications.textLabel,
                binding.rowNotifications.getRoot(), R.drawable.ic_notification, R.string.notifications,
                () -> startActivity(new Intent(this, SettingsActivity.class)
                        .putExtra(SettingsActivity.EXTRA_SECTION, SettingsActivity.SECTION_NOTIFICATIONS)));
    }

    private void bind(User u) {
        UiUtils.loadAvatar(binding.imageAvatar, u.photoUrl, u.name, binding.textInitials);
        binding.textName.setText(u.name == null ? getString(R.string.profile) : u.name);

        List<String> meta = new java.util.ArrayList<>();
        int age = DateUtils.ageFromDob(u.dob);
        if (age > 0) meta.add(age + " " + getString(R.string.age));
        if (u.heightCm > 0) meta.add(String.format(Locale.US, "%.0f cm", u.heightCm));
        if (u.weightKg > 0) meta.add(FormatUtils.kg(u.weightKg));
        binding.textMeta.setText(join(meta, "  ·  "));

        binding.statStreak.textValue.setText(String.valueOf(u.currentStreak));
        binding.statWorkouts.textValue.setText(String.valueOf(u.totalWorkouts));
        binding.statVolume.textValue.setText(FormatUtils.compactKg(u.totalVolumeKg));
        binding.statPrs.textValue.setText(String.valueOf(u.totalPrs));

        renderDetails(u);
    }

    private void renderDetails(User u) {
        binding.containerDetails.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(this);
        if (u.goal != null && !u.goal.isEmpty()) addDetail(inflater, R.string.goal, u.goal);
        if (u.experience != null && !u.experience.isEmpty()) addDetail(inflater, R.string.experience, u.experience);
        addDetail(inflater, R.string.gym, u.gymName == null || u.gymName.isEmpty() ? "—" : u.gymName);
        if (u.targetWeightKg > 0) {
            addDetail(inflater, R.string.weight_trend, FormatUtils.kg(u.targetWeightKg));
        }
        int badges = u.earnedBadges == null ? 0 : u.earnedBadges.size();
        addDetail(inflater, R.string.achievements, String.valueOf(badges));
    }

    private void addDetail(LayoutInflater inflater, int labelRes, String value) {
        ItemDetailRowBinding row = ItemDetailRowBinding.inflate(inflater, binding.containerDetails, false);
        row.textLabel.setText(labelRes);
        row.textValue.setText(value);
        binding.containerDetails.addView(row.getRoot());
    }

    private void loadRank(String uid) {
        if (!FirebaseState.isReady(this)) return;
        leaderboardService.getLeaderboard(LeaderboardService.CAT_OVERALL, null, null, null, null,
                new Callback<List<LeaderboardEntry>>() {
                    @Override
                    public void onSuccess(List<LeaderboardEntry> entries) {
                        if (isFinishing()) return;
                        int total = entries.size();
                        LeaderboardEntry mine = null;
                        for (LeaderboardEntry e : entries) {
                            if (e.user != null && uid.equals(e.user.uid)) {
                                mine = e;
                                break;
                            }
                        }
                        if (mine == null) {
                            binding.textRank.setText("—");
                            binding.textRankDetail.setText(R.string.no_leaderboard_data);
                            return;
                        }
                        binding.textRank.setText(getString(R.string.rank_hash, mine.rank));
                        binding.textRankDetail.setText(String.format(Locale.US,
                                "of %d athletes · %.0f pts", total, mine.overallScore));
                    }

                    @Override
                    public void onError(Exception e) {
                        binding.textRank.setText("—");
                        binding.textRankDetail.setText(R.string.no_leaderboard_data);
                    }
                });
    }

    private void confirmLogout() {
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.logout)
                .setMessage(R.string.logout_confirm)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.logout, (d, w) -> {
                    new AuthRepository().logout();
                    Session.clear();
                    Intent intent = new Intent(this, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                })
                .show();
    }

    private void bindStat(ImageView icon, TextView value, TextView label,
                          int iconRes, String valueText, int labelRes) {
        icon.setImageResource(iconRes);
        value.setText(valueText);
        label.setText(labelRes);
    }

    private void bindRow(ImageView icon, TextView label, android.view.View root,
                         int iconRes, int labelRes, Runnable onClick) {
        icon.setImageResource(iconRes);
        icon.setColorFilter(ContextCompat.getColor(this, R.color.text_secondary));
        label.setText(labelRes);
        root.setOnClickListener(v -> onClick.run());
    }

    private static String join(List<String> parts, String sep) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) sb.append(sep);
            sb.append(parts.get(i));
        }
        return sb.toString();
    }
}
