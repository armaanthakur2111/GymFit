package com.gymfit.app.data.service;

import com.google.firebase.firestore.DocumentSnapshot;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Db;
import com.gymfit.app.data.model.ExerciseEntry;
import com.gymfit.app.data.model.PersonalRecord;
import com.gymfit.app.data.model.SetLog;
import com.gymfit.app.data.model.Workout;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * PR detection. The best-ever value per (user, exercise, type) lives in
 * `personalRecords`. The very first logged workout silently writes baseline
 * records (isBaseline semantics: previousValue == 0), which are not celebrated.
 */
public class PrService {

    /** Compares the finished workout against stored bests; returns newly celebrated PRs. */
    public void detectPrs(String uid, Workout workout, Callback<List<PersonalRecord>> callback) {
        if (Db.personalRecords() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        // One fetch of all the user's PR docs, then everything else is in-memory.
        Db.personalRecords().whereEqualTo("userId", uid).get()
                .addOnSuccessListener(snapshot -> {
                    Map<String, PersonalRecord> bests = new HashMap<>();
                    for (DocumentSnapshot doc : snapshot) {
                        PersonalRecord pr = doc.toObject(PersonalRecord.class);
                        if (pr == null || pr.type == null || pr.exerciseName == null) continue;
                        String key = pr.exerciseName + "|" + pr.type;
                        PersonalRecord current = bests.get(key);
                        if (current == null || pr.value > current.value) {
                            pr.id = doc.getId();
                            bests.put(key, pr);
                        }
                    }

                    List<PersonalRecord> newPrs = new ArrayList<>();
                    List<PersonalRecord> toSave = new ArrayList<>();

                    for (ExerciseEntry entry : workout.completedEntries()) {
                        collect(uid, workout, entry, bests, PersonalRecord.TYPE_WEIGHT,
                                entry.bestWeight(), "kg", newPrs, toSave);
                        collect(uid, workout, entry, bests, PersonalRecord.TYPE_E1RM,
                                entry.bestE1rm(), "kg", newPrs, toSave);
                        collect(uid, workout, entry, bests, PersonalRecord.TYPE_VOLUME,
                                entry.volume(), "kg", newPrs, toSave);
                        collect(uid, workout, entry, bests, PersonalRecord.TYPE_REPS,
                                maxReps(entry), "reps", newPrs, toSave);
                    }

                    saveAll(toSave, newPrs, workout, callback);
                })
                .addOnFailureListener(callback::onError);
    }

    private int maxReps(ExerciseEntry entry) {
        int max = 0;
        for (SetLog s : entry.sets) {
            if (s.completed && s.weightKg > 0) max = Math.max(max, s.reps);
        }
        return max;
    }

    private void collect(String uid, Workout workout, ExerciseEntry entry,
                         Map<String, PersonalRecord> bests, String type,
                         double newValue, String unit,
                         List<PersonalRecord> celebrated, List<PersonalRecord> toSave) {
        if (newValue <= 0) return;
        PersonalRecord best = bests.get(entry.exerciseName + "|" + type);
        if (best == null) {
            // Silent baseline — first time this exercise is ever logged.
            toSave.add(new PersonalRecord(uid, entry.exerciseName, type, newValue, 0, unit, workout.id));
        } else if (newValue > best.value + 1e-9) {
            PersonalRecord pr = new PersonalRecord(uid, entry.exerciseName, type,
                    newValue, best.value, unit, workout.id);
            celebrated.add(pr);
            toSave.add(pr);
        }
    }

    private void saveAll(List<PersonalRecord> records, List<PersonalRecord> celebrated,
                         Workout workout, Callback<List<PersonalRecord>> callback) {
        if (records.isEmpty()) {
            workout.prCount = 0;
            callback.onSuccess(celebrated);
            return;
        }
        final int[] remaining = {records.size()};
        final boolean[] failed = {false};
        for (PersonalRecord pr : records) {
            Db.personalRecords().add(pr).addOnCompleteListener(task -> {
                if (!task.isSuccessful()) failed[0] = true;
                if (--remaining[0] == 0) {
                    workout.prCount = celebrated.size();
                    callback.onSuccess(celebrated);
                }
            });
        }
    }
}
