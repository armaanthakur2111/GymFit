package com.gymfit.app.ui.messages;

import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.ListenerRegistration;
import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.ChatRoom;
import com.gymfit.app.data.model.Message;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.repository.MessageRepository;
import com.gymfit.app.databinding.ActivityChatBinding;
import com.gymfit.app.databinding.ItemMessageBinding;
import com.gymfit.app.util.DateUtils;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.UiUtils;

import java.util.ArrayList;
import java.util.List;

/** One-to-one realtime chat. */
public class ChatActivity extends AppCompatActivity {

    public static final String EXTRA_OTHER_UID = "otherUid";
    public static final String EXTRA_OTHER_NAME = "otherName";
    public static final String EXTRA_CHAT_ID = "chatId";

    private ActivityChatBinding binding;
    private final MessageRepository messageRepo = new MessageRepository();
    private final List<Message> messages = new ArrayList<>();
    private MessageAdapter adapter;
    private ListenerRegistration registration;

    private String otherUid;
    private String chatId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.buttonBack.setOnClickListener(v -> finish());

        otherUid = getIntent().getStringExtra(EXTRA_OTHER_UID);
        String otherName = getIntent().getStringExtra(EXTRA_OTHER_NAME);
        if (otherName != null && !otherName.isEmpty()) binding.textTitle.setText(otherName);

        String myUid = Session.uid();
        chatId = getIntent().getStringExtra(EXTRA_CHAT_ID);
        if (chatId == null && myUid != null && otherUid != null) {
            chatId = ChatRoom.chatIdFor(myUid, otherUid);
        }

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        binding.recyclerMessages.setLayoutManager(layoutManager);
        adapter = new MessageAdapter();
        binding.recyclerMessages.setAdapter(adapter);

        binding.buttonSend.setOnClickListener(v -> send());

        if (!FirebaseState.isReady(this) || chatId == null || myUid == null || otherUid == null) {
            binding.buttonSend.setEnabled(false);
            return;
        }
        listen();
    }

    private void listen() {
        registration = messageRepo.listenMessages(chatId, new Callback<List<Message>>() {
            @Override
            public void onSuccess(List<Message> result) {
                if (isFinishing()) return;
                messages.clear();
                if (result != null) messages.addAll(result);
                adapter.notifyDataSetChanged();
                if (!messages.isEmpty()) {
                    binding.recyclerMessages.scrollToPosition(messages.size() - 1);
                }
                messageRepo.markRead(Session.uid(), chatId);
            }

            @Override
            public void onError(Exception e) {
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, ChatActivity.this));
            }
        });
    }

    private void send() {
        CharSequence cs = binding.inputMessage.getText();
        String text = cs == null ? "" : cs.toString().trim();
        User me = Session.profile();
        if (text.isEmpty() || me == null) return;
        User other = new User();
        other.uid = otherUid;
        binding.buttonSend.setEnabled(false);
        messageRepo.sendMessage(me, other, text, new Callback<Void>() {
            @Override
            public void onSuccess(Void result) {
                binding.buttonSend.setEnabled(true);
                binding.inputMessage.setText("");
            }

            @Override
            public void onError(Exception e) {
                binding.buttonSend.setEnabled(true);
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, ChatActivity.this));
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (chatId != null && Session.uid() != null) messageRepo.markRead(Session.uid(), chatId);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (registration != null) registration.remove();
    }

    private class MessageAdapter extends RecyclerView.Adapter<MessageHolder> {
        @NonNull
        @Override
        public MessageHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new MessageHolder(ItemMessageBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull MessageHolder holder, int position) {
            Message m = messages.get(position);
            boolean mine = Session.uid() != null && Session.uid().equals(m.senderId);
            holder.binding.textMessage.setText(m.text);
            holder.binding.textTime.setText(DateUtils.formatTime(m.createdAt));
            holder.binding.rowRoot.setGravity(mine ? Gravity.END : Gravity.START);
            holder.binding.bubble.setBackgroundResource(
                    mine ? R.drawable.bg_bubble_me : R.drawable.bg_bubble_other);
            holder.binding.textTime.setTextColor(ContextCompat.getColor(ChatActivity.this,
                    mine ? R.color.text_on_accent : R.color.text_tertiary));
        }

        @Override
        public int getItemCount() {
            return messages.size();
        }
    }

    private static class MessageHolder extends RecyclerView.ViewHolder {
        final ItemMessageBinding binding;

        MessageHolder(ItemMessageBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
