package com.gymfit.app.ui.social;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.ActivityPost;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.repository.FriendRepository;
import com.gymfit.app.data.repository.SocialRepository;
import com.gymfit.app.data.repository.UserRepository;
import com.gymfit.app.databinding.ActivityUserProfileBinding;
import com.gymfit.app.ui.messages.ChatActivity;
import com.gymfit.app.util.DateUtils;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.FormatUtils;
import com.gymfit.app.util.UiUtils;

import java.util.ArrayList;
import java.util.List;

/** Another athlete's profile: stats, public activity feed and friend/message actions. */
public class UserProfileActivity extends AppCompatActivity implements ActivityFeedAdapter.Listener {

    public static final String EXTRA_UID = "uid";

    private ActivityUserProfileBinding binding;
    private final UserRepository userRepo = new UserRepository();
    private final FriendRepository friendRepo = new FriendRepository();
    private final SocialRepository socialRepo = new SocialRepository();
    private ActivityFeedAdapter feedAdapter;

    private String otherUid;
    private User other;
    private boolean isFriend;
    private boolean requested;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUserProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.buttonBack.setOnClickListener(v -> finish());

        otherUid = getIntent().getStringExtra(EXTRA_UID);
        binding.recyclerActivity.setLayoutManager(new LinearLayoutManager(this));
        feedAdapter = new ActivityFeedAdapter(this);
        binding.recyclerActivity.setAdapter(feedAdapter);

        bindStat(binding.statStreak.imageIcon, binding.statStreak.textValue, binding.statStreak.textLabel,
                R.drawable.ic_fire, "0", R.string.day_streak);
        bindStat(binding.statWorkouts.imageIcon, binding.statWorkouts.textValue, binding.statWorkouts.textLabel,
                R.drawable.ic_dumbbell, "0", R.string.total_workouts);
        bindStat(binding.statVolume.imageIcon, binding.statVolume.textValue, binding.statVolume.textLabel,
                R.drawable.ic_volume, FormatUtils.compactKg(0), R.string.total_volume);
        bindStat(binding.statPrs.imageIcon, binding.statPrs.textValue, binding.statPrs.textLabel,
                R.drawable.ic_medal, "0", R.string.pr_count);

        binding.buttonFriend.setOnClickListener(v -> onFriendAction());
        binding.buttonMessage.setOnClickListener(v -> openChat());

        if (otherUid == null || otherUid.equals(Session.uid())) {
            startActivity(new Intent(this, com.gymfit.app.ui.profile.ProfileActivity.class));
            finish();
            return;
        }
        load();
    }

    private void load() {
        if (!FirebaseState.isReady(this)) return;
        userRepo.getUser(otherUid, new Callback<User>() {
            @Override
            public void onSuccess(User result) {
                if (result == null || isFinishing()) return;
                other = result;
                bindUser(result);
                resolveRelationship();
                loadActivity();
            }

            @Override
            public void onError(Exception e) {
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, UserProfileActivity.this));
            }
        });
    }

    private void bindUser(User u) {
        UiUtils.loadAvatar(binding.imageAvatar, u.photoUrl, u.name, binding.textInitials);
        binding.textName.setText(u.name == null ? "Athlete" : u.name);
        List<String> meta = new ArrayList<>();
        int age = DateUtils.ageFromDob(u.dob);
        if (age > 0) meta.add(age + " " + getString(R.string.age));
        if (u.goal != null && !u.goal.isEmpty()) meta.add(u.goal);
        if (u.gymName != null && !u.gymName.isEmpty() && u.showGymOnMap) meta.add(u.gymName);
        binding.textMeta.setText(join(meta));

        binding.statStreak.textValue.setText(String.valueOf(u.currentStreak));
        binding.statWorkouts.textValue.setText(String.valueOf(u.totalWorkouts));
        binding.statVolume.textValue.setText(FormatUtils.compactKg(u.totalVolumeKg));
        binding.statPrs.textValue.setText(String.valueOf(u.totalPrs));
    }

    private void resolveRelationship() {
        String uid = Session.uid();
        User me = Session.profile();
        requested = me != null && me.sentRequestIds != null && me.sentRequestIds.contains(otherUid);
        friendRepo.areFriends(uid, otherUid, new Callback<Boolean>() {
            @Override
            public void onSuccess(Boolean result) {
                isFriend = Boolean.TRUE.equals(result);
                updateFriendButton();
            }

            @Override
            public void onError(Exception e) {
                updateFriendButton();
            }
        });
        updateFriendButton();
    }

    private void updateFriendButton() {
        if (isFriend) {
            binding.buttonFriend.setText(R.string.remove_friend);
            binding.buttonFriend.setEnabled(true);
        } else if (requested) {
            binding.buttonFriend.setText(R.string.requested);
            binding.buttonFriend.setEnabled(false);
        } else {
            binding.buttonFriend.setText(R.string.add_friend);
            binding.buttonFriend.setEnabled(true);
        }
    }

    private void onFriendAction() {
        User me = Session.profile();
        if (me == null) return;
        if (isFriend) {
            friendRepo.removeFriend(me.uid, otherUid, new Callback<Void>() {
                @Override
                public void onSuccess(Void result) {
                    isFriend = false;
                    updateFriendButton();
                }

                @Override
                public void onError(Exception e) {
                    UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, UserProfileActivity.this));
                }
            });
            return;
        }
        friendRepo.sendRequest(me, otherUid, new Callback<Void>() {
            @Override
            public void onSuccess(Void result) {
                requested = true;
                userRepo.markRequestSent(me.uid, otherUid);
                if (me.sentRequestIds == null) me.sentRequestIds = new ArrayList<>();
                if (!me.sentRequestIds.contains(otherUid)) me.sentRequestIds.add(otherUid);
                Session.setProfile(me);
                updateFriendButton();
                UiUtils.snack(binding.getRoot(), getString(R.string.requested));
            }

            @Override
            public void onError(Exception e) {
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, UserProfileActivity.this));
            }
        });
    }

    private void openChat() {
        if (other == null) return;
        startActivity(new Intent(this, ChatActivity.class)
                .putExtra(ChatActivity.EXTRA_OTHER_UID, other.uid)
                .putExtra(ChatActivity.EXTRA_OTHER_NAME, other.firstName()));
    }

    private void loadActivity() {
        if (other == null) return;
        boolean publicOnly = !other.publicProfile || !isFriendOrSelf();
        socialRepo.getActivitiesByUser(otherUid, publicOnly, 30, new Callback<List<ActivityPost>>() {
            @Override
            public void onSuccess(List<ActivityPost> result) {
                if (isFinishing()) return;
                List<ActivityPost> posts = result == null ? new ArrayList<>() : result;
                if (!other.showActivities) posts = new ArrayList<>();
                feedAdapter.submit(posts);
                binding.textEmptyActivity.setVisibility(posts.isEmpty() ? View.VISIBLE : View.GONE);
                binding.recyclerActivity.setVisibility(posts.isEmpty() ? View.GONE : View.VISIBLE);
            }

            @Override
            public void onError(Exception e) {
                binding.textEmptyActivity.setVisibility(View.VISIBLE);
                binding.recyclerActivity.setVisibility(View.GONE);
            }
        });
    }

    private boolean isFriendOrSelf() {
        return isFriend || (otherUid != null && otherUid.equals(Session.uid()));
    }

    @Override
    public void onComments(ActivityPost post) {
        startActivity(new Intent(this, CommentsActivity.class)
                .putExtra(CommentsActivity.EXTRA_ACTIVITY_ID, post.id));
    }

    @Override
    public void onUserClick(ActivityPost post) {
        if (post.userId == null || post.userId.equals(otherUid)) return;
        startActivity(new Intent(this, UserProfileActivity.class)
                .putExtra(EXTRA_UID, post.userId));
    }

    private void bindStat(ImageView icon, TextView value, TextView label,
                          int iconRes, String valueText, int labelRes) {
        icon.setImageResource(iconRes);
        value.setText(valueText);
        label.setText(labelRes);
    }

    private static String join(List<String> parts) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) sb.append("  ·  ");
            sb.append(parts.get(i));
        }
        return sb.toString();
    }
}
