package com.gymfit.app.ui.workout;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.WorkoutTemplate;
import com.gymfit.app.data.repository.WorkoutRepository;
import com.gymfit.app.databinding.FragmentWorkoutBinding;
import com.gymfit.app.databinding.ItemTemplateBinding;
import com.gymfit.app.ui.ai.AiCoachActivity;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.SessionManager;
import com.gymfit.app.util.UiUtils;

import java.util.ArrayList;
import java.util.List;

/** Workout tab: resume an in-progress session, start a free workout, or pick/build a split. */
public class WorkoutFragment extends Fragment {

    private FragmentWorkoutBinding binding;
    private final WorkoutRepository repo = new WorkoutRepository();
    private TemplateAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentWorkoutBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        adapter = new TemplateAdapter();
        binding.recyclerTemplates.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.recyclerTemplates.setAdapter(adapter);

        binding.buttonEmpty.setOnClickListener(v -> startFreeWorkout());
        binding.buttonAi.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), AiCoachActivity.class)));
        binding.buttonCreateSplit.setOnClickListener(v -> {
            Intent i = new Intent(requireContext(), TemplateEditorActivity.class);
            startActivity(i);
        });
        binding.cardActive.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), ActiveWorkoutActivity.class)));
    }

    @Override
    public void onResume() {
        super.onResume();
        if (binding == null) return;
        updateActiveCard();
        loadTemplates();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void updateActiveCard() {
        if (ActiveWorkout.isActive()) {
            binding.cardActive.setVisibility(View.VISIBLE);
            binding.textActiveName.setText(ActiveWorkout.get().name);
        } else {
            binding.cardActive.setVisibility(View.GONE);
        }
    }

    private void loadTemplates() {
        String uid = Session.uid();
        if (!FirebaseState.isReady(requireContext()) || uid == null) {
            binding.bannerFirebase.setVisibility(View.VISIBLE);
            adapter.submit(WorkoutRepository.builtinTemplates());
            return;
        }
        binding.bannerFirebase.setVisibility(View.GONE);

        SessionManager sm = new SessionManager(requireContext());
        if (!sm.templatesSeeded()) {
            repo.seedSystemTemplates(new Callback<Void>() {
                @Override
                public void onSuccess(Void result) {
                    sm.setTemplatesSeeded();
                    fetchTemplates(uid);
                }

                @Override
                public void onError(Exception e) {
                    fetchTemplates(uid);
                }
            });
        } else {
            fetchTemplates(uid);
        }
    }

    private void fetchTemplates(String uid) {
        repo.getTemplates(uid, new Callback<List<WorkoutTemplate>>() {
            @Override
            public void onSuccess(List<WorkoutTemplate> result) {
                if (binding == null || !isAdded()) return;
                adapter.submit(result == null ? new ArrayList<>() : result);
            }

            @Override
            public void onError(Exception e) {
                if (binding == null || !isAdded()) return;
                adapter.submit(WorkoutRepository.builtinTemplates());
            }
        });
    }

    private void startFreeWorkout() {
        if (ActiveWorkout.isActive()) {
            startActivity(new Intent(requireContext(), ActiveWorkoutActivity.class));
            return;
        }
        ActiveWorkout.startEmpty("Free Workout");
        startActivity(new Intent(requireContext(), ActiveWorkoutActivity.class));
    }

    private void startTemplate(WorkoutTemplate template) {
        if (ActiveWorkout.isActive()) {
            UiUtils.snack(binding.getRoot(), getString(R.string.continue_workout));
            startActivity(new Intent(requireContext(), ActiveWorkoutActivity.class));
            return;
        }
        ActiveWorkout.startFromTemplate(template);
        startActivity(new Intent(requireContext(), ActiveWorkoutActivity.class));
    }

    private class TemplateAdapter extends RecyclerView.Adapter<TemplateAdapter.Holder> {

        private final List<WorkoutTemplate> items = new ArrayList<>();

        void submit(List<WorkoutTemplate> list) {
            items.clear();
            items.addAll(list);
            notifyDataSetChanged();
            if (binding != null) {
                binding.textEmpty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
            }
        }

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new Holder(ItemTemplateBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Holder holder, int position) {
            holder.bind(items.get(position));
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        class Holder extends RecyclerView.ViewHolder {
            private final ItemTemplateBinding b;

            Holder(ItemTemplateBinding b) {
                super(b.getRoot());
                this.b = b;
            }

            void bind(WorkoutTemplate t) {
                b.textName.setText(t.name);
                int count = t.exercises == null ? 0 : t.exercises.size();
                b.textMeta.setText((t.type == null ? "" : t.type + " · ")
                        + count + " " + getString(R.string.exercises));
                if ("ai".equals(t.source)) {
                    b.textBadge.setVisibility(View.VISIBLE);
                    b.textBadge.setText(R.string.ai_coach);
                } else {
                    b.textBadge.setVisibility(View.GONE);
                }
                boolean editable = !("system".equals(t.ownerId));
                b.buttonEdit.setVisibility(editable ? View.VISIBLE : View.GONE);
                b.buttonEdit.setOnClickListener(v -> {
                    Intent i = new Intent(requireContext(), TemplateEditorActivity.class);
                    i.putExtra("templateId", t.id);
                    startActivity(i);
                });
                b.getRoot().setOnClickListener(v -> startTemplate(t));
            }
        }
    }
}
