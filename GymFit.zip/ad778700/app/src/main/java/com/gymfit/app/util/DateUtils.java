package com.gymfit.app.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public final class DateUtils {

    private DateUtils() {
    }

    public static String relativeTime(long millis) {
        long diff = System.currentTimeMillis() - millis;
        if (diff < 0) diff = 0;
        long minutes = TimeUnit.MILLISECONDS.toMinutes(diff);
        if (minutes < 1) return "just now";
        if (minutes < 60) return minutes + "m ago";
        long hours = TimeUnit.MILLISECONDS.toHours(diff);
        if (hours < 24) return hours + "h ago";
        long days = TimeUnit.MILLISECONDS.toDays(diff);
        if (days == 1) return "yesterday";
        if (days < 7) return days + "d ago";
        return formatDate(millis);
    }

    public static String formatDate(long millis) {
        return new SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(new Date(millis));
    }

    public static String formatDayMonth(long millis) {
        return new SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(new Date(millis));
    }

    public static String formatTime(long millis) {
        return new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(millis));
    }

    public static String greeting() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour < 12) return "GOOD MORNING";
        if (hour < 17) return "GOOD AFTERNOON";
        return "GOOD EVENING";
    }

    public static long startOfDay(long millis) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(millis);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    public static long startOfWeek(long millis) {
        Calendar c = Calendar.getInstance();
        c.setFirstDayOfWeek(Calendar.MONDAY);
        c.setTimeInMillis(startOfDay(millis));
        int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
        int diff = (dayOfWeek == Calendar.SUNDAY) ? 6 : dayOfWeek - Calendar.MONDAY;
        c.add(Calendar.DAY_OF_YEAR, -diff);
        return c.getTimeInMillis();
    }

    public static boolean isSameDay(long a, long b) {
        return startOfDay(a) == startOfDay(b);
    }

    public static int daysBetween(long fromMillis, long toMillis) {
        long from = startOfDay(fromMillis);
        long to = startOfDay(toMillis);
        return (int) TimeUnit.MILLISECONDS.toDays(to - from);
    }

    public static int ageFromDob(String isoDate) {
        if (isoDate == null || isoDate.isEmpty()) return 0;
        try {
            Date dob = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(isoDate);
            if (dob == null) return 0;
            Calendar birth = Calendar.getInstance();
            birth.setTime(dob);
            Calendar now = Calendar.getInstance();
            int age = now.get(Calendar.YEAR) - birth.get(Calendar.YEAR);
            if (now.get(Calendar.DAY_OF_YEAR) < birth.get(Calendar.DAY_OF_YEAR)) age--;
            return Math.max(age, 0);
        } catch (Exception e) {
            return 0;
        }
    }

    public static String formatCountdown(long millisLeft) {
        long totalSeconds = Math.max(0, millisLeft / 1000);
        return String.format(Locale.US, "%d:%02d", totalSeconds / 60, totalSeconds % 60);
    }
}
