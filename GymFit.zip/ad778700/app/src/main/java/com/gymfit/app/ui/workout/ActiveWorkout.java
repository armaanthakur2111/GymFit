package com.gymfit.app.ui.workout;

import com.gymfit.app.data.model.ExerciseEntry;
import com.gymfit.app.data.model.SetLog;
import com.gymfit.app.data.model.Workout;
import com.gymfit.app.data.model.WorkoutTemplate;

import java.util.ArrayList;

/**
 * In-memory holder for the workout currently being logged. Survives activity
 * recreation; intentionally not persisted across process death for v1.
 */
public final class ActiveWorkout {

    private static Workout current;
    private static String templateId;

    private ActiveWorkout() {
    }

    public static boolean isActive() {
        return current != null;
    }

    public static Workout get() {
        return current;
    }

    public static String getTemplateId() {
        return templateId;
    }

    public static void startFromTemplate(WorkoutTemplate template) {
        Workout w = new Workout();
        w.name = template.name;
        w.type = template.type;
        w.templateId = template.id;
        w.startTime = System.currentTimeMillis();
        w.entries = new ArrayList<>();
        for (com.gymfit.app.data.model.TemplateExercise te : template.exercises) {
            ExerciseEntry entry = new ExerciseEntry(te.exerciseName, te.muscleGroup);
            for (int i = 0; i < Math.max(1, te.targetSets); i++) {
                SetLog set = new SetLog(0, te.targetReps);
                set.completed = false;
                entry.sets.add(set);
            }
            w.entries.add(entry);
        }
        templateId = template.id;
        current = w;
    }

    public static void startEmpty(String name) {
        Workout w = new Workout();
        w.name = name == null || name.isEmpty() ? "Free Workout" : name;
        w.type = "Custom";
        w.startTime = System.currentTimeMillis();
        w.entries = new ArrayList<>();
        templateId = null;
        current = w;
    }

    public static void clear() {
        current = null;
        templateId = null;
    }
}
