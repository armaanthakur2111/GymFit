package com.gymfit.app.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.gymfit.app.R;
import com.gymfit.app.databinding.ActivityMainBinding;
import com.gymfit.app.ui.home.HomeFragment;
import com.gymfit.app.ui.leaderboard.LeaderboardFragment;
import com.gymfit.app.ui.map.MapFragment;
import com.gymfit.app.ui.social.SocialFragment;
import com.gymfit.app.ui.workout.WorkoutFragment;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private Fragment current;

    private final androidx.activity.result.ActivityResultLauncher<String> notificationPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> { });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if (savedInstanceState == null) {
            showTab(R.id.nav_home);
        }

        binding.bottomNav.setOnItemSelectedListener(item -> {
            showTab(item.getItemId());
            return true;
        });

        requestNotificationPermissionIfNeeded();
    }

    public void selectTab(int menuId) {
        binding.bottomNav.setSelectedItemId(menuId);
    }

    private void showTab(int itemId) {
        Fragment fragment;
        String tag;
        if (itemId == R.id.nav_workout) {
            fragment = new WorkoutFragment();
            tag = "workout";
        } else if (itemId == R.id.nav_leaderboard) {
            fragment = new LeaderboardFragment();
            tag = "leaderboard";
        } else if (itemId == R.id.nav_map) {
            fragment = new MapFragment();
            tag = "map";
        } else if (itemId == R.id.nav_social) {
            fragment = new SocialFragment();
            tag = "social";
        } else {
            fragment = new HomeFragment();
            tag = "home";
        }
        current = fragment;
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainer, fragment, tag)
                .commit();
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this,
                Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS);
        }
    }
}
