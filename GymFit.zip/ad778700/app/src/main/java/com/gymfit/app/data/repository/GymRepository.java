package com.gymfit.app.data.repository;

import com.google.firebase.firestore.DocumentSnapshot;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Db;
import com.gymfit.app.data.model.Gym;
import com.gymfit.app.data.model.User;

import java.util.ArrayList;
import java.util.List;

/**
 * Gym directory. Gyms are shared public documents; a starter catalog is seeded
 * once so the map is never empty. Only gym positions are stored — never a
 * user's live location (privacy rule).
 */
public class GymRepository {

    public void getGyms(Callback<List<Gym>> callback) {
        if (Db.gyms() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.gyms().get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.isEmpty()) {
                        seed(callback);
                        return;
                    }
                    List<Gym> gyms = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot) {
                        Gym g = doc.toObject(Gym.class);
                        if (g != null) {
                            g.id = doc.getId();
                            gyms.add(g);
                        }
                    }
                    callback.onSuccess(gyms);
                })
                .addOnFailureListener(callback::onError);
    }

    /** Starter catalog (fictional gyms in major cities) written with stable ids. */
    private void seed(Callback<List<Gym>> callback) {
        List<Gym> starters = new ArrayList<>();
        starters.add(new Gym("gym_ironworks", "Ironworks Strength", "Mumbai", 19.0760, 72.8777));
        starters.add(new Gym("gym_titan", "Titan Fitness Club", "Mumbai", 19.0176, 72.8562));
        starters.add(new Gym("gym_forge", "The Forge Gym", "Delhi", 28.6139, 77.2090));
        starters.add(new Gym("gym_apex", "Apex Training Lab", "Delhi", 28.5355, 77.3910));
        starters.add(new Gym("gym_barbell", "Barbell Republic", "Bengaluru", 12.9716, 77.5946));
        starters.add(new Gym("gym_squat", "Squat Rack Athletics", "Bengaluru", 12.9352, 77.6245));
        starters.add(new Gym("gym_prime", "Prime Physique", "Hyderabad", 17.3850, 78.4867));
        starters.add(new Gym("gym_core", "Core Culture", "Pune", 18.5204, 73.8567));

        final int[] remaining = {starters.size()};
        for (Gym g : starters) {
            Db.gyms().document(g.id).set(g).addOnCompleteListener(task -> {
                if (--remaining[0] == 0) callback.onSuccess(starters);
            });
        }
    }

    /** Counts members per gym and marks the user's own gym. */
    public void getGymsWithCounts(User user, Callback<List<Gym>> callback) {
        getGyms(new Callback<List<Gym>>() {
            @Override
            public void onSuccess(List<Gym> gyms) {
                if (Db.users() == null) {
                    callback.onSuccess(gyms);
                    return;
                }
                final int[] remaining = {gyms.size()};
                if (remaining[0] == 0) {
                    callback.onSuccess(gyms);
                    return;
                }
                for (Gym g : gyms) {
                    Db.users().whereEqualTo("gymId", g.id).get()
                            .addOnSuccessListener(snapshot -> {
                                g.memberCount = snapshot.size();
                                if (--remaining[0] == 0) callback.onSuccess(gyms);
                            })
                            .addOnFailureListener(e -> {
                                if (--remaining[0] == 0) callback.onSuccess(gyms);
                            });
                }
            }

            @Override
            public void onError(Exception e) {
                callback.onError(e);
            }
        });
    }

    public void getGym(String gymId, Callback<Gym> callback) {
        if (Db.gyms() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.gyms().document(gymId).get()
                .addOnSuccessListener(doc -> callback.onSuccess(doc.toObject(Gym.class)))
                .addOnFailureListener(callback::onError);
    }

    /** Users who train at a gym (public gym visibility only). */
    public void getGymMembers(String gymId, Callback<List<User>> callback) {
        if (Db.users() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.users().whereEqualTo("gymId", gymId).limit(100).get()
                .addOnSuccessListener(snapshot -> {
                    List<User> members = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot) {
                        User u = doc.toObject(User.class);
                        if (u != null && u.showGymOnMap) members.add(u);
                    }
                    callback.onSuccess(members);
                })
                .addOnFailureListener(callback::onError);
    }
}
