package com.gymfit.app.ui.social;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.ActivityPost;
import com.gymfit.app.data.model.FriendRequest;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.repository.FriendRepository;
import com.gymfit.app.data.repository.SocialRepository;
import com.gymfit.app.data.service.AchievementService;
import com.gymfit.app.databinding.FragmentSocialBinding;
import com.gymfit.app.databinding.ItemFriendBinding;
import com.gymfit.app.databinding.ItemFriendRequestBinding;
import com.gymfit.app.ui.messages.ChatActivity;
import com.gymfit.app.ui.messages.MessagesActivity;
import com.gymfit.app.util.DateUtils;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.UiUtils;

import java.util.ArrayList;
import java.util.List;

/** Social hub: activity feed, friends list and incoming friend requests. */
public class SocialFragment extends Fragment implements ActivityFeedAdapter.Listener {

    private static final int TAB_FEED = 0;
    private static final int TAB_FRIENDS = 1;
    private static final int TAB_REQUESTS = 2;

    private FragmentSocialBinding binding;
    private final SocialRepository socialRepo = new SocialRepository();
    private final FriendRepository friendRepo = new FriendRepository();
    private final AchievementService achievements = new AchievementService();

    private ActivityFeedAdapter feedAdapter;
    private FriendAdapter friendAdapter;
    private RequestAdapter requestAdapter;
    private int tab = TAB_FEED;

    private final List<FriendRepository.Friend> friends = new ArrayList<>();
    private final List<FriendRequest> requests = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentSocialBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        feedAdapter = new ActivityFeedAdapter(this);
        binding.recyclerFeed.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.recyclerFeed.setAdapter(feedAdapter);

        friendAdapter = new FriendAdapter();
        binding.recyclerFriends.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.recyclerFriends.setAdapter(friendAdapter);

        requestAdapter = new RequestAdapter();
        binding.recyclerRequests.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.recyclerRequests.setAdapter(requestAdapter);

        binding.buttonSearch.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), UserSearchActivity.class)));
        binding.buttonMessages.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), MessagesActivity.class)));

        binding.chipFeed.setOnClickListener(v -> selectTab(TAB_FEED));
        binding.chipFriends.setOnClickListener(v -> selectTab(TAB_FRIENDS));
        binding.chipRequests.setOnClickListener(v -> selectTab(TAB_REQUESTS));

        if (!FirebaseState.isReady(requireContext())) {
            binding.bannerFirebase.setVisibility(View.VISIBLE);
            showTab();
            return;
        }
        selectTab(TAB_FEED);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (FirebaseState.isReady(requireContext())) loadTab();
    }

    private void selectTab(int newTab) {
        tab = newTab;
        binding.chipFeed.setChecked(newTab == TAB_FEED);
        binding.chipFriends.setChecked(newTab == TAB_FRIENDS);
        binding.chipRequests.setChecked(newTab == TAB_REQUESTS);
        showTab();
        loadTab();
    }

    private void showTab() {
        binding.recyclerFeed.setVisibility(tab == TAB_FEED ? View.VISIBLE : View.GONE);
        binding.recyclerFriends.setVisibility(tab == TAB_FRIENDS ? View.VISIBLE : View.GONE);
        binding.recyclerRequests.setVisibility(tab == TAB_REQUESTS ? View.VISIBLE : View.GONE);
        binding.textEmpty.setVisibility(View.GONE);
    }

    private void loadTab() {
        if (!FirebaseState.isReady(requireContext())) return;
        String uid = Session.uid();
        if (uid == null) return;
        binding.progressBar.setVisibility(View.VISIBLE);
        if (tab == TAB_FEED) loadFeed(uid);
        else if (tab == TAB_FRIENDS) loadFriends(uid);
        else loadRequests(uid);
    }

    private void loadFeed(String uid) {
        friendRepo.getFriendIds(uid, new Callback<List<String>>() {
            @Override
            public void onSuccess(List<String> friendIds) {
                socialRepo.getFeed(uid, friendIds, new Callback<List<ActivityPost>>() {
                    @Override
                    public void onSuccess(List<ActivityPost> result) {
                        if (binding == null) return;
                        binding.progressBar.setVisibility(View.GONE);
                        feedAdapter.submit(result);
                        updateEmpty(result == null || result.isEmpty(), R.string.no_activities);
                    }

                    @Override
                    public void onError(Exception e) {
                        feedError(e);
                    }
                });
            }

            @Override
            public void onError(Exception e) {
                socialRepo.getFeed(uid, new ArrayList<>(), new Callback<List<ActivityPost>>() {
                    @Override
                    public void onSuccess(List<ActivityPost> result) {
                        if (binding == null) return;
                        binding.progressBar.setVisibility(View.GONE);
                        feedAdapter.submit(result);
                        updateEmpty(result == null || result.isEmpty(), R.string.no_activities);
                    }

                    @Override
                    public void onError(Exception e2) {
                        feedError(e2);
                    }
                });
            }
        });
    }

    private void feedError(Exception e) {
        if (binding == null) return;
        binding.progressBar.setVisibility(View.GONE);
        updateEmpty(true, R.string.no_activities);
        UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, requireContext()));
    }

    private void loadFriends(String uid) {
        friendRepo.getFriends(uid, new Callback<List<FriendRepository.Friend>>() {
            @Override
            public void onSuccess(List<FriendRepository.Friend> result) {
                if (binding == null) return;
                binding.progressBar.setVisibility(View.GONE);
                friends.clear();
                if (result != null) friends.addAll(result);
                friendAdapter.notifyDataSetChanged();
                updateEmpty(friends.isEmpty(), R.string.no_friends_hint);
            }

            @Override
            public void onError(Exception e) {
                if (binding == null) return;
                binding.progressBar.setVisibility(View.GONE);
                updateEmpty(true, R.string.no_friends_hint);
            }
        });
    }

    private void loadRequests(String uid) {
        friendRepo.getIncomingRequests(uid, new Callback<List<FriendRequest>>() {
            @Override
            public void onSuccess(List<FriendRequest> result) {
                if (binding == null) return;
                binding.progressBar.setVisibility(View.GONE);
                requests.clear();
                if (result != null) requests.addAll(result);
                requestAdapter.notifyDataSetChanged();
                updateEmpty(requests.isEmpty(), R.string.no_requests);
            }

            @Override
            public void onError(Exception e) {
                if (binding == null) return;
                binding.progressBar.setVisibility(View.GONE);
                updateEmpty(true, R.string.no_requests);
            }
        });
    }

    private void updateEmpty(boolean empty, int messageRes) {
        if (binding == null) return;
        binding.textEmpty.setText(messageRes);
        binding.textEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
    }

    // ---- ActivityFeedAdapter.Listener ----

    @Override
    public void onComments(ActivityPost post) {
        startActivity(new Intent(requireContext(), CommentsActivity.class)
                .putExtra(CommentsActivity.EXTRA_ACTIVITY_ID, post.id));
    }

    @Override
    public void onUserClick(ActivityPost post) {
        if (post.userId == null) return;
        startActivity(new Intent(requireContext(), UserProfileActivity.class)
                .putExtra(UserProfileActivity.EXTRA_UID, post.userId));
    }

    private void openChat(String otherUid, String otherName) {
        startActivity(new Intent(requireContext(), ChatActivity.class)
                .putExtra(ChatActivity.EXTRA_OTHER_UID, otherUid)
                .putExtra(ChatActivity.EXTRA_OTHER_NAME, otherName));
    }

    private void confirmRemove(FriendRepository.Friend friend) {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.remove_friend)
                .setMessage(friend.name)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.remove_friend, (d, w) -> {
                    String uid = Session.uid();
                    if (uid == null) return;
                    friendRepo.removeFriend(uid, friend.uid, new Callback<Void>() {
                        @Override
                        public void onSuccess(Void result) {
                            loadFriends(uid);
                        }

                        @Override
                        public void onError(Exception e) {
                            UiUtils.snack(binding.getRoot(),
                                    UiUtils.friendlyError(e, requireContext()));
                        }
                    });
                })
                .show();
    }

    private void accept(FriendRequest request) {
        User me = Session.profile();
        if (me == null) return;
        friendRepo.acceptRequest(me, request, new Callback<Void>() {
            @Override
            public void onSuccess(Void result) {
                achievements.evaluate(me, 0, new Callback<List<String>>() {
                    @Override
                    public void onSuccess(List<String> ignored) {
                    }

                    @Override
                    public void onError(Exception e) {
                    }
                });
                String uid = Session.uid();
                if (uid != null) loadRequests(uid);
            }

            @Override
            public void onError(Exception e) {
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, requireContext()));
            }
        });
    }

    private void reject(FriendRequest request) {
        String uid = Session.uid();
        if (uid == null) return;
        friendRepo.rejectRequest(uid, request, new Callback<Void>() {
            @Override
            public void onSuccess(Void result) {
                loadRequests(uid);
            }

            @Override
            public void onError(Exception e) {
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, requireContext()));
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    // ---- Friends adapter ----

    private class FriendAdapter extends RecyclerView.Adapter<FriendHolder> {
        @NonNull
        @Override
        public FriendHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new FriendHolder(ItemFriendBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull FriendHolder holder, int position) {
            FriendRepository.Friend f = friends.get(position);
            holder.binding.textName.setText(f.name);
            List<String> meta = new ArrayList<>();
            if (f.goal != null && !f.goal.isEmpty()) meta.add(f.goal);
            if (f.gymName != null && !f.gymName.isEmpty()) meta.add(f.gymName);
            holder.binding.textMeta.setText(join(meta));
            UiUtils.loadAvatar(holder.binding.imageAvatar, f.photoUrl, f.name, holder.binding.textInitials);
            holder.binding.getRoot().setOnClickListener(v ->
                    startActivity(new Intent(requireContext(), UserProfileActivity.class)
                            .putExtra(UserProfileActivity.EXTRA_UID, f.uid)));
            holder.binding.buttonMessage.setOnClickListener(v -> openChat(f.uid, f.name));
            holder.binding.buttonRemove.setOnClickListener(v -> confirmRemove(f));
        }

        @Override
        public int getItemCount() {
            return friends.size();
        }
    }

    private static class FriendHolder extends RecyclerView.ViewHolder {
        final ItemFriendBinding binding;

        FriendHolder(ItemFriendBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    // ---- Requests adapter ----

    private class RequestAdapter extends RecyclerView.Adapter<RequestHolder> {
        @NonNull
        @Override
        public RequestHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new RequestHolder(ItemFriendRequestBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull RequestHolder holder, int position) {
            FriendRequest r = requests.get(position);
            holder.binding.textName.setText(r.fromName);
            holder.binding.textTime.setText(DateUtils.relativeTime(r.createdAt));
            UiUtils.loadAvatar(holder.binding.imageAvatar, r.fromPhoto, r.fromName,
                    holder.binding.textInitials);
            holder.binding.buttonAccept.setOnClickListener(v -> {
                int pos = holder.getBindingAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) accept(requests.get(pos));
            });
            holder.binding.buttonReject.setOnClickListener(v -> {
                int pos = holder.getBindingAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) reject(requests.get(pos));
            });
        }

        @Override
        public int getItemCount() {
            return requests.size();
        }
    }

    private static class RequestHolder extends RecyclerView.ViewHolder {
        final ItemFriendRequestBinding binding;

        RequestHolder(ItemFriendRequestBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    private static String join(List<String> parts) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) sb.append("  ·  ");
            sb.append(parts.get(i));
        }
        return sb.toString();
    }
}
