package com.gymfit.app.data.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** One-to-one conversation. Stored in `chats/{id}` where id = sorted "uidA_uidB". */
public class ChatRoom {

    public String id;
    public List<String> participantIds = new ArrayList<>();
    public String lastMessageText;
    public String lastSenderId;
    public long lastMessageAt;
    /** uid -> epoch millis of that user's last read time. */
    public Map<String, Long> lastReadAt = new HashMap<>();

    public ChatRoom() {
    }

    public static String chatIdFor(String uidA, String uidB) {
        return uidA.compareTo(uidB) < 0 ? uidA + "_" + uidB : uidB + "_" + uidA;
    }

    public String otherUserId(String myUid) {
        for (String id : participantIds) {
            if (!id.equals(myUid)) return id;
        }
        return null;
    }

    public boolean hasUnreadFor(String myUid) {
        Long lastRead = lastReadAt.get(myUid);
        long readAt = lastRead == null ? 0 : lastRead;
        return lastMessageAt > readAt && !myUid.equals(lastSenderId);
    }
}
