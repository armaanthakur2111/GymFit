package com.gymfit.app.ui.profile;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.repository.UserRepository;
import com.gymfit.app.databinding.ActivityEditProfileBinding;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.UiUtils;
import com.gymfit.app.util.ValidationUtils;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Edits the mutable profile fields; rolling stats are untouched (updated via updateFields). */
public class EditProfileActivity extends AppCompatActivity {

    private ActivityEditProfileBinding binding;
    private final UserRepository userRepo = new UserRepository();
    private User user;
    private String dobIso = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEditProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.buttonBack.setOnClickListener(v -> finish());
        binding.buttonSave.setOnClickListener(v -> save());
        binding.inputDob.setOnClickListener(v -> pickDob());
        binding.layoutDob.setEndIconOnClickListener(v -> pickDob());

        user = Session.profile();
        if (user != null) {
            bind(user);
        } else {
            load();
        }
    }

    private void load() {
        String uid = Session.uid();
        if (!FirebaseState.isReady(this) || uid == null) return;
        userRepo.getUser(uid, new Callback<User>() {
            @Override
            public void onSuccess(User result) {
                if (result == null || isFinishing()) return;
                user = result;
                Session.setProfile(result);
                bind(result);
            }

            @Override
            public void onError(Exception e) {
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, EditProfileActivity.this));
            }
        });
    }

    private void bind(User u) {
        binding.inputName.setText(u.name);
        dobIso = u.dob == null ? "" : u.dob;
        binding.inputDob.setText(displayDob(dobIso));
        binding.inputGender.setText(u.gender, false);
        binding.inputHeight.setText(u.heightCm > 0 ? trim(u.heightCm) : "");
        binding.inputWeight.setText(u.weightKg > 0 ? trim(u.weightKg) : "");
        binding.inputTargetWeight.setText(u.targetWeightKg > 0 ? trim(u.targetWeightKg) : "");
        binding.inputExperience.setText(u.experience, false);
        binding.inputGoal.setText(u.goal, false);
        binding.inputFrequency.setText(
                u.trainingDaysPerWeek > 0 ? u.trainingDaysPerWeek + " days" : "", false);
        binding.inputPhoto.setText(u.photoUrl);
    }

    private void pickDob() {
        Calendar now = Calendar.getInstance();
        int year = now.get(Calendar.YEAR) - 20;
        int month = now.get(Calendar.MONTH);
        int day = now.get(Calendar.DAY_OF_MONTH);
        if (!dobIso.isEmpty()) {
            try {
                String[] p = dobIso.split("-");
                year = Integer.parseInt(p[0]);
                month = Integer.parseInt(p[1]) - 1;
                day = Integer.parseInt(p[2]);
            } catch (Exception ignored) {
            }
        }
        new DatePickerDialog(this, (view, y, m, d) -> {
            dobIso = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d);
            binding.inputDob.setText(String.format(Locale.US, "%02d/%02d/%04d", d, m + 1, y));
        }, year, month, day).show();
    }

    private void save() {
        if (user == null) return;
        String name = text(binding.inputName.getText());
        if (!ValidationUtils.isNonEmpty(name)) {
            binding.layoutName.setError(getString(R.string.error_required_field));
            return;
        }
        binding.layoutName.setError(null);

        if (!FirebaseState.isReady(this)) {
            UiUtils.snack(binding.getRoot(), getString(R.string.firebase_not_configured));
            return;
        }

        Map<String, Object> fields = new HashMap<>();
        fields.put("name", name);
        fields.put("dob", dobIso);
        fields.put("gender", text(binding.inputGender.getText()));
        fields.put("heightCm", ValidationUtils.parseDouble(text(binding.inputHeight.getText()), user.heightCm));
        fields.put("weightKg", ValidationUtils.parseDouble(text(binding.inputWeight.getText()), user.weightKg));
        fields.put("targetWeightKg", ValidationUtils.parseDouble(text(binding.inputTargetWeight.getText()), 0));
        fields.put("experience", text(binding.inputExperience.getText()));
        fields.put("goal", text(binding.inputGoal.getText()));
        String freq = text(binding.inputFrequency.getText());
        fields.put("trainingDaysPerWeek", ValidationUtils.parseInt(freq.replaceAll("\\D+", ""), user.trainingDaysPerWeek));
        fields.put("photoUrl", text(binding.inputPhoto.getText()));
        fields.put("searchKey", name.trim().toLowerCase(Locale.US));

        setLoading(true);
        userRepo.updateFields(user.uid, fields, new Callback<Void>() {
            @Override
            public void onSuccess(Void result) {
                setLoading(false);
                applyLocal(fields);
                UiUtils.snack(binding.getRoot(), getString(R.string.profile_updated));
                finish();
            }

            @Override
            public void onError(Exception e) {
                setLoading(false);
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, EditProfileActivity.this));
            }
        });
    }

    private void applyLocal(Map<String, Object> f) {
        user.name = (String) f.get("name");
        user.dob = (String) f.get("dob");
        user.gender = (String) f.get("gender");
        user.heightCm = num(f.get("heightCm"));
        user.weightKg = num(f.get("weightKg"));
        user.targetWeightKg = num(f.get("targetWeightKg"));
        user.experience = (String) f.get("experience");
        user.goal = (String) f.get("goal");
        user.trainingDaysPerWeek = (int) num(f.get("trainingDaysPerWeek"));
        user.photoUrl = (String) f.get("photoUrl");
        user.searchKey = (String) f.get("searchKey");
        Session.setProfile(user);
    }

    private void setLoading(boolean loading) {
        binding.progress.setVisibility(loading ? View.VISIBLE : View.GONE);
        binding.buttonSave.setEnabled(!loading);
    }

    private static double num(Object v) {
        return v instanceof Number ? ((Number) v).doubleValue() : 0;
    }

    private static String trim(double v) {
        if (v == Math.rint(v)) return String.format(Locale.US, "%d", (long) v);
        return String.format(Locale.US, "%.1f", v);
    }

    private static String displayDob(String iso) {
        if (iso == null || iso.isEmpty()) return "";
        try {
            String[] p = iso.split("-");
            return String.format(Locale.US, "%s/%s/%s", p[2], p[1], p[0]);
        } catch (Exception e) {
            return "";
        }
    }

    private static String text(CharSequence cs) {
        return cs == null ? "" : cs.toString().trim();
    }
}
