package com.gymfit.app.ui.map;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.Gym;
import com.gymfit.app.data.model.LeaderboardEntry;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.repository.GymRepository;
import com.gymfit.app.data.repository.UserRepository;
import com.gymfit.app.data.service.LeaderboardService;
import com.gymfit.app.databinding.ActivityGymDetailBinding;
import com.gymfit.app.databinding.ItemLeaderboardRowBinding;
import com.gymfit.app.ui.social.UserProfileActivity;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.UiUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** A single gym: member leaderboard, your rank there, and setting it as your home gym. */
public class GymDetailActivity extends AppCompatActivity {

    public static final String EXTRA_GYM_ID = "gymId";

    private ActivityGymDetailBinding binding;
    private final GymRepository gymRepo = new GymRepository();
    private final UserRepository userRepo = new UserRepository();
    private final LeaderboardService leaderboard = new LeaderboardService();
    private final List<LeaderboardEntry> members = new ArrayList<>();
    private MemberAdapter adapter;

    private String gymId;
    private Gym gym;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityGymDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.buttonBack.setOnClickListener(v -> finish());

        gymId = getIntent().getStringExtra(EXTRA_GYM_ID);
        binding.recyclerMembers.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MemberAdapter();
        binding.recyclerMembers.setAdapter(adapter);
        binding.buttonSetMyGym.setOnClickListener(v -> setAsMyGym());

        if (!FirebaseState.isReady(this) || gymId == null) {
            binding.buttonSetMyGym.setEnabled(false);
            return;
        }
        loadGym();
        loadMembers();
    }

    private void loadGym() {
        gymRepo.getGym(gymId, new Callback<Gym>() {
            @Override
            public void onSuccess(Gym result) {
                if (result == null || isFinishing()) return;
                gym = result;
                gym.id = gymId;
                binding.textGymName.setText(result.name);
                binding.textTitle.setText(result.name);
                binding.textGymMeta.setText(result.city == null ? "" : result.city);
                updateMyGymButton();
            }

            @Override
            public void onError(Exception e) {
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, GymDetailActivity.this));
            }
        });
    }

    private void loadMembers() {
        leaderboard.getLeaderboard(LeaderboardService.CAT_OVERALL, gymId, null, null, null,
                new Callback<List<LeaderboardEntry>>() {
                    @Override
                    public void onSuccess(List<LeaderboardEntry> result) {
                        if (isFinishing()) return;
                        members.clear();
                        if (result != null) members.addAll(result);
                        adapter.notifyDataSetChanged();
                        binding.textEmpty.setVisibility(members.isEmpty() ? View.VISIBLE : View.GONE);
                        bindYourRank();
                    }

                    @Override
                    public void onError(Exception e) {
                        binding.textEmpty.setVisibility(View.VISIBLE);
                    }
                });
    }

    private void bindYourRank() {
        String uid = Session.uid();
        if (uid == null) return;
        for (LeaderboardEntry e : members) {
            if (e.user != null && uid.equals(e.user.uid)) {
                binding.cardYourRank.setVisibility(View.VISIBLE);
                binding.textYourRank.setText(getString(R.string.rank_hash, e.rank));
                return;
            }
        }
        binding.cardYourRank.setVisibility(View.GONE);
    }

    private void updateMyGymButton() {
        User me = Session.profile();
        boolean isMine = me != null && gymId != null && gymId.equals(me.gymId);
        binding.buttonSetMyGym.setText(isMine ? R.string.gym : R.string.set_as_my_gym);
        binding.buttonSetMyGym.setEnabled(!isMine);
    }

    private void setAsMyGym() {
        User me = Session.profile();
        if (me == null || gym == null) return;
        Map<String, Object> fields = new HashMap<>();
        fields.put("gymId", gym.id);
        fields.put("gymName", gym.name);
        userRepo.updateFields(me.uid, fields, new Callback<Void>() {
            @Override
            public void onSuccess(Void result) {
                me.gymId = gym.id;
                me.gymName = gym.name;
                Session.setProfile(me);
                updateMyGymButton();
                UiUtils.snack(binding.getRoot(), getString(R.string.saved));
            }

            @Override
            public void onError(Exception e) {
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, GymDetailActivity.this));
            }
        });
    }

    private class MemberAdapter extends RecyclerView.Adapter<MemberHolder> {
        @NonNull
        @Override
        public MemberHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new MemberHolder(ItemLeaderboardRowBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull MemberHolder holder, int position) {
            LeaderboardEntry e = members.get(position);
            User u = e.user;
            holder.binding.textRank.setText(String.valueOf(e.rank));
            holder.binding.textName.setText(u == null ? "Athlete" : u.name);
            UiUtils.loadAvatar(holder.binding.imageAvatar, u == null ? null : u.photoUrl,
                    u == null ? null : u.name, holder.binding.textInitials);
            holder.binding.textMeta.setText(u == null ? "" : u.weightClass());
            holder.binding.textScore.setText(String.format(Locale.US, "%.0f", e.overallScore));
            holder.binding.textRank.setTextColor(ContextCompat.getColor(GymDetailActivity.this,
                    e.rank <= 3 ? R.color.accent_gold : R.color.text_secondary));
            holder.binding.rowRoot.setOnClickListener(v -> {
                if (u == null || u.uid == null) return;
                startActivity(new Intent(GymDetailActivity.this, UserProfileActivity.class)
                        .putExtra(UserProfileActivity.EXTRA_UID, u.uid));
            });
        }

        @Override
        public int getItemCount() {
            return members.size();
        }
    }

    private static class MemberHolder extends RecyclerView.ViewHolder {
        final ItemLeaderboardRowBinding binding;

        MemberHolder(ItemLeaderboardRowBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
