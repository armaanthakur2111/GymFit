package com.gymfit.app;

import android.app.Application;

import com.gymfit.app.util.NotificationHelper;

public class GymFitApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        NotificationHelper.createChannels(this);
    }
}
