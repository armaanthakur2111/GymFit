package com.gymfit.app.data;

import java.util.ArrayList;
import java.util.List;

/** Built-in exercise database with muscle-group classification. */
public final class ExerciseCatalog {

    public static final class Exercise {
        public final String name;
        public final String muscleGroup;

        Exercise(String name, String muscleGroup) {
            this.name = name;
            this.muscleGroup = muscleGroup;
        }
    }

    public static final String[] MUSCLE_GROUPS = {
            "Chest", "Back", "Shoulders", "Biceps", "Triceps", "Quads", "Hamstrings", "Glutes", "Calves", "Core"
    };

    private static final List<Exercise> ALL = new ArrayList<>();

    static {
        // Chest
        add("Bench Press", "Chest");
        add("Incline Bench Press", "Chest");
        add("Incline Dumbbell Press", "Chest");
        add("Dumbbell Bench Press", "Chest");
        add("Cable Fly", "Chest");
        add("Pec Deck", "Chest");
        add("Push-Up", "Chest");
        add("Dip (Chest)", "Chest");
        // Back
        add("Deadlift", "Back");
        add("Pull-Up", "Back");
        add("Lat Pulldown", "Back");
        add("Barbell Row", "Back");
        add("Dumbbell Row", "Back");
        add("Seated Cable Row", "Back");
        add("T-Bar Row", "Back");
        add("Face Pull", "Back");
        add("Back Extension", "Back");
        add("Shrug", "Back");
        // Shoulders
        add("Overhead Press", "Shoulders");
        add("Dumbbell Shoulder Press", "Shoulders");
        add("Lateral Raise", "Shoulders");
        add("Front Raise", "Shoulders");
        add("Rear Delt Fly", "Shoulders");
        add("Arnold Press", "Shoulders");
        add("Upright Row", "Shoulders");
        // Biceps
        add("Barbell Curl", "Biceps");
        add("Dumbbell Curl", "Biceps");
        add("Hammer Curl", "Biceps");
        add("Preacher Curl", "Biceps");
        add("Incline Dumbbell Curl", "Biceps");
        add("Cable Curl", "Biceps");
        // Triceps
        add("Tricep Pushdown", "Triceps");
        add("Skull Crusher", "Triceps");
        add("Overhead Tricep Extension", "Triceps");
        add("Close-Grip Bench Press", "Triceps");
        add("Dip (Triceps)", "Triceps");
        add("Kickback", "Triceps");
        // Quads
        add("Squat", "Quads");
        add("Front Squat", "Quads");
        add("Leg Press", "Quads");
        add("Leg Extension", "Quads");
        add("Bulgarian Split Squat", "Quads");
        add("Lunge", "Quads");
        add("Hack Squat", "Quads");
        add("Goblet Squat", "Quads");
        // Hamstrings
        add("Romanian Deadlift", "Hamstrings");
        add("Leg Curl", "Hamstrings");
        add("Seated Leg Curl", "Hamstrings");
        add("Nordic Curl", "Hamstrings");
        add("Good Morning", "Hamstrings");
        // Glutes
        add("Hip Thrust", "Glutes");
        add("Glute Bridge", "Glutes");
        add("Cable Kickback", "Glutes");
        add("Sumo Deadlift", "Glutes");
        // Calves
        add("Standing Calf Raise", "Calves");
        add("Seated Calf Raise", "Calves");
        add("Donkey Calf Raise", "Calves");
        // Core
        add("Plank", "Core");
        add("Crunch", "Core");
        add("Hanging Leg Raise", "Core");
        add("Cable Crunch", "Core");
        add("Russian Twist", "Core");
        add("Ab Wheel Rollout", "Core");
        add("Side Plank", "Core");
    }

    private static void add(String name, String muscleGroup) {
        ALL.add(new Exercise(name, muscleGroup));
    }

    private ExerciseCatalog() {
    }

    public static List<Exercise> all() {
        return ALL;
    }

    public static List<Exercise> search(String query) {
        List<Exercise> result = new ArrayList<>();
        if (query == null || query.trim().isEmpty()) return ALL;
        String q = query.trim().toLowerCase();
        for (Exercise e : ALL) {
            if (e.name.toLowerCase().contains(q) || e.muscleGroup.toLowerCase().contains(q)) {
                result.add(e);
            }
        }
        return result;
    }

    public static String muscleGroupOf(String exerciseName) {
        for (Exercise e : ALL) {
            if (e.name.equalsIgnoreCase(exerciseName)) return e.muscleGroup;
        }
        return "Custom";
    }

    public static List<Exercise> byMuscleGroup(String muscleGroup) {
        List<Exercise> result = new ArrayList<>();
        for (Exercise e : ALL) {
            if (e.muscleGroup.equalsIgnoreCase(muscleGroup)) result.add(e);
        }
        return result;
    }
}
