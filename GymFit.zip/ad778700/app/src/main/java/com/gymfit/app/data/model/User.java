package com.gymfit.app.data.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** User profile + aggregate stats, stored in Firestore `users/{uid}`. */
public class User {

    public String uid;
    public String name;
    public String email;
    public String searchKey;      // lowercase name, for prefix search
    public String dob;            // yyyy-MM-dd
    public String gender;
    public double heightCm;
    public double weightKg;
    public String experience;     // Beginner / Intermediate / Advanced
    public String goal;           // e.g. "Cut / Shred"
    public int trainingDaysPerWeek;
    public String gymId;
    public String gymName;
    public String photoUrl;
    public long createdAt;

    // Privacy
    public boolean publicProfile = true;
    public boolean showActivities = true;
    public boolean showOnLeaderboard = true;
    public boolean showGymOnMap = true;

    // Aggregate stats (kept in sync when workouts finish)
    public int totalWorkouts;
    public double totalVolumeKg;
    public int totalPrs;
    public int currentStreak;
    public int longestStreak;
    public long lastWorkoutAt;
    public List<String> earnedBadges = new ArrayList<>();

    // Rolling stats for transparent leaderboard scoring (recomputed at workout finish)
    public int workoutsLast28;
    public double volumeLast28Kg;
    public double volumePrev28Kg;
    public int prsLast30;
    public double bestBenchE1rm;
    public double bestSquatE1rm;
    public double bestDeadliftE1rm;
    public double targetWeightKg;

    // Challenges: id -> join time; completed ids tracked separately
    public Map<String, Long> joinedChallengesAt = new HashMap<>();
    public List<String> completedChallenges = new ArrayList<>();

    // Friend requests I sent that haven't been accepted yet
    public List<String> sentRequestIds = new ArrayList<>();

    public User() {
    }

    public void refreshSearchKey() {
        searchKey = name == null ? "" : name.trim().toLowerCase();
    }

    public String weightClass() {
        if (weightKg <= 0) return "Open";
        if (weightKg < 60) return "<60 kg";
        if (weightKg < 70) return "60–70 kg";
        if (weightKg < 80) return "70–80 kg";
        if (weightKg < 90) return "80–90 kg";
        if (weightKg < 100) return "90–100 kg";
        return "100+ kg";
    }

    public String firstName() {
        if (name == null || name.trim().isEmpty()) return "Athlete";
        return name.trim().split("\\s+")[0];
    }
}
