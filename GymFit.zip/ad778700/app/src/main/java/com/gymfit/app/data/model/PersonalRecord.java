package com.gymfit.app.data.model;

/** A personal record. Stored in `personalRecords/{id}`. */
public class PersonalRecord {

    public static final String TYPE_WEIGHT = "WEIGHT";
    public static final String TYPE_E1RM = "E1RM";
    public static final String TYPE_VOLUME = "VOLUME";
    public static final String TYPE_REPS = "REPS";

    public String id;
    public String userId;
    public String exerciseName;
    public String type;
    public double value;
    public double previousValue;
    public String unit;            // "kg" or "reps"
    public String workoutId;
    public long achievedAt;

    public PersonalRecord() {
    }

    public PersonalRecord(String userId, String exerciseName, String type,
                          double value, double previousValue, String unit, String workoutId) {
        this.userId = userId;
        this.exerciseName = exerciseName;
        this.type = type;
        this.value = value;
        this.previousValue = previousValue;
        this.unit = unit;
        this.workoutId = workoutId;
        this.achievedAt = System.currentTimeMillis();
    }

    public String typeLabel() {
        switch (type) {
            case TYPE_WEIGHT: return "Heaviest Weight";
            case TYPE_E1RM: return "Estimated 1RM";
            case TYPE_VOLUME: return "Exercise Volume";
            case TYPE_REPS: return "Rep PR";
            default: return "Personal Record";
        }
    }

    public double improvementFraction() {
        if (previousValue <= 0) return 1.0;
        return (value - previousValue) / previousValue;
    }
}
