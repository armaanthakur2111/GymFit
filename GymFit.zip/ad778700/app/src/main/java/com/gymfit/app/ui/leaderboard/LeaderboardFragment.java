package com.gymfit.app.ui.leaderboard;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.Chip;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.LeaderboardEntry;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.service.LeaderboardService;
import com.gymfit.app.databinding.DialogLeaderboardFiltersBinding;
import com.gymfit.app.databinding.FragmentLeaderboardBinding;
import com.gymfit.app.databinding.ItemDetailRowBinding;
import com.gymfit.app.databinding.ItemLeaderboardRowBinding;
import com.gymfit.app.ui.social.UserProfileActivity;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.UiUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Transparent leaderboard: category tabs, filters, your-rank breakdown and score explanation. */
public class LeaderboardFragment extends Fragment {

    private FragmentLeaderboardBinding binding;
    private final LeaderboardService service = new LeaderboardService();
    private final List<LeaderboardEntry> entries = new ArrayList<>();
    private BoardAdapter adapter;

    private String category = LeaderboardService.CAT_OVERALL;
    private String goalFilter = null;
    private String experienceFilter = null;
    private String weightClassFilter = null;
    private boolean myGymOnly = false;

    private static final String[] CAT_KEYS = {
            LeaderboardService.CAT_OVERALL, LeaderboardService.CAT_STRENGTH,
            LeaderboardService.CAT_CONSISTENCY, LeaderboardService.CAT_PROGRESS,
            LeaderboardService.CAT_VOLUME
    };
    private static final int[] CAT_LABELS = {
            R.string.cat_overall, R.string.cat_strength, R.string.cat_consistency,
            R.string.cat_progress, R.string.cat_volume
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentLeaderboardBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.recyclerLeaderboard.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new BoardAdapter();
        binding.recyclerLeaderboard.setAdapter(adapter);

        buildCategoryChips();
        binding.buttonFilters.setOnClickListener(v -> openFilters());
        binding.buttonExplain.setOnClickListener(v -> toggleExplanation());

        if (!FirebaseState.isReady(requireContext())) {
            binding.bannerFirebase.setVisibility(View.VISIBLE);
            binding.progressBar.setVisibility(View.GONE);
            binding.textEmpty.setVisibility(View.VISIBLE);
            return;
        }
        load();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (FirebaseState.isReady(requireContext())) load();
    }

    private void buildCategoryChips() {
        binding.chipCategories.removeAllViews();
        for (int i = 0; i < CAT_KEYS.length; i++) {
            Chip chip = new Chip(requireContext());
            chip.setText(CAT_LABELS[i]);
            chip.setCheckable(true);
            chip.setChecked(i == 0);
            chip.setId(View.generateViewId());
            final String key = CAT_KEYS[i];
            chip.setOnClickListener(v -> {
                if (!key.equals(category)) {
                    category = key;
                    load();
                }
            });
            binding.chipCategories.addView(chip);
        }
    }

    private void toggleExplanation() {
        boolean showing = binding.textExplanation.getVisibility() == View.VISIBLE;
        if (showing) {
            binding.textExplanation.setVisibility(View.GONE);
        } else {
            binding.textExplanation.setText(R.string.score_explanation_body);
            binding.textExplanation.setVisibility(View.VISIBLE);
        }
    }

    private void openFilters() {
        DialogLeaderboardFiltersBinding d = DialogLeaderboardFiltersBinding.inflate(getLayoutInflater());
        ArrayAdapter<CharSequence> goalAdapter = prefixedAdapter(R.array.fitness_goals);
        ArrayAdapter<CharSequence> expAdapter = prefixedAdapter(R.array.experience_levels);
        ArrayAdapter<CharSequence> wcAdapter = prefixedAdapter(R.array.weight_classes);
        d.inputGoal.setAdapter(goalAdapter);
        d.inputExperience.setAdapter(expAdapter);
        d.inputWeightClass.setAdapter(wcAdapter);
        d.inputGoal.setText(orAll(goalFilter), false);
        d.inputExperience.setText(orAll(experienceFilter), false);
        d.inputWeightClass.setText(orAll(weightClassFilter), false);
        d.switchMyGym.setChecked(myGymOnly);

        new MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.filters)
                .setView(d.getRoot())
                .setNeutralButton(R.string.filter_clear, (dlg, w) -> {
                    goalFilter = experienceFilter = weightClassFilter = null;
                    myGymOnly = false;
                    load();
                })
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.filter_apply, (dlg, w) -> {
                    goalFilter = valueOrNull(d.inputGoal.getText().toString());
                    experienceFilter = valueOrNull(d.inputExperience.getText().toString());
                    weightClassFilter = valueOrNull(d.inputWeightClass.getText().toString());
                    myGymOnly = d.switchMyGym.isChecked();
                    load();
                })
                .show();
    }

    private ArrayAdapter<CharSequence> prefixedAdapter(int arrayRes) {
        ArrayAdapter<CharSequence> a = ArrayAdapter.createFromResource(
                requireContext(), arrayRes, android.R.layout.simple_list_item_1);
        a.insert(getString(R.string.filter_all), 0);
        return a;
    }

    private String orAll(String value) {
        return value == null ? getString(R.string.filter_all) : value;
    }

    private String valueOrNull(String text) {
        if (text == null) return null;
        String t = text.trim();
        if (t.isEmpty() || t.equalsIgnoreCase(getString(R.string.filter_all))) return null;
        return t;
    }

    private void load() {
        User me = Session.profile();
        String gymIdFilter = (myGymOnly && me != null && me.gymId != null && !me.gymId.isEmpty())
                ? me.gymId : null;
        binding.progressBar.setVisibility(View.VISIBLE);
        binding.textEmpty.setVisibility(View.GONE);

        service.getLeaderboard(category, gymIdFilter, goalFilter, weightClassFilter,
                experienceFilter, new Callback<List<LeaderboardEntry>>() {
                    @Override
                    public void onSuccess(List<LeaderboardEntry> result) {
                        if (binding == null || !isAdded()) return;
                        entries.clear();
                        if (result != null) entries.addAll(result);
                        adapter.notifyDataSetChanged();
                        binding.progressBar.setVisibility(View.GONE);
                        binding.textEmpty.setVisibility(entries.isEmpty() ? View.VISIBLE : View.GONE);
                        bindYourRank();
                    }

                    @Override
                    public void onError(Exception e) {
                        if (binding == null || !isAdded()) return;
                        binding.progressBar.setVisibility(View.GONE);
                        binding.textEmpty.setVisibility(View.VISIBLE);
                        UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, requireContext()));
                    }
                });
    }

    private void bindYourRank() {
        String uid = Session.uid();
        LeaderboardEntry mine = null;
        if (uid != null) {
            for (LeaderboardEntry e : entries) {
                if (e.user != null && uid.equals(e.user.uid)) {
                    mine = e;
                    break;
                }
            }
        }
        if (mine == null) {
            binding.cardYourRank.setVisibility(View.GONE);
            return;
        }
        binding.cardYourRank.setVisibility(View.VISIBLE);
        binding.textYourRank.setText(getString(R.string.rank_hash, mine.rank));

        binding.containerBreakdown.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(requireContext());
        addBreakdown(inflater, R.string.cat_consistency, mine.consistencyScore);
        addBreakdown(inflater, R.string.cat_strength, mine.strengthScore);
        addBreakdown(inflater, R.string.cat_progress, mine.progressScore);
        addBreakdown(inflater, R.string.cat_volume, mine.volumeScore);
        addBreakdown(inflater, R.string.cat_overall, mine.overallScore);
    }

    private void addBreakdown(LayoutInflater inflater, int labelRes, double score) {
        ItemDetailRowBinding row = ItemDetailRowBinding.inflate(inflater, binding.containerBreakdown, false);
        row.textLabel.setText(labelRes);
        row.textValue.setText(String.format(Locale.US, "%.0f", score));
        binding.containerBreakdown.addView(row.getRoot());
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private class BoardAdapter extends RecyclerView.Adapter<BoardHolder> {

        @NonNull
        @Override
        public BoardHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ItemLeaderboardRowBinding b = ItemLeaderboardRowBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false);
            return new BoardHolder(b);
        }

        @Override
        public void onBindViewHolder(@NonNull BoardHolder holder, int position) {
            LeaderboardEntry e = entries.get(position);
            User u = e.user;
            holder.binding.textRank.setText(String.valueOf(e.rank));
            holder.binding.textName.setText(u == null ? "Athlete" : u.name);
            UiUtils.loadAvatar(holder.binding.imageAvatar, u == null ? null : u.photoUrl,
                    u == null ? null : u.name, holder.binding.textInitials);

            List<String> meta = new ArrayList<>();
            if (u != null) {
                meta.add(u.weightClass());
                if (u.gymName != null && !u.gymName.isEmpty()) meta.add(u.gymName);
            }
            holder.binding.textMeta.setText(join(meta));

            double score = LeaderboardService.scoreFor(e, category);
            holder.binding.textScore.setText(String.format(Locale.US, "%.0f", score));

            boolean isMe = Session.uid() != null && u != null && Session.uid().equals(u.uid);
            int rankColor = ContextCompat.getColor(requireContext(),
                    isMe ? R.color.accent : (e.rank <= 3 ? R.color.accent_gold : R.color.text_secondary));
            holder.binding.textRank.setTextColor(rankColor);
            holder.binding.rowRoot.setBackgroundColor(ContextCompat.getColor(requireContext(),
                    isMe ? R.color.accent_soft : android.R.color.transparent));
            holder.binding.rowRoot.setOnClickListener(v -> {
                if (u == null || u.uid == null) return;
                startActivity(new Intent(requireContext(), UserProfileActivity.class)
                        .putExtra(UserProfileActivity.EXTRA_UID, u.uid));
            });
        }

        @Override
        public int getItemCount() {
            return entries.size();
        }
    }

    private static String join(List<String> parts) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) sb.append("  ·  ");
            sb.append(parts.get(i));
        }
        return sb.toString();
    }

    private static class BoardHolder extends RecyclerView.ViewHolder {
        final ItemLeaderboardRowBinding binding;

        BoardHolder(ItemLeaderboardRowBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
