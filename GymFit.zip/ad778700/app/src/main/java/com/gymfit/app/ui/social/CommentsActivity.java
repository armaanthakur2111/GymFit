package com.gymfit.app.ui.social;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.ActivityPost;
import com.gymfit.app.data.model.Comment;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.repository.SocialRepository;
import com.gymfit.app.databinding.ActivityCommentsBinding;
import com.gymfit.app.databinding.ItemCommentBinding;
import com.gymfit.app.util.DateUtils;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.FormatUtils;
import com.gymfit.app.util.UiUtils;

import java.util.ArrayList;
import java.util.List;

/** Threaded comments for a single activity post. */
public class CommentsActivity extends AppCompatActivity {

    public static final String EXTRA_ACTIVITY_ID = "activityId";

    private ActivityCommentsBinding binding;
    private final SocialRepository socialRepo = new SocialRepository();
    private final List<Comment> comments = new ArrayList<>();
    private CommentAdapter adapter;
    private ActivityPost post;
    private String activityId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCommentsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.buttonBack.setOnClickListener(v -> finish());

        activityId = getIntent().getStringExtra(EXTRA_ACTIVITY_ID);
        binding.recyclerComments.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CommentAdapter();
        binding.recyclerComments.setAdapter(adapter);

        binding.buttonSend.setOnClickListener(v -> send());

        if (!FirebaseState.isReady(this) || activityId == null) {
            binding.buttonSend.setEnabled(false);
            return;
        }
        loadPost();
        loadComments();
    }

    private void loadPost() {
        socialRepo.getActivity(activityId, new Callback<ActivityPost>() {
            @Override
            public void onSuccess(ActivityPost result) {
                post = result;
            }

            @Override
            public void onError(Exception e) {
            }
        });
    }

    private void loadComments() {
        socialRepo.getComments(activityId, new Callback<List<Comment>>() {
            @Override
            public void onSuccess(List<Comment> result) {
                if (isFinishing()) return;
                comments.clear();
                if (result != null) comments.addAll(result);
                adapter.notifyDataSetChanged();
                binding.textEmpty.setVisibility(comments.isEmpty() ? View.VISIBLE : View.GONE);
                if (!comments.isEmpty()) {
                    binding.recyclerComments.scrollToPosition(comments.size() - 1);
                }
            }

            @Override
            public void onError(Exception e) {
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, CommentsActivity.this));
            }
        });
    }

    private void send() {
        String text = binding.inputComment.getText() == null ? "" : binding.inputComment.getText().toString().trim();
        User me = Session.profile();
        if (text.isEmpty() || me == null) return;
        if (post == null) {
            post = new ActivityPost();
            post.id = activityId;
        }
        binding.buttonSend.setEnabled(false);
        socialRepo.addComment(me, post, text, new Callback<Void>() {
            @Override
            public void onSuccess(Void result) {
                binding.buttonSend.setEnabled(true);
                binding.inputComment.setText("");
                loadComments();
            }

            @Override
            public void onError(Exception e) {
                binding.buttonSend.setEnabled(true);
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, CommentsActivity.this));
            }
        });
    }

    private class CommentAdapter extends RecyclerView.Adapter<CommentHolder> {
        @NonNull
        @Override
        public CommentHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new CommentHolder(ItemCommentBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull CommentHolder holder, int position) {
            Comment c = comments.get(position);
            holder.binding.textName.setText(c.userName);
            holder.binding.textComment.setText(c.text);
            holder.binding.textTime.setText(DateUtils.relativeTime(c.createdAt));
            holder.binding.textInitials.setText(FormatUtils.initials(c.userName));
        }

        @Override
        public int getItemCount() {
            return comments.size();
        }
    }

    private static class CommentHolder extends RecyclerView.ViewHolder {
        final ItemCommentBinding binding;

        CommentHolder(ItemCommentBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
