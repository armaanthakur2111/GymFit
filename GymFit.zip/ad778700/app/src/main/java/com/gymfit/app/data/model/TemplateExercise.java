package com.gymfit.app.data.model;

/** An exercise planned inside a template. */
public class TemplateExercise {

    public String exerciseName;
    public String muscleGroup;
    public int targetSets = 3;
    public int targetReps = 10;

    public TemplateExercise() {
    }

    public TemplateExercise(String exerciseName, String muscleGroup, int targetSets, int targetReps) {
        this.exerciseName = exerciseName;
        this.muscleGroup = muscleGroup;
        this.targetSets = targetSets;
        this.targetReps = targetReps;
    }
}
