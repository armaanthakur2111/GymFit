package com.gymfit.app.data.model;

import java.util.ArrayList;
import java.util.List;

/** One exercise within a workout, with its sets. */
public class ExerciseEntry {

    public String exerciseName;
    public String muscleGroup;
    public List<SetLog> sets = new ArrayList<>();

    public ExerciseEntry() {
    }

    public ExerciseEntry(String exerciseName, String muscleGroup) {
        this.exerciseName = exerciseName;
        this.muscleGroup = muscleGroup;
    }

    public double volume() {
        double total = 0;
        for (SetLog s : sets) {
            if (s.completed) total += s.volume();
        }
        return total;
    }

    public int completedSets() {
        int count = 0;
        for (SetLog s : sets) {
            if (s.completed) count++;
        }
        return count;
    }

    public int totalReps() {
        int reps = 0;
        for (SetLog s : sets) {
            if (s.completed) reps += s.reps;
        }
        return reps;
    }

    public double bestWeight() {
        double best = 0;
        for (SetLog s : sets) {
            if (s.completed && s.weightKg > best) best = s.weightKg;
        }
        return best;
    }

    public double bestE1rm() {
        double best = 0;
        for (SetLog s : sets) {
            if (s.completed) best = Math.max(best, s.estimated1Rm());
        }
        return best;
    }

    public boolean hasCompletedSets() {
        return completedSets() > 0;
    }
}
