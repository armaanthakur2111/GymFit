package com.gymfit.app.ui.map;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.Gym;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.repository.GymRepository;
import com.gymfit.app.data.repository.UserRepository;
import com.gymfit.app.databinding.ActivityGymPickerBinding;
import com.gymfit.app.databinding.ItemGymRowBinding;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.UiUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Searchable gym picker. Selecting a gym sets it as the user's home gym and returns it. */
public class GymPickerActivity extends AppCompatActivity {

    public static final String RESULT_GYM_ID = "gymId";
    public static final String RESULT_GYM_NAME = "gymName";

    private ActivityGymPickerBinding binding;
    private final GymRepository gymRepo = new GymRepository();
    private final UserRepository userRepo = new UserRepository();
    private final List<Gym> all = new ArrayList<>();
    private final List<Gym> shown = new ArrayList<>();
    private GymAdapter adapter;
    private String query = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityGymPickerBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.buttonBack.setOnClickListener(v -> finish());

        binding.recyclerGyms.setLayoutManager(new LinearLayoutManager(this));
        adapter = new GymAdapter();
        binding.recyclerGyms.setAdapter(adapter);

        binding.inputSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
                query = s == null ? "" : s.toString().trim().toLowerCase(Locale.US);
                applyFilter();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        load();
    }

    private void load() {
        if (!FirebaseState.isReady(this)) {
            binding.progressBar.setVisibility(View.GONE);
            return;
        }
        binding.progressBar.setVisibility(View.VISIBLE);
        gymRepo.getGymsWithCounts(Session.profile(), new Callback<List<Gym>>() {
            @Override
            public void onSuccess(List<Gym> result) {
                if (isFinishing()) return;
                all.clear();
                if (result != null) all.addAll(result);
                applyFilter();
                binding.progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onError(Exception e) {
                binding.progressBar.setVisibility(View.GONE);
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, GymPickerActivity.this));
            }
        });
    }

    private void applyFilter() {
        shown.clear();
        for (Gym g : all) {
            if (query.isEmpty()
                    || (g.name != null && g.name.toLowerCase(Locale.US).contains(query))
                    || (g.city != null && g.city.toLowerCase(Locale.US).contains(query))) {
                shown.add(g);
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void select(Gym g) {
        User me = Session.profile();
        Intent data = new Intent();
        data.putExtra(RESULT_GYM_ID, g.id);
        data.putExtra(RESULT_GYM_NAME, g.name);
        setResult(RESULT_OK, data);

        if (me != null && FirebaseState.isReady(this)) {
            Map<String, Object> fields = new HashMap<>();
            fields.put("gymId", g.id);
            fields.put("gymName", g.name);
            userRepo.updateFields(me.uid, fields, new Callback<Void>() {
                @Override
                public void onSuccess(Void result) {
                    me.gymId = g.id;
                    me.gymName = g.name;
                    Session.setProfile(me);
                    finish();
                }

                @Override
                public void onError(Exception e) {
                    finish();
                }
            });
        } else {
            finish();
        }
    }

    private class GymAdapter extends RecyclerView.Adapter<GymHolder> {
        @NonNull
        @Override
        public GymHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new GymHolder(ItemGymRowBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull GymHolder holder, int position) {
            Gym g = shown.get(position);
            holder.binding.textName.setText(g.name);
            holder.binding.textMeta.setText(String.format(Locale.US, "%s · %d %s",
                    g.city == null ? "" : g.city, g.memberCount, getString(R.string.gymfit_users)));
            User me = Session.profile();
            boolean mine = me != null && g.id != null && g.id.equals(me.gymId);
            holder.binding.textBadge.setVisibility(mine ? View.VISIBLE : View.GONE);
            if (mine) holder.binding.textBadge.setText(R.string.gym);
            holder.binding.getRoot().setOnClickListener(v -> {
                int pos = holder.getBindingAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) select(shown.get(pos));
            });
        }

        @Override
        public int getItemCount() {
            return shown.size();
        }
    }

    private static class GymHolder extends RecyclerView.ViewHolder {
        final ItemGymRowBinding binding;

        GymHolder(ItemGymRowBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
