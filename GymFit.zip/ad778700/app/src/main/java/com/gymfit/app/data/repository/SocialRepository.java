package com.gymfit.app.data.repository;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Db;
import com.gymfit.app.data.model.ActivityPost;
import com.gymfit.app.data.model.AppNotification;
import com.gymfit.app.data.model.Comment;
import com.gymfit.app.data.model.PersonalRecord;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.model.Workout;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Activity feed, kudos and comments. */
public class SocialRepository {

    /**
     * Feed: latest public activities, with posts from the user and their friends
     * ranked first. Kudos-by-me state is batch-loaded via doc ids (activityId_uid).
     */
    public void getFeed(String uid, List<String> friendIds, Callback<List<ActivityPost>> callback) {
        if (Db.activities() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.activities()
                .whereEqualTo("publicPost", true)
                .limit(60)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<ActivityPost> posts = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot) {
                        ActivityPost p = doc.toObject(ActivityPost.class);
                        if (p != null) {
                            p.id = doc.getId();
                            posts.add(p);
                        }
                    }
                    posts.sort((a, b) -> Long.compare(b.createdAt, a.createdAt));

                    Set<String> circle = new HashSet<>();
                    circle.add(uid);
                    if (friendIds != null) circle.addAll(friendIds);

                    List<ActivityPost> ordered = new ArrayList<>();
                    for (ActivityPost p : posts) {
                        if (circle.contains(p.userId)) ordered.add(p);
                    }
                    for (ActivityPost p : posts) {
                        if (!circle.contains(p.userId)) ordered.add(p);
                    }
                    loadKudosState(uid, ordered, callback);
                })
                .addOnFailureListener(callback::onError);
    }

    private void loadKudosState(String uid, List<ActivityPost> posts, Callback<List<ActivityPost>> callback) {
        if (Db.kudos() == null || posts.isEmpty()) {
            callback.onSuccess(posts);
            return;
        }
        List<String> ids = new ArrayList<>();
        for (ActivityPost p : posts) ids.add(p.id + "_" + uid);
        Db.kudos().whereIn("__name__",
                ids.subList(0, Math.min(ids.size(), 30)))
                .get()
                .addOnSuccessListener(snapshot -> {
                    Set<String> liked = new HashSet<>();
                    for (DocumentSnapshot doc : snapshot) liked.add(doc.getId());
                    for (ActivityPost p : posts) p.kudosByMe = liked.contains(p.id + "_" + uid);
                    callback.onSuccess(posts);
                })
                .addOnFailureListener(e -> callback.onSuccess(posts));
    }

    public void getActivity(String id, Callback<ActivityPost> callback) {
        if (Db.activities() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.activities().document(id).get()
                .addOnSuccessListener(doc -> {
                    ActivityPost p = doc.toObject(ActivityPost.class);
                    if (p != null) p.id = doc.getId();
                    callback.onSuccess(p);
                })
                .addOnFailureListener(callback::onError);
    }

    public void getActivitiesByUser(String userId, boolean publicOnly, int limit,
                                    Callback<List<ActivityPost>> callback) {
        if (Db.activities() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.activities().whereEqualTo("userId", userId).limit(limit).get()
                .addOnSuccessListener(snapshot -> {
                    List<ActivityPost> posts = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot) {
                        ActivityPost p = doc.toObject(ActivityPost.class);
                        if (p == null) continue;
                        if (publicOnly && !p.publicPost) continue;
                        p.id = doc.getId();
                        posts.add(p);
                    }
                    posts.sort((a, b) -> Long.compare(b.createdAt, a.createdAt));
                    callback.onSuccess(posts);
                })
                .addOnFailureListener(callback::onError);
    }

    public void postActivity(ActivityPost post, Callback<Void> callback) {
        if (Db.activities() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        post.id = NotificationRepository.reverseTimeId();
        post.createdAt = System.currentTimeMillis();
        Db.activities().document(post.id).set(post)
                .addOnSuccessListener(v -> callback.onSuccess(null))
                .addOnFailureListener(callback::onError);
    }

    public void postWorkoutActivity(User user, Workout workout, Callback<Void> callback) {
        ActivityPost post = new ActivityPost();
        post.userId = user.uid;
        post.userName = user.name;
        post.userPhoto = user.photoUrl;
        post.type = ActivityPost.TYPE_WORKOUT;
        post.text = "completed a " + workout.name + " workout";
        post.workoutId = workout.id;
        post.workoutName = workout.name;
        post.workoutType = workout.type;
        post.volumeKg = workout.totalVolumeKg;
        post.durationMinutes = workout.durationMinutes;
        post.publicPost = user.showActivities;
        postActivity(post, callback);
    }

    public void postPrActivity(User user, PersonalRecord pr, Callback<Void> callback) {
        ActivityPost post = new ActivityPost();
        post.userId = user.uid;
        post.userName = user.name;
        post.userPhoto = user.photoUrl;
        post.type = ActivityPost.TYPE_PR;
        post.text = "achieved a new " + pr.exerciseName + " PR (" + pr.typeLabel() + ")";
        post.workoutId = pr.workoutId;
        post.publicPost = user.showActivities;
        postActivity(post, callback);
    }

    public void postStreakActivity(User user, int streakDays, Callback<Void> callback) {
        ActivityPost post = new ActivityPost();
        post.userId = user.uid;
        post.userName = user.name;
        post.userPhoto = user.photoUrl;
        post.type = ActivityPost.TYPE_STREAK;
        post.text = "reached a " + streakDays + "-day streak";
        post.publicPost = user.showActivities;
        postActivity(post, callback);
    }

    /** Toggles kudos; returns the new state (true = liked). */
    public void toggleKudos(User me, ActivityPost post, Callback<Boolean> callback) {
        if (Db.kudos() == null || Db.activities() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        String docId = post.id + "_" + me.uid;
        Db.kudos().document(docId).get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        doc.getReference().delete();
                        Db.activities().document(post.id)
                                .update("kudosCount", FieldValue.increment(-1));
                        post.kudosCount = Math.max(0, post.kudosCount - 1);
                        post.kudosByMe = false;
                        callback.onSuccess(false);
                    } else {
                        Map<String, Object> kudos = new HashMap<>();
                        kudos.put("activityId", post.id);
                        kudos.put("userId", me.uid);
                        kudos.put("createdAt", System.currentTimeMillis());
                        Db.kudos().document(docId).set(kudos);
                        Db.activities().document(post.id)
                                .update("kudosCount", FieldValue.increment(1));
                        post.kudosCount++;
                        post.kudosByMe = true;
                        NotificationRepository.push(post.userId, AppNotification.TYPE_KUDOS,
                                "New kudos", me.name + " gave kudos to your activity.",
                                me.uid, me.name, post.id);
                        callback.onSuccess(true);
                    }
                })
                .addOnFailureListener(callback::onError);
    }

    public void getComments(String activityId, Callback<List<Comment>> callback) {
        if (Db.comments() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.comments().whereEqualTo("activityId", activityId).limit(200).get()
                .addOnSuccessListener(snapshot -> {
                    List<Comment> comments = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot) {
                        Comment c = doc.toObject(Comment.class);
                        if (c != null) {
                            c.id = doc.getId();
                            comments.add(c);
                        }
                    }
                    comments.sort((a, b) -> Long.compare(a.createdAt, b.createdAt));
                    callback.onSuccess(comments);
                })
                .addOnFailureListener(callback::onError);
    }

    public void addComment(User me, ActivityPost post, String text, Callback<Void> callback) {
        if (Db.comments() == null || Db.activities() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Comment comment = new Comment();
        comment.activityId = post.id;
        comment.userId = me.uid;
        comment.userName = me.name;
        comment.text = text;
        comment.createdAt = System.currentTimeMillis();
        Db.comments().add(comment)
                .addOnSuccessListener(ref -> {
                    Db.activities().document(post.id)
                            .update("commentCount", FieldValue.increment(1));
                    post.commentCount++;
                    NotificationRepository.push(post.userId, AppNotification.TYPE_COMMENT,
                            "New comment", me.name + ": " + text,
                            me.uid, me.name, post.id);
                    callback.onSuccess(null);
                })
                .addOnFailureListener(callback::onError);
    }

    public void deleteComment(String commentId, String activityId) {
        if (Db.comments() != null) {
            Db.comments().document(commentId).delete();
        }
        if (Db.activities() != null) {
            Db.activities().document(activityId).update("commentCount", FieldValue.increment(-1));
        }
    }

    public static List<ActivityPost> emptyIfNull(List<ActivityPost> list) {
        return list == null ? Collections.emptyList() : list;
    }
}
