package com.gymfit.app.ui.workout;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.gymfit.app.R;
import com.gymfit.app.data.ExerciseCatalog;

import java.util.ArrayList;
import java.util.List;

/**
 * Reusable exercise picker: a searchable list over the built-in catalog.
 * Used both when adding an exercise mid-workout and when editing a split.
 */
public final class ExercisePickerDialog {

    public interface OnPicked {
        void onPicked(ExerciseCatalog.Exercise exercise);
    }

    private ExercisePickerDialog() {
    }

    public static void show(Context context, OnPicked callback) {
        View view = LayoutInflater.from(context).inflate(R.layout.dialog_exercise_picker, null);
        TextInputEditText search = view.findViewById(R.id.inputSearch);
        ListView list = view.findViewById(R.id.listExercises);

        ExerciseAdapter adapter = new ExerciseAdapter(context, ExerciseCatalog.all());
        list.setAdapter(adapter);

        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(context)
                .setTitle(R.string.add_exercise)
                .setView(view)
                .setNegativeButton(R.string.cancel, null);

        androidx.appcompat.app.AlertDialog dialog = builder.create();
        list.setOnItemClickListener((parent, v, position, id) -> {
            ExerciseCatalog.Exercise ex = adapter.getItem(position);
            dialog.dismiss();
            if (ex != null && callback != null) callback.onPicked(ex);
        });

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                adapter.getFilter().filter(s);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        dialog.show();
    }

    private static class ExerciseAdapter extends BaseAdapter implements Filterable {
        private final Context context;
        private final List<ExerciseCatalog.Exercise> all;
        private List<ExerciseCatalog.Exercise> shown;

        ExerciseAdapter(Context context, List<ExerciseCatalog.Exercise> all) {
            this.context = context;
            this.all = all;
            this.shown = new ArrayList<>(all);
        }

        @Override
        public int getCount() {
            return shown.size();
        }

        @Override
        public ExerciseCatalog.Exercise getItem(int position) {
            return shown.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(context).inflate(R.layout.item_exercise_pick, parent, false);
            }
            ExerciseCatalog.Exercise ex = getItem(position);
            ((TextView) convertView.findViewById(R.id.textName)).setText(ex.name);
            ((TextView) convertView.findViewById(R.id.textMuscle)).setText(ex.muscleGroup);
            return convertView;
        }

        @Override
        public Filter getFilter() {
            return new Filter() {
                @Override
                protected FilterResults performFiltering(CharSequence constraint) {
                    String q = constraint == null ? "" : constraint.toString().trim().toLowerCase();
                    List<ExerciseCatalog.Exercise> result = new ArrayList<>();
                    if (q.isEmpty()) {
                        result.addAll(all);
                    } else {
                        for (ExerciseCatalog.Exercise e : all) {
                            if (e.name.toLowerCase().contains(q) || e.muscleGroup.toLowerCase().contains(q)) {
                                result.add(e);
                            }
                        }
                    }
                    FilterResults fr = new FilterResults();
                    fr.values = result;
                    fr.count = result.size();
                    return fr;
                }

                @Override
                @SuppressWarnings("unchecked")
                protected void publishResults(CharSequence constraint, FilterResults results) {
                    shown = (List<ExerciseCatalog.Exercise>) results.values;
                    notifyDataSetChanged();
                }
            };
        }
    }
}
