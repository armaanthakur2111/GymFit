package com.gymfit.app.data.service;

import android.content.Context;

import com.gymfit.app.data.Callback;
import com.gymfit.app.data.model.AppNotification;
import com.gymfit.app.data.model.PersonalRecord;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.model.Workout;
import com.gymfit.app.data.repository.NotificationRepository;
import com.gymfit.app.data.repository.SocialRepository;
import com.gymfit.app.data.repository.UserRepository;
import com.gymfit.app.data.repository.WorkoutRepository;
import com.gymfit.app.util.NotificationHelper;

import java.util.List;

/**
 * End-of-workout pipeline: save workout -> detect PRs -> refresh stats ->
 * badges -> challenges -> social post -> notifications. Each step degrades
 * gracefully; a failing step never blocks the others.
 */
public class WorkoutCompletionService {

    /** Everything the summary/celebration screens need after the pipeline runs. */
    public static class Result {
        public Workout workout;
        public List<PersonalRecord> newPrs;
        public User updatedUser;
        public List<String> newBadges;
    }

    public void complete(Context context, User user, Workout workout, boolean shareToFeed,
                         Callback<Result> callback) {
        workout.recalculate();
        workout.userId = user.uid;
        workout.endTime = System.currentTimeMillis();
        workout.sharedToFeed = shareToFeed;

        Result result = new Result();
        result.workout = workout;

        new WorkoutRepository().saveWorkout(workout, new Callback<String>() {
            @Override
            public void onSuccess(String workoutId) {
                detectPrs(context, user, workout, result, shareToFeed, callback);
            }

            @Override
            public void onError(Exception e) {
                callback.onError(e);
            }
        });
    }

    private void detectPrs(Context context, User user, Workout workout, Result result,
                           boolean shareToFeed, Callback<Result> callback) {
        new PrService().detectPrs(user.uid, workout, new Callback<List<PersonalRecord>>() {
            @Override
            public void onSuccess(List<PersonalRecord> prs) {
                result.newPrs = prs;
                refreshStats(context, user, workout, result, shareToFeed, callback);
            }

            @Override
            public void onError(Exception e) {
                result.newPrs = java.util.Collections.emptyList();
                refreshStats(context, user, workout, result, shareToFeed, callback);
            }
        });
    }

    private void refreshStats(Context context, User user, Workout workout, Result result,
                              boolean shareToFeed, Callback<Result> callback) {
        new StatsService().recomputeAfterWorkout(user.uid, new Callback<User>() {
            @Override
            public void onSuccess(User updated) {
                updated.totalPrs += result.newPrs.size();
                new UserRepository().updateFields(updated.uid,
                        java.util.Collections.singletonMap("totalPrs", updated.totalPrs),
                        ignoreErrors());
                result.updatedUser = updated;
                evaluateBadges(context, updated, workout, result, shareToFeed, callback);
            }

            @Override
            public void onError(Exception e) {
                result.updatedUser = user;
                evaluateBadges(context, user, workout, result, shareToFeed, callback);
            }
        });
    }

    private void evaluateBadges(Context context, User user, Workout workout, Result result,
                                boolean shareToFeed, Callback<Result> callback) {
        new AchievementService().evaluate(user, result.newPrs.size(), new Callback<List<String>>() {
            @Override
            public void onSuccess(List<String> badges) {
                result.newBadges = badges;
                checkChallenges(context, user, workout, result, shareToFeed, callback);
            }

            @Override
            public void onError(Exception e) {
                result.newBadges = java.util.Collections.emptyList();
                checkChallenges(context, user, workout, result, shareToFeed, callback);
            }
        });
    }

    private void checkChallenges(Context context, User user, Workout workout, Result result,
                                 boolean shareToFeed, Callback<Result> callback) {
        new ChallengeService().checkCompletions(user, new Callback<List<String>>() {
            @Override
            public void onSuccess(List<String> completed) {
                finish(context, user, workout, result, shareToFeed, callback);
            }

            @Override
            public void onError(Exception e) {
                finish(context, user, workout, result, shareToFeed, callback);
            }
        });
    }

    private void finish(Context context, User user, Workout workout, Result result,
                        boolean shareToFeed, Callback<Result> callback) {
        if (shareToFeed && user.showActivities) {
            new SocialRepository().postWorkoutActivity(user, workout, ignoreErrors());
        }
        if (!result.newPrs.isEmpty() && user.showActivities) {
            PersonalRecord top = result.newPrs.get(0);
            new SocialRepository().postPrActivity(user, top, ignoreErrors());
        }
        if (user.currentStreak > 0 && user.currentStreak % 5 == 0) {
            NotificationRepository.push(user.uid, AppNotification.TYPE_STREAK,
                    "Streak alive!", user.currentStreak + "-day training streak. Keep pushing.",
                    null, null, null);
        }
        if (context != null) {
            int prCount = result.newPrs == null ? 0 : result.newPrs.size();
            String body = workout.exerciseCount + " exercises · "
                    + Math.round(workout.totalVolumeKg) + " kg volume"
                    + (prCount > 0 ? " · " + prCount + " new PR" + (prCount > 1 ? "s" : "") : "");
            NotificationHelper.notify(context, NotificationHelper.CHANNEL_PROGRESS,
                    (int) (System.currentTimeMillis() / 1000),
                    "Workout saved", body, null);
        }
        callback.onSuccess(result);
    }

    private static <T> Callback<T> ignoreErrors() {
        return new Callback<T>() {
            @Override
            public void onSuccess(T result) {
            }

            @Override
            public void onError(Exception e) {
            }
        };
    }
}
