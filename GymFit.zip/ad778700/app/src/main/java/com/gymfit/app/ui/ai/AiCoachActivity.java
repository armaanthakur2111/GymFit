package com.gymfit.app.ui.ai;

import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.model.Workout;
import com.gymfit.app.data.model.WorkoutTemplate;
import com.gymfit.app.data.repository.AiCoachRepository;
import com.gymfit.app.data.repository.WorkoutRepository;
import com.gymfit.app.databinding.ActivityAiCoachBinding;
import com.gymfit.app.databinding.ItemMessageBinding;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.UiUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * AI Coach chat. Replies stream from a build-time configured backend endpoint;
 * the OpenAI key never ships in the app. A detected weekly split can be imported
 * straight into the user's workout templates via ADD TO MY WORKOUT.
 */
public class AiCoachActivity extends AppCompatActivity {

    private ActivityAiCoachBinding binding;
    private final AiCoachRepository aiRepo = new AiCoachRepository();
    private final WorkoutRepository workoutRepo = new WorkoutRepository();

    private final List<UiMsg> display = new ArrayList<>();
    private final List<AiCoachRepository.ChatMessage> history = new ArrayList<>();
    private MsgAdapter adapter;
    private boolean busy;
    private String lastReply;

    private static class UiMsg {
        final String text;
        final boolean fromUser;

        UiMsg(String text, boolean fromUser) {
            this.text = text;
            this.fromUser = fromUser;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAiCoachBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.buttonBack.setOnClickListener(v -> finish());

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        binding.recyclerMessages.setLayoutManager(layoutManager);
        adapter = new MsgAdapter();
        binding.recyclerMessages.setAdapter(adapter);

        binding.buttonSend.setOnClickListener(v -> onSend());
        binding.buttonAddPlan.setOnClickListener(v -> importPlan());
        binding.chipAnalyze.setOnClickListener(v -> analyzeProgress());
        binding.chipSplit.setOnClickListener(v -> send(getString(R.string.ai_suggest_split)));
        binding.chipBench.setOnClickListener(v -> send(getString(R.string.ai_suggest_bench)));
        binding.chipPlateau.setOnClickListener(v -> send(getString(R.string.ai_suggest_plateau)));

        boolean configured = aiRepo.isConfigured();
        if (!configured) {
            binding.bannerNotConfigured.setVisibility(View.VISIBLE);
            binding.buttonSend.setEnabled(false);
            binding.inputMessage.setEnabled(false);
        }
        display.add(new UiMsg(getString(R.string.ai_welcome), false));
        adapter.notifyDataSetChanged();
    }

    private void onSend() {
        CharSequence cs = binding.inputMessage.getText();
        String text = cs == null ? "" : cs.toString().trim();
        if (text.isEmpty()) return;
        binding.inputMessage.setText("");
        send(text);
    }

    private void send(String text) {
        if (busy || !aiRepo.isConfigured()) return;
        pushUser(text, text);
    }

    private void analyzeProgress() {
        if (busy) return;
        User me = Session.profile();
        if (!aiRepo.isConfigured()) return;
        if (me == null) {
            send(getString(R.string.analyze_my_progress));
            return;
        }
        binding.progressThinking.setVisibility(View.VISIBLE);
        busy = true;
        String uid = Session.uid();
        if (!FirebaseState.isReady(this) || uid == null) {
            String prompt = aiRepo.buildAnalysisPrompt(me, new ArrayList<>());
            busy = false;
            binding.progressThinking.setVisibility(View.GONE);
            pushUser(getString(R.string.analyze_my_progress), prompt);
            return;
        }
        workoutRepo.getUserWorkouts(uid, 12, new Callback<List<Workout>>() {
            @Override
            public void onSuccess(List<Workout> workouts) {
                busy = false;
                binding.progressThinking.setVisibility(View.GONE);
                String prompt = aiRepo.buildAnalysisPrompt(me,
                        workouts == null ? new ArrayList<>() : workouts);
                pushUser(getString(R.string.analyze_my_progress), prompt);
            }

            @Override
            public void onError(Exception e) {
                busy = false;
                binding.progressThinking.setVisibility(View.GONE);
                String prompt = aiRepo.buildAnalysisPrompt(me, new ArrayList<>());
                pushUser(getString(R.string.analyze_my_progress), prompt);
            }
        });
    }

    private void pushUser(String displayText, String apiContent) {
        display.add(new UiMsg(displayText, true));
        history.add(new AiCoachRepository.ChatMessage("user", apiContent));
        adapter.notifyDataSetChanged();
        scrollDown();
        callChat();
    }

    private void callChat() {
        User me = Session.profile();
        busy = true;
        binding.progressThinking.setVisibility(View.VISIBLE);
        binding.buttonSend.setEnabled(false);
        aiRepo.chat(me, history, new Callback<String>() {
            @Override
            public void onSuccess(String reply) {
                busy = false;
                binding.progressThinking.setVisibility(View.GONE);
                binding.buttonSend.setEnabled(aiRepo.isConfigured());
                lastReply = reply;
                history.add(new AiCoachRepository.ChatMessage("assistant", reply));
                display.add(new UiMsg(reply == null ? "" : reply, false));
                adapter.notifyDataSetChanged();
                scrollDown();
                detectPlan(reply);
            }

            @Override
            public void onError(Exception e) {
                busy = false;
                binding.progressThinking.setVisibility(View.GONE);
                binding.buttonSend.setEnabled(aiRepo.isConfigured());
                display.add(new UiMsg(getString(R.string.ai_error), false));
                adapter.notifyDataSetChanged();
                scrollDown();
            }
        });
    }

    private void detectPlan(String reply) {
        List<WorkoutTemplate> plans = AiCoachRepository.parseSplitPlan(reply, Session.uid());
        if (!plans.isEmpty()) {
            binding.buttonAddPlan.setVisibility(View.VISIBLE);
            UiUtils.snack(binding.getRoot(), getString(R.string.ai_split_detected));
        } else {
            binding.buttonAddPlan.setVisibility(View.GONE);
        }
    }

    private void importPlan() {
        User me = Session.profile();
        String uid = Session.uid();
        if (uid == null || me == null || !FirebaseState.isReady(this)) {
            UiUtils.snack(binding.getRoot(), getString(R.string.firebase_not_configured));
            return;
        }
        List<WorkoutTemplate> plans = AiCoachRepository.parseSplitPlan(lastReply, uid);
        if (plans.isEmpty()) {
            binding.buttonAddPlan.setVisibility(View.GONE);
            return;
        }
        binding.buttonAddPlan.setEnabled(false);
        final int[] remaining = {plans.size()};
        for (WorkoutTemplate t : plans) {
            workoutRepo.saveTemplate(t, new Callback<String>() {
                @Override
                public void onSuccess(String id) {
                    if (--remaining[0] == 0) onPlanSaved();
                }

                @Override
                public void onError(Exception e) {
                    if (--remaining[0] == 0) onPlanSaved();
                }
            });
        }
    }

    private void onPlanSaved() {
        binding.buttonAddPlan.setEnabled(true);
        binding.buttonAddPlan.setVisibility(View.GONE);
        UiUtils.snack(binding.getRoot(), getString(R.string.plan_added));
    }

    private void scrollDown() {
        if (!display.isEmpty()) binding.recyclerMessages.scrollToPosition(display.size() - 1);
    }

    private class MsgAdapter extends RecyclerView.Adapter<MsgHolder> {
        @NonNull
        @Override
        public MsgHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new MsgHolder(ItemMessageBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull MsgHolder holder, int position) {
            UiMsg m = display.get(position);
            holder.binding.textMessage.setText(m.text);
            holder.binding.textTime.setVisibility(View.GONE);
            holder.binding.rowRoot.setGravity(m.fromUser ? Gravity.END : Gravity.START);
            holder.binding.bubble.setBackgroundResource(
                    m.fromUser ? R.drawable.bg_bubble_me : R.drawable.bg_bubble_other);
            holder.binding.textMessage.setTextColor(ContextCompat.getColor(AiCoachActivity.this,
                    R.color.text_primary));
        }

        @Override
        public int getItemCount() {
            return display.size();
        }
    }

    private static class MsgHolder extends RecyclerView.ViewHolder {
        final ItemMessageBinding binding;

        MsgHolder(ItemMessageBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
