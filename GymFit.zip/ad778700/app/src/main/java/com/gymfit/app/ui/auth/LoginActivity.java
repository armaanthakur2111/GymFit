package com.gymfit.app.ui.auth;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.repository.AuthRepository;
import com.gymfit.app.databinding.ActivityLoginBinding;
import com.gymfit.app.ui.MainActivity;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.UiUtils;
import com.gymfit.app.util.ValidationUtils;

public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding binding;
    private final AuthRepository auth = new AuthRepository();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if (!FirebaseState.isReady(this)) {
            binding.bannerFirebase.setVisibility(View.VISIBLE);
        }

        binding.buttonLogin.setOnClickListener(v -> attemptLogin());
        binding.buttonSignUp.setOnClickListener(v ->
                startActivity(new Intent(this, SignUpActivity.class)));
        binding.buttonForgot.setOnClickListener(v ->
                startActivity(new Intent(this, ForgotPasswordActivity.class)));
    }

    private void attemptLogin() {
        String email = binding.inputEmail.getText() == null ? "" : binding.inputEmail.getText().toString();
        String password = binding.inputPassword.getText() == null ? "" : binding.inputPassword.getText().toString();

        if (!ValidationUtils.isValidEmail(email)) {
            binding.layoutEmail.setError(getString(R.string.error_invalid_email));
            return;
        }
        binding.layoutEmail.setError(null);
        if (!ValidationUtils.isValidPassword(password)) {
            binding.layoutPassword.setError(getString(R.string.error_short_password));
            return;
        }
        binding.layoutPassword.setError(null);

        setLoading(true);
        auth.login(email, password, new Callback<com.google.firebase.auth.FirebaseUser>() {
            @Override
            public void onSuccess(com.google.firebase.auth.FirebaseUser result) {
                setLoading(false);
                startActivity(new Intent(LoginActivity.this, MainActivity.class));
                finish();
            }

            @Override
            public void onError(Exception e) {
                setLoading(false);
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, LoginActivity.this));
            }
        });
    }

    private void setLoading(boolean loading) {
        binding.progress.setVisibility(loading ? View.VISIBLE : View.GONE);
        binding.buttonLogin.setEnabled(!loading);
    }
}
