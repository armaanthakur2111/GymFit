package com.gymfit.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.gymfit.app.ui.auth.LoginActivity;
import com.gymfit.app.ui.auth.OnboardingActivity;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.SessionManager;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        new Handler(Looper.getMainLooper()).postDelayed(this::route, 900);
    }

    private void route() {
        if (isFinishing()) return;
        SessionManager session = new SessionManager(this);
        if (!session.isOnboarded()) {
            startActivity(new Intent(this, OnboardingActivity.class));
            finish();
            return;
        }
        FirebaseUser user = FirebaseState.isReady(this)
                ? FirebaseAuth.getInstance().getCurrentUser() : null;
        if (user != null) {
            startActivity(new Intent(this, MainActivity.class));
        } else {
            startActivity(new Intent(this, LoginActivity.class));
        }
        finish();
    }
}
