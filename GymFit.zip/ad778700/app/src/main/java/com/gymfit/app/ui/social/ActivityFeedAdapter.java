package com.gymfit.app.ui.social;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.ActivityPost;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.repository.SocialRepository;
import com.gymfit.app.databinding.ItemActivityFeedBinding;
import com.gymfit.app.util.DateUtils;
import com.gymfit.app.util.FormatUtils;
import com.gymfit.app.util.UiUtils;

import java.util.ArrayList;
import java.util.List;

/** Reusable activity-feed adapter with inline kudos toggling. */
public class ActivityFeedAdapter extends RecyclerView.Adapter<ActivityFeedAdapter.FeedHolder> {

    public interface Listener {
        void onComments(ActivityPost post);

        void onUserClick(ActivityPost post);
    }

    private final List<ActivityPost> posts = new ArrayList<>();
    private final SocialRepository socialRepo = new SocialRepository();
    private final Listener listener;

    public ActivityFeedAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<ActivityPost> list) {
        posts.clear();
        if (list != null) posts.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public FeedHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemActivityFeedBinding b = ItemActivityFeedBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new FeedHolder(b);
    }

    @Override
    public void onBindViewHolder(@NonNull FeedHolder holder, int position) {
        ActivityPost post = posts.get(position);
        ItemActivityFeedBinding b = holder.binding;

        b.textName.setText(post.userName);
        b.textTime.setText(DateUtils.relativeTime(post.createdAt));
        b.textActivity.setText(post.text);
        UiUtils.loadAvatar(b.imageAvatar, post.userPhoto, post.userName, b.textAvatarInitials);
        b.imageTypeIcon.setImageResource(iconForActivity(post.type));

        if (post.workoutId != null && !post.workoutId.isEmpty()) {
            b.layoutWorkoutInfo.setVisibility(View.VISIBLE);
            b.textWorkoutName.setText(post.workoutName);
            b.textWorkoutStats.setText(FormatUtils.compactKg(post.volumeKg) + " · "
                    + FormatUtils.duration(post.durationMinutes));
        } else {
            b.layoutWorkoutInfo.setVisibility(View.GONE);
        }

        b.textKudosCount.setText(String.valueOf(post.kudosCount));
        b.textCommentCount.setText(String.valueOf(post.commentCount));
        applyKudosTint(b, post.kudosByMe);

        b.getRoot().setOnClickListener(v -> {
            if (listener != null) listener.onUserClick(post);
        });
        b.textName.setOnClickListener(v -> {
            if (listener != null) listener.onUserClick(post);
        });

        b.buttonKudos.setOnClickListener(v -> {
            User me = Session.profile();
            if (me == null) return;
            socialRepo.toggleKudos(me, post, new Callback<Boolean>() {
                @Override
                public void onSuccess(Boolean liked) {
                    b.textKudosCount.setText(String.valueOf(post.kudosCount));
                    applyKudosTint(b, liked);
                }

                @Override
                public void onError(Exception e) {
                    UiUtils.snack(b.getRoot(), UiUtils.friendlyError(e, b.getRoot().getContext()));
                }
            });
        });

        b.buttonComments.setOnClickListener(v -> {
            if (listener != null) listener.onComments(post);
        });
    }

    @Override
    public int getItemCount() {
        return posts.size();
    }

    private void applyKudosTint(ItemActivityFeedBinding b, boolean liked) {
        int color = ContextCompat.getColor(b.getRoot().getContext(),
                liked ? R.color.accent : R.color.text_secondary);
        b.imageKudos.setColorFilter(color);
        b.textKudosCount.setTextColor(color);
    }

    private int iconForActivity(String type) {
        if (type == null) return R.drawable.ic_dumbbell;
        switch (type) {
            case ActivityPost.TYPE_PR: return R.drawable.ic_medal;
            case ActivityPost.TYPE_STREAK: return R.drawable.ic_fire;
            case ActivityPost.TYPE_JOINED: return R.drawable.ic_person;
            default: return R.drawable.ic_dumbbell;
        }
    }

    static class FeedHolder extends RecyclerView.ViewHolder {
        final ItemActivityFeedBinding binding;

        FeedHolder(ItemActivityFeedBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
