package com.gymfit.app.ui.bodyweight;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.BodyWeightEntry;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.repository.UserRepository;
import com.gymfit.app.databinding.ActivityBodyWeightBinding;
import com.gymfit.app.util.DateUtils;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.FormatUtils;
import com.gymfit.app.util.UiUtils;
import com.gymfit.app.util.ValidationUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Log and review body-weight trend over time. */
public class BodyWeightActivity extends AppCompatActivity {

    private ActivityBodyWeightBinding binding;
    private final UserRepository repo = new UserRepository();
    private final List<BodyWeightEntry> entries = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBodyWeightBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.buttonBack.setOnClickListener(v -> finish());
        binding.buttonLog.setOnClickListener(v -> logWeight());
        styleChart(binding.chartWeight);

        User u = Session.profile();
        if (u != null && u.weightKg > 0) {
            binding.textCurrent.setText(FormatUtils.kg(u.weightKg));
        }
        load();
    }

    private void load() {
        String uid = Session.uid();
        if (!FirebaseState.isReady(this) || uid == null) {
            binding.textEmpty.setVisibility(View.VISIBLE);
            return;
        }
        repo.getBodyWeights(uid, new Callback<List<BodyWeightEntry>>() {
            @Override
            public void onSuccess(List<BodyWeightEntry> result) {
                entries.clear();
                if (result != null) entries.addAll(result);
                render();
            }

            @Override
            public void onError(Exception e) {
                binding.textEmpty.setVisibility(View.VISIBLE);
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, BodyWeightActivity.this));
            }
        });
    }

    private void logWeight() {
        String uid = Session.uid();
        double value = ValidationUtils.parseDouble(
                binding.inputWeight.getText() == null ? "" : binding.inputWeight.getText().toString(), 0);
        if (value <= 0) {
            binding.layoutWeight.setError(getString(R.string.error_required_field));
            return;
        }
        binding.layoutWeight.setError(null);
        if (!FirebaseState.isReady(this) || uid == null) {
            UiUtils.snack(binding.getRoot(), getString(R.string.firebase_not_configured));
            return;
        }
        binding.buttonLog.setEnabled(false);
        repo.addBodyWeight(uid, value, new Callback<Void>() {
            @Override
            public void onSuccess(Void result) {
                binding.buttonLog.setEnabled(true);
                binding.inputWeight.setText("");
                UiUtils.snack(binding.getRoot(), getString(R.string.saved));
                load();
            }

            @Override
            public void onError(Exception e) {
                binding.buttonLog.setEnabled(true);
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, BodyWeightActivity.this));
            }
        });
    }

    private void render() {
        if (entries.isEmpty()) {
            binding.textEmpty.setVisibility(View.VISIBLE);
            binding.chartWeight.setVisibility(View.GONE);
            return;
        }
        binding.textEmpty.setVisibility(View.GONE);
        binding.chartWeight.setVisibility(View.VISIBLE);

        BodyWeightEntry latest = entries.get(entries.size() - 1);
        binding.textCurrent.setText(FormatUtils.kg(latest.weightKg));
        if (entries.size() >= 2) {
            BodyWeightEntry first = entries.get(0);
            double delta = latest.weightKg - first.weightKg;
            binding.textTrend.setText(String.format(Locale.US, "%s%.1f kg overall",
                    delta >= 0 ? "+" : "", delta));
        } else {
            binding.textTrend.setText(R.string.weight_trend);
        }

        List<Entry> points = new ArrayList<>();
        for (int i = 0; i < entries.size(); i++) {
            points.add(new Entry(i, (float) entries.get(i).weightKg));
        }
        LineDataSet set = new LineDataSet(points, "");
        set.setColor(ContextCompat.getColor(this, R.color.accent));
        set.setCircleColor(ContextCompat.getColor(this, R.color.accent));
        set.setLineWidth(2.5f);
        set.setCircleRadius(3f);
        set.setDrawValues(false);
        set.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set.setDrawFilled(true);
        set.setFillColor(ContextCompat.getColor(this, R.color.accent));
        set.setFillAlpha(40);

        LineData data = new LineData(set);
        binding.chartWeight.setData(data);
        binding.chartWeight.getXAxis().setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                int idx = (int) value;
                if (idx < 0 || idx >= entries.size()) return "";
                return DateUtils.formatDayMonth(entries.get(idx).recordedAt);
            }
        });
        binding.chartWeight.invalidate();
    }

    private void styleChart(LineChart chart) {
        int tertiary = ContextCompat.getColor(this, R.color.text_tertiary);
        int grid = ContextCompat.getColor(this, R.color.bg_card_alt);
        chart.getDescription().setEnabled(false);
        chart.getLegend().setEnabled(false);
        chart.setDrawGridBackground(false);
        chart.setScaleEnabled(false);
        chart.setPinchZoom(false);
        chart.getAxisRight().setEnabled(false);
        XAxis x = chart.getXAxis();
        x.setPosition(XAxis.XAxisPosition.BOTTOM);
        x.setDrawGridLines(false);
        x.setTextColor(tertiary);
        x.setGranularity(1f);
        chart.getAxisLeft().setTextColor(tertiary);
        chart.getAxisLeft().setGridColor(grid);
        chart.getAxisLeft().setSpaceTop(15f);
        chart.getAxisLeft().setSpaceBottom(15f);
    }
}
