package com.gymfit.app.data.model;

/** Static challenge definition. Join state lives on User.joinedChallenges; progress is computed. */
public class Challenge {

    public static final String METRIC_WORKOUTS = "WORKOUTS";
    public static final String METRIC_PRS = "PRS";
    public static final String METRIC_VOLUME = "VOLUME";
    public static final String METRIC_STREAK = "STREAK";

    public final String id;
    public final String title;
    public final String description;
    public final String metric;
    public final int target;
    public final int days;

    public Challenge(String id, String title, String description, String metric, int target, int days) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.metric = metric;
        this.target = target;
        this.days = days;
    }

    public static Challenge[] catalog() {
        return new Challenge[]{
                new Challenge("c_30_consistency", "30 Day Consistency",
                        "Complete 20 workouts in 30 days.", METRIC_WORKOUTS, 20, 30),
                new Challenge("c_14_ten", "Fortnight Grinder",
                        "Complete 10 workouts in 14 days.", METRIC_WORKOUTS, 10, 14),
                new Challenge("c_pr5", "Record Breaker",
                        "Hit 5 personal records in 30 days.", METRIC_PRS, 5, 30),
                new Challenge("c_vol100k", "100K Club",
                        "Lift 100,000 kg of total volume in a month.", METRIC_VOLUME, 100000, 30),
                new Challenge("c_streak30", "Iron Streak",
                        "Keep a 30-day training streak alive.", METRIC_STREAK, 30, 30),
                new Challenge("c_streak7", "Week Warrior",
                        "Train 7 days in a row.", METRIC_STREAK, 7, 7),
        };
    }

    public static Challenge byId(String id) {
        for (Challenge c : catalog()) {
            if (c.id.equals(id)) return c;
        }
        return null;
    }
}
