package com.gymfit.app.data.model;

/** Comment on an activity. Stored in `comments/{id}`. */
public class Comment {

    public String id;
    public String activityId;
    public String userId;
    public String userName;
    public String text;
    public long createdAt;

    public Comment() {
    }
}
