package com.gymfit.app.data.repository;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.Query;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Db;
import com.gymfit.app.data.model.BodyWeightEntry;
import com.gymfit.app.data.model.User;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/** Profile reads/writes and body-weight log (users/{uid}/bodyWeights). */
public class UserRepository {

    public void getUser(String uid, Callback<User> callback) {
        if (Db.users() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.users().document(uid).get()
                .addOnSuccessListener(doc -> callback.onSuccess(doc.toObject(User.class)))
                .addOnFailureListener(callback::onError);
    }

    public void getUsers(List<String> uids, Callback<List<User>> callback) {
        if (Db.users() == null || uids == null || uids.isEmpty()) {
            callback.onSuccess(new ArrayList<>());
            return;
        }
        List<User> result = Collections.synchronizedList(new ArrayList<>());
        final int[] remaining = {uids.size()};
        for (String uid : uids) {
            Db.users().document(uid).get()
                    .addOnSuccessListener(doc -> {
                        User u = doc.toObject(User.class);
                        if (u != null) result.add(u);
                        if (--remaining[0] == 0) callback.onSuccess(new ArrayList<>(result));
                    })
                    .addOnFailureListener(e -> {
                        if (--remaining[0] == 0) callback.onSuccess(new ArrayList<>(result));
                    });
        }
    }

    public void watchUser(String uid, Callback<User> callback) {
        if (Db.users() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.users().document(uid).addSnapshotListener((doc, error) -> {
            if (error != null) {
                callback.onError(error);
                return;
            }
            if (doc != null && doc.exists()) {
                callback.onSuccess(doc.toObject(User.class));
            }
        });
    }

    public void saveProfile(User user, Callback<Void> callback) {
        if (Db.users() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        user.refreshSearchKey();
        Db.users().document(user.uid).set(user)
                .addOnSuccessListener(v -> callback.onSuccess(null))
                .addOnFailureListener(callback::onError);
    }

    public void updateFields(String uid, Map<String, Object> fields, Callback<Void> callback) {
        if (Db.users() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.users().document(uid).update(fields)
                .addOnSuccessListener(v -> callback.onSuccess(null))
                .addOnFailureListener(callback::onError);
    }

    /** Prefix search on the lowercase name key — single-field range query, no composite index needed. */
    public void searchUsers(String query, Callback<List<User>> callback) {
        if (Db.users() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        String q = query == null ? "" : query.trim().toLowerCase();
        if (q.isEmpty()) {
            callback.onSuccess(new ArrayList<>());
            return;
        }
        Db.users().orderBy("searchKey", Query.Direction.ASCENDING)
                .startAt(q)
                .endAt(q + "\uf8ff")
                .limit(30)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<User> users = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot) {
                        User u = doc.toObject(User.class);
                        if (u != null) users.add(u);
                    }
                    callback.onSuccess(users);
                })
                .addOnFailureListener(callback::onError);
    }

    public void markRequestSent(String uid, String targetUid) {
        if (Db.users() != null) {
            Db.users().document(uid).update("sentRequestIds", FieldValue.arrayUnion(targetUid));
        }
    }

    public void clearSentRequest(String uid, String targetUid) {
        if (Db.users() != null) {
            Db.users().document(uid).update("sentRequestIds", FieldValue.arrayRemove(targetUid));
        }
    }

    // ---- Body weight ----

    public void addBodyWeight(String uid, double weightKg, Callback<Void> callback) {
        if (Db.users() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        BodyWeightEntry entry = new BodyWeightEntry(uid, weightKg);
        Db.users().document(uid).collection(Db.BODY_WEIGHTS).add(entry)
                .addOnSuccessListener(ref -> {
                    updateFields(uid, Collections.singletonMap("weightKg", weightKg), new Callback<Void>() {
                        @Override
                        public void onSuccess(Void result) {
                            callback.onSuccess(null);
                        }

                        @Override
                        public void onError(Exception e) {
                            callback.onSuccess(null);
                        }
                    });
                })
                .addOnFailureListener(callback::onError);
    }

    public void getBodyWeights(String uid, Callback<List<BodyWeightEntry>> callback) {
        if (Db.users() == null) {
            callback.onError(new IllegalStateException("Firestore unavailable"));
            return;
        }
        Db.users().document(uid).collection(Db.BODY_WEIGHTS).get()
                .addOnSuccessListener(snapshot -> {
                    List<BodyWeightEntry> entries = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot) {
                        BodyWeightEntry e = doc.toObject(BodyWeightEntry.class);
                        if (e != null) {
                            e.id = doc.getId();
                            entries.add(e);
                        }
                    }
                    entries.sort((a, b) -> Long.compare(a.recordedAt, b.recordedAt));
                    callback.onSuccess(entries);
                })
                .addOnFailureListener(callback::onError);
    }
}
