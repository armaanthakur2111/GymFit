package com.gymfit.app.ui.workout;

import com.gymfit.app.data.model.PersonalRecord;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.model.Workout;

import java.util.ArrayList;
import java.util.List;

/**
 * Passes the just-finished workout result between the celebration and summary
 * screens without parceling nested lists. Cleared when the summary is dismissed.
 */
public final class WorkoutResult {

    public static WorkoutResult last;

    public Workout workout;
    public List<PersonalRecord> newPrs = new ArrayList<>();
    public List<String> newBadges = new ArrayList<>();
    public User updatedUser;

    private WorkoutResult() {
    }

    public static WorkoutResult of(Workout workout, List<PersonalRecord> prs,
                                   List<String> badges, User user) {
        WorkoutResult r = new WorkoutResult();
        r.workout = workout;
        if (prs != null) r.newPrs = prs;
        if (badges != null) r.newBadges = badges;
        r.updatedUser = user;
        return r;
    }

    public boolean hasPrs() {
        return newPrs != null && !newPrs.isEmpty();
    }

    public static void clear() {
        last = null;
    }
}
