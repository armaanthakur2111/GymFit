package com.gymfit.app.ui.messages;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gymfit.app.R;
import com.gymfit.app.data.Callback;
import com.gymfit.app.data.Session;
import com.gymfit.app.data.model.ChatRoom;
import com.gymfit.app.data.model.User;
import com.gymfit.app.data.repository.MessageRepository;
import com.gymfit.app.data.repository.UserRepository;
import com.gymfit.app.databinding.ActivityMessagesBinding;
import com.gymfit.app.databinding.ItemChatRowBinding;
import com.gymfit.app.util.DateUtils;
import com.gymfit.app.util.FirebaseState;
import com.gymfit.app.util.UiUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Conversation list backed by chats the current user participates in. */
public class MessagesActivity extends AppCompatActivity {

    private ActivityMessagesBinding binding;
    private final MessageRepository messageRepo = new MessageRepository();
    private final UserRepository userRepo = new UserRepository();
    private final List<ChatRoom> rooms = new ArrayList<>();
    private final Map<String, User> userCache = new HashMap<>();
    private ChatAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMessagesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.buttonBack.setOnClickListener(v -> finish());

        binding.recyclerChats.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ChatAdapter();
        binding.recyclerChats.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }

    private void load() {
        String uid = Session.uid();
        if (!FirebaseState.isReady(this) || uid == null) {
            binding.progressBar.setVisibility(View.GONE);
            binding.emptyState.setVisibility(View.VISIBLE);
            return;
        }
        binding.progressBar.setVisibility(View.VISIBLE);
        messageRepo.getChats(uid, new Callback<List<ChatRoom>>() {
            @Override
            public void onSuccess(List<ChatRoom> result) {
                if (isFinishing()) return;
                rooms.clear();
                if (result != null) rooms.addAll(result);
                resolveOthers();
            }

            @Override
            public void onError(Exception e) {
                binding.progressBar.setVisibility(View.GONE);
                binding.emptyState.setVisibility(View.VISIBLE);
                UiUtils.snack(binding.getRoot(), UiUtils.friendlyError(e, MessagesActivity.this));
            }
        });
    }

    private void resolveOthers() {
        String uid = Session.uid();
        List<String> ids = new ArrayList<>();
        for (ChatRoom r : rooms) {
            String other = r.otherUserId(uid);
            if (other != null && !userCache.containsKey(other)) ids.add(other);
        }
        if (ids.isEmpty()) {
            finishLoad();
            return;
        }
        userRepo.getUsers(ids, new Callback<List<User>>() {
            @Override
            public void onSuccess(List<User> users) {
                if (users != null) {
                    for (User u : users) if (u.uid != null) userCache.put(u.uid, u);
                }
                finishLoad();
            }

            @Override
            public void onError(Exception e) {
                finishLoad();
            }
        });
    }

    private void finishLoad() {
        binding.progressBar.setVisibility(View.GONE);
        adapter.notifyDataSetChanged();
        binding.emptyState.setVisibility(rooms.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private class ChatAdapter extends RecyclerView.Adapter<ChatHolder> {
        @NonNull
        @Override
        public ChatHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ChatHolder(ItemChatRowBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull ChatHolder holder, int position) {
            ChatRoom room = rooms.get(position);
            String uid = Session.uid();
            String otherUid = room.otherUserId(uid);
            User other = otherUid == null ? null : userCache.get(otherUid);
            String name = other != null && other.name != null ? other.name : "Athlete";

            holder.binding.textName.setText(name);
            holder.binding.textLast.setText(room.lastMessageText == null ? "" : room.lastMessageText);
            holder.binding.textTime.setText(DateUtils.relativeTime(room.lastMessageAt));
            UiUtils.loadAvatar(holder.binding.imageAvatar, other == null ? null : other.photoUrl,
                    name, holder.binding.textInitials);
            holder.binding.dotUnread.setVisibility(room.hasUnreadFor(uid) ? View.VISIBLE : View.GONE);

            holder.binding.getRoot().setOnClickListener(v -> {
                Intent i = new Intent(MessagesActivity.this, ChatActivity.class);
                i.putExtra(ChatActivity.EXTRA_OTHER_UID, otherUid);
                i.putExtra(ChatActivity.EXTRA_OTHER_NAME, name);
                i.putExtra(ChatActivity.EXTRA_CHAT_ID, room.id);
                startActivity(i);
            });
        }

        @Override
        public int getItemCount() {
            return rooms.size();
        }
    }

    private static class ChatHolder extends RecyclerView.ViewHolder {
        final ItemChatRowBinding binding;

        ChatHolder(ItemChatRowBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
