package com.gymfit.app.data;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.gymfit.app.data.model.User;

/**
 * Lightweight session holder: current auth user and cached profile document,
 * shared by fragments/activities to avoid repeated fetches per screen.
 */
public class Session {

    private static User cachedProfile;

    private Session() {
    }

    public static FirebaseUser authUser() {
        try {
            return FirebaseAuth.getInstance().getCurrentUser();
        } catch (Exception e) {
            return null;
        }
    }

    public static String uid() {
        FirebaseUser u = authUser();
        return u == null ? null : u.getUid();
    }

    public static User profile() {
        return cachedProfile;
    }

    public static void setProfile(User user) {
        cachedProfile = user;
    }

    public static void clear() {
        cachedProfile = null;
    }
}
