package com.gymfit.app.data.model;

/** A gym location. Stored in `gyms/{id}`. Only the gym position is ever exposed — never a user's live location. */
public class Gym {

    public String id;
    public String name;
    public String city;
    public double latitude;
    public double longitude;

    // Client-side only, filled by queries.
    public transient int memberCount;

    public Gym() {
    }

    public Gym(String id, String name, String city, double latitude, double longitude) {
        this.id = id;
        this.name = name;
        this.city = city;
        this.latitude = latitude;
        this.longitude = longitude;
    }
}
