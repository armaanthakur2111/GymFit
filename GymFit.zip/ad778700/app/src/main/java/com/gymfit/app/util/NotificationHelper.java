package com.gymfit.app.util;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.gymfit.app.R;

public final class NotificationHelper {

    public static final String CHANNEL_SOCIAL = "gymfit_social";
    public static final String CHANNEL_PROGRESS = "gymfit_progress";
    public static final String CHANNEL_WORKOUT = "gymfit_workout";

    private NotificationHelper() {
    }

    public static void createChannels(Context context) {
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) return;

        manager.createNotificationChannel(new NotificationChannel(
                CHANNEL_SOCIAL,
                context.getString(R.string.channel_social_name),
                NotificationManager.IMPORTANCE_DEFAULT));
        manager.createNotificationChannel(new NotificationChannel(
                CHANNEL_PROGRESS,
                context.getString(R.string.channel_progress_name),
                NotificationManager.IMPORTANCE_HIGH));
        NotificationChannel workout = new NotificationChannel(
                CHANNEL_WORKOUT,
                context.getString(R.string.channel_workout_name),
                NotificationManager.IMPORTANCE_HIGH);
        manager.createNotificationChannel(workout);

        NotificationChannel social = manager.getNotificationChannel(CHANNEL_SOCIAL);
        if (social != null) {
            social.setDescription(context.getString(R.string.channel_social_desc));
        }
        NotificationChannel progress = manager.getNotificationChannel(CHANNEL_PROGRESS);
        if (progress != null) {
            progress.setDescription(context.getString(R.string.channel_progress_desc));
        }
        NotificationChannel w = manager.getNotificationChannel(CHANNEL_WORKOUT);
        if (w != null) {
            w.setDescription(context.getString(R.string.channel_workout_desc));
        }
    }

    public static void notify(Context context, String channelId, int id, String title, String body, Intent tapIntent) {
        NotificationManagerCompat manager = NotificationManagerCompat.from(context);
        if (!manager.areNotificationsEnabled()) return;

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setColor(context.getColor(R.color.accent));

        if (tapIntent != null) {
            PendingIntent pending = PendingIntent.getActivity(
                    context, id, tapIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            builder.setContentIntent(pending);
        }

        try {
            if (android.os.Build.VERSION.SDK_INT >= 33
                    && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                return;
            }
            manager.notify(id, builder.build());
        } catch (SecurityException ignored) {
            // Permission revoked between check and post; silently drop.
        }
    }
}
