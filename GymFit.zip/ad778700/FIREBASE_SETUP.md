# GymFit — Backend & Credential Setup

GymFit is built to run **without any credentials checked into the repository**. Every
external secret is supplied through configuration, and the app degrades gracefully
(showing an in-app banner and falling back to local-only behaviour) whenever a
credential is missing. This file lists exactly what to provide and where.

There are **three** independent integrations. You can enable them one at a time.

| Integration | Required for | Missing-credential behaviour |
|---|---|---|
| Firebase (Auth + Firestore + Storage) | Accounts, cloud sync, social, messaging, leaderboards, notifications | App runs offline/local-only; `bannerFirebase` shown on social screens |
| Google Maps SDK | The gym map | `MapFragment` shows a gym **list** instead of a map; `bannerMap` shown |
| AI Coach backend proxy | The AI coach chat | AI screen shows `bannerNotConfigured`; input disabled |

---

## 1. Firebase

### 1a. `google-services.json`
1. Create (or open) a project at <https://console.firebase.google.com>.
2. Add an **Android** app with package name `com.gymfit.app`.
3. Download `google-services.json` and place it at:
   ```
   app/google-services.json
   ```
   The Gradle plugin `com.google.gms.google-services` is applied **conditionally**
   (see the bottom of `app/build.gradle`) only when this file exists, so the project
   builds fine without it. **Never commit this file** — it is environment config.
4. In the Firebase console enable:
   - **Authentication → Email/Password** (the app never stores plaintext passwords;
     Firebase Auth handles hashing/verification).
   - **Cloud Firestore** (start in *production* mode, then deploy the rules below).
   - **Storage** (only needed if you later wire avatar uploads).

### 1b. Security rules
Deploy the rules shipped in this repo:
```
firebase deploy --only firestore:rules,storage
```
- `firestore.rules` — owner-scoped private data, public social reads, and the
  narrowly-scoped cross-user writes the fan-out design needs (friend mirrors,
  request inbox, kudos/comment counters, notifications, chat messages).
- `storage.rules` — per-user `avatars/{uid}/...` namespace.

### 1c. Seed data
`gyms` are treated as read-only venues managed out of band. Populate the `gyms`
collection from the Firebase console or a one-off admin script (fields: `name`,
`city`, `latitude`, `longitude`). Built-in workout splits are seeded client-side by
`WorkoutRepository.seedSystemTemplates()`.

> **Exact missing credential:** `app/google-services.json` (Firebase project config).

---

## 2. Google Maps

The manifest already wires the key via a string resource (never hardcoded):
```xml
<meta-data android:name="com.google.android.geo.API_KEY"
           android:value="@string/google_maps_api_key" />
```
1. In Google Cloud Console, enable **Maps SDK for Android** and create an API key.
2. Replace the placeholder in `app/src/main/res/values/strings.xml`:
   ```xml
   <string name="google_maps_api_key">YOUR_GOOGLE_MAPS_API_KEY</string>
   ```
   While the value equals `YOUR_GOOGLE_MAPS_API_KEY`, `MapFragment` detects the
   placeholder and renders the **list fallback** instead of a map — no crash.
3. For production, keep the real key out of version control (inject it at build time
   or via a secure `strings.xml` overlay) and restrict it by package + SHA-1.

> **Exact missing credential:** a Google Maps API key with *Maps SDK for Android* enabled.

The app deliberately stores only the user's **selected gym venue**, never a live
GPS location — see the privacy note surfaced in `MapFragment`.

---

## 3. AI Coach (OpenAI via a backend proxy)

**The OpenAI API key must never be shipped inside the Android app.** The client talks
to *your* backend endpoint, and the backend holds the real OpenAI key.

### 3a. Configure the client
Supply these as Gradle properties (in `~/.gradle/gradle.properties`, CI secrets, or
`-P` flags) — they map to `BuildConfig` fields in `app/build.gradle`:

| Gradle property | BuildConfig field | Default | Meaning |
|---|---|---|---|
| `GYMFIT_AI_ENDPOINT` | `AI_ENDPOINT` | `""` (empty → unconfigured) | URL of your proxy |
| `GYMFIT_AI_KEY` | `AI_API_KEY` | `""` | Optional token your proxy requires (sent as `Authorization: Bearer`) |
| `GYMFIT_AI_MODEL` | `AI_MODEL` | `gpt-4o-mini` | Model name forwarded to OpenAI |

Example:
```bash
./gradlew assembleDebug \
  -PGYMFIT_AI_ENDPOINT="https://your-backend.example.com/api/coach" \
  -PGYMFIT_AI_KEY="proxy-shared-secret"
```

### 3b. Contract your backend must implement
The client (`AiCoachRepository`) sends an **OpenAI Chat Completions–compatible**
request and expects an OpenAI-compatible response:

Request `POST {AI_ENDPOINT}`:
```json
{
  "model": "gpt-4o-mini",
  "messages": [
    { "role": "system", "content": "..." },
    { "role": "user",   "content": "..." }
  ],
  "temperature": 0.7,
  "max_tokens": 900
}
```
Response:
```json
{ "choices": [ { "message": { "content": "coach reply text" } } ] }
```
Your proxy should validate the caller, then forward to
`https://api.openai.com/v1/chat/completions` using the server-side
`OPENAI_API_KEY` (stored in the server environment / secret manager, never in the
app or the repo), and return the upstream JSON unchanged.

> **Exact missing credentials:** (1) the deployed proxy URL for `GYMFIT_AI_ENDPOINT`,
> and (2) the server-side `OPENAI_API_KEY` held by that proxy.

---

## Quick checklist
- [ ] `app/google-services.json` added (git-ignored)
- [ ] Firestore + Auth enabled; `firestore.rules` / `storage.rules` deployed
- [ ] `gyms` collection seeded
- [ ] `google_maps_api_key` replaced with a real, restricted key (optional)
- [ ] `GYMFIT_AI_ENDPOINT` (and optional `GYMFIT_AI_KEY`) provided via Gradle props
- [ ] Backend proxy holds `OPENAI_API_KEY` server-side
